import numpy as np
import random
import math
import copy

from pymoo.indicators.hv import HV


class SGA_QL_FJSP:
    def __init__(self, generation, popsize, to, oh, work, job_num, tran_time, M_dicr, Work_arr, work_num):
        self.generation = generation
        self.popsize = popsize
        self.to = to
        self.oh = oh
        self.work = work
        self.job_num = job_num
        self.tran_time = tran_time
        self.M_dicr = M_dicr
        self.Work_arr = Work_arr
        self.work_num = work_num

        # *** SGA 核心状态：位置和速度 (作为实例属性统一管理) ***
        self.Vel = np.zeros((self.popsize, len(self.work)))
        self.Pos = np.zeros((self.popsize, len(self.work)))

        # 速度限制，防止数值溢出
        self.v_max = 0.5
        self.v_min = -0.5

        # --- Q-Learning 参数 ---
        self.actions = [0, 1, 2, 3]  # 0: SGA-Explore, 1: SGA-Exploit, 2: Restart, 3: Lévy-Flight
        self.num_actions = 4
        self.num_states = 9
        self.q_table = np.zeros((self.num_states, self.num_actions))
        self.reward_history = []

        # Q-learning 超参数
        self.alpha = 0.3
        self.gamma = 0.7
        self.epsilon = 1.0
        self.epsilon_decay = 0.97
        self.epsilon_min = 0.01
        self.stagnation_reset_threshold = 20

        # --- 状态与奖励追踪变量 ---
        # >>> 修改 1：使用归一化后的参考点 <<<
        self.ref_point = np.array([1.1, 1.1, 1.1])
        self.hv_indicator = HV(ref_point=self.ref_point)
        self.last_hv = 0.0
        self.convergence_stagnation_counter = 0
        self.last_avg_cd = 0.0
        self.diversity_history = []

        self.diversity_threshold_low, self.diversity_threshold_high = self._determine_diversity_thresholds()

        self.best_cmax_so_far = float('inf')
        self.best_energy_so_far = float('inf')
        self.best_fatigue_so_far = float('inf')

    def _determine_diversity_thresholds(self):
        print("--- Determining dynamic diversity thresholds from initial sampling ---")
        pop_data = []

        work_job, work_M, work_T, work_tran, _, job_init, work_wc = self.to.creat_job()
        for i in range(self.popsize):
            res = self.to.caculate(work_job[i:i + 1], work_M[i:i + 1], work_T[i:i + 1], work_tran[i:i + 1],
                                   work_wc[i:i + 1])
            fitness = [res[0], res[10], res[9]]
            pop_data.append({'fitness': fitness})

        initial_diversity = self._calculate_avg_crowding_distance(pop_data)

        if initial_diversity < 0.1:
            initial_diversity = 1.0

        high_threshold = initial_diversity * 0.8
        low_threshold = initial_diversity * 0.3

        print(f"Initial Diversity Base: {initial_diversity:.4f}")
        print(f"Dynamic thresholds set: low={low_threshold:.4f}, high={high_threshold:.4f}")
        return low_threshold, high_threshold

    def min_max_normalize_pareto(self, pareto_fitness):
        if not pareto_fitness: return []
        arr = np.array(pareto_fitness, dtype=float)

        # 1. 动态初始化并跟踪全局极值（无论算例多大都能自适应）
        if not hasattr(self, 'global_min_bounds'):
            self.global_min_bounds = np.min(arr, axis=0)
            self.global_max_bounds = np.max(arr, axis=0)
        else:
            self.global_min_bounds = np.minimum(self.global_min_bounds, np.min(arr, axis=0))
            self.global_max_bounds = np.maximum(self.global_max_bounds, np.max(arr, axis=0))
        # 2. 计算极差
        diff = self.global_max_bounds - self.global_min_bounds
        # 3. 防止除零错误（如果某一代所有个体的某个目标值完全一样）
        diff[diff == 0] = 1e-8
        # 4. 映射到 [0, 1]
        norm_arr = (arr - self.global_min_bounds) / diff
        # 5. 严格限制在 [0, 1] 之间，防止微小浮点误差
        norm_arr = np.clip(norm_arr, 0.0, 1.0)
        return norm_arr.tolist()

    def mutation(self, individual_data, pm_job=0.1, pm_machine=0.2):
        new_data = copy.deepcopy(individual_data)
        job_seq = new_data['job'].flatten()
        num_ops = len(job_seq)

        if random.random() < pm_job:
            idx1, idx2 = random.sample(range(num_ops), 2)
            if job_seq[idx1] != job_seq[idx2]:
                job_seq[idx1], job_seq[idx2] = job_seq[idx2], job_seq[idx1]
                new_data['job'] = job_seq.reshape(1, -1)

        if random.random() < pm_machine:
            op_idx = random.randint(0, num_ops - 1)
            job_id = int(new_data['job'][0, op_idx])
            op_order = np.where(new_data['job'][0] == job_id)[0].tolist().index(op_idx)

            available_machines = self.to.Tmachine[job_id][op_order]
            if len(available_machines) > 1:
                new_m_1based = random.choice(available_machines)
                new_data['M'][0, op_idx] = new_m_1based - 1

        new_M = new_data['M']
        new_T = np.zeros_like(new_data['T'])
        new_wc = new_data['wc']
        op_counters = {job_id: 0 for job_id in range(self.job_num)}

        for i in range(num_ops):
            job_id = int(new_data['job'][0, i])
            op_seq = op_counters[job_id]

            available_machines = self.to.Tmachine[job_id][op_seq]
            available_times = self.to.Tmachinetime[job_id][op_seq]

            current_m_0based = int(new_M[0, i])
            current_m_1based = current_m_0based + 1

            if current_m_1based in available_machines:
                m_index = available_machines.index(current_m_1based)
                new_T[0, i] = available_times[m_index]
            else:
                new_m_1based = random.choice(available_machines)
                new_m_0based = new_m_1based - 1
                m_index = available_machines.index(new_m_1based)

                new_M[0, i] = new_m_0based
                new_T[0, i] = available_times[m_index]

                workers = self.Work_arr[new_m_0based]
                new_wc[0, i] = random.choice(workers) if len(workers) > 0 else 0

            op_counters[job_id] += 1

        new_data['M'] = new_M
        new_data['T'] = new_T
        new_data['wc'] = new_wc

        return new_data

    def reset_for_new_episode(self):
        self.Vel = np.zeros((self.popsize, len(self.work)))
        self.Pos = np.zeros((self.popsize, len(self.work)))
        self.reward_history = []
        self.last_hv = 0.0
        self.convergence_stagnation_counter = 0
        self.last_avg_cd = 0.0
        self.diversity_history = []
        self.best_cmax_so_far = float('inf')
        self.best_energy_so_far = float('inf')
        self.best_fatigue_so_far = float('inf')

    def to_MT(self, W1, M1, T1, WC):
        Ma_W1, Tm_W1, WCross, WC_W1 = [], [], [], []
        for i in range(self.job_num):
            Ma_W1.append([]), Tm_W1.append([]), WCross.append([]), WC_W1.append([])
        for i in range(W1.shape[1]):
            signal1 = int(W1[0, i])
            Ma_W1[signal1].append(M1[0, i]), Tm_W1[signal1].append(T1[0, i]), WC_W1[signal1].append(WC[0, i]);
            index = np.random.randint(0, 2, 1)[0]
            WCross[signal1].append(index)
        return Ma_W1, Tm_W1, WCross, WC_W1

    def back_MT(self, W1, Ma_W1, Tm_W1, WC1):
        memory1 = np.zeros((1, self.job_num), dtype=int)
        m1, t1, wc = np.zeros((1, W1.shape[1])), np.zeros((1, W1.shape[1])), np.zeros((1, W1.shape[1]))
        for i in range(W1.shape[1]):
            signal1 = int(W1[0, i])
            m1[0, i] = Ma_W1[signal1][memory1[0, signal1]]
            t1[0, i] = Tm_W1[signal1][memory1[0, signal1]]
            wc[0][i] = WC1[signal1][memory1[0, signal1]]
            memory1[0, signal1] += 1
        return m1, t1, wc

    def mac_cross(self,Ma_W1,Tm_W1,Ma_W2,Tm_W2,WCross,WC_W1,WC_W2):  #机器均匀交叉
        MC1,MC2,TC1,TC2=[],[],[],[]
        TR1,TR2,trtime=[],[],[]
        WC1,WC2 = [],[]
        for i in range(self.job_num):
            MC1.append([]),MC2.append([]),TC1.append([]),TC2.append([]),WC1.append([]),WC2.append([])
            c =len((WCross[i]))
            for j in range(c):
                if(WCross[i][j]==0):  #为0时继承另一个父代的加工机器选择
                    MC1[i].append(Ma_W1[i][j]), MC2[i].append(Ma_W2[i][j]), TC1[i].append(Tm_W1[i][j]), TC2[i].append(Tm_W2[i][j])#,WC1[i].append(float(self.select_different_number(self.Work_arr[int(Ma_W1[i][j])], WC_W1[i][j]))),WC2[i].append(float(self.select_different_number(self.Work_arr[int(Ma_W1[i][j])], WC_W2[i][j])))#, WC1[i].append(WC_W1[i][j]), WC2[i].append(WC_W2[i][j])
                else:                #为1时继承父代的机器选择
                    MC2[i].append(Ma_W1[i][j]), MC1[i].append(Ma_W2[i][j]), TC2[i].append(Tm_W1[i][j]), TC1[i].append(Tm_W2[i][j])#,WC2[i].append(float(self.select_different_number(self.Work_arr[int(Ma_W1[i][j])], WC_W1[i][j]))),WC1[i].append(float(self.select_different_number(self.Work_arr[int(Ma_W1[i][j])], WC_W2[i][j])))#, WC2[i].append(WC_W1[i][j]), WC1[i].append(WC_W2[i][j])
            for z in range(c):
                prob = random.random()
                if prob < 0.99:
                    if (WCross[i][z] == 0):
                        WC1[i].append(WC_W1[i][z]), WC2[i].append(WC_W2[i][z])
                    else:
                        WC2[i].append(WC_W1[i][z]), WC1[i].append(WC_W2[i][z])
                else:
                    if (WCross[i][z] == 0):
                        WC1[i].append(float(self.select_different_number(self.Work_arr[int(Ma_W1[i][z])], WC_W1[i][z])))
                        WC2[i].append(float(self.select_different_number(self.Work_arr[int(Ma_W1[i][z])], WC_W2[i][z])))
                    else:
                        WC2[i].append(float(self.select_different_number(self.Work_arr[int(Ma_W1[i][z])], WC_W1[i][z])))
                        WC1[i].append(float(self.select_different_number(self.Work_arr[int(Ma_W1[i][z])], WC_W2[i][z])))

        return MC1,TC1,MC2,TC2,WC1,WC2
    def select_different_number(self,list, number):
        while True:
            if len(list) == 1:
                return number
            else:
                random_number = np.random.choice(list)
                if random_number != number:
                    return random_number

    def POX_improve(self, Father_1, Father_2):
        f1 = Father_1.flatten().copy()
        f2 = Father_2.flatten().copy()
        n_jobs = self.job_num
        n_ops = len(self.work)
        all_jobs = list(range(n_jobs))
        random.shuffle(all_jobs)
        split_point = random.randint(1, n_jobs - 1)
        J_set_1 = set(all_jobs[:split_point])
        J_set_2 = set(all_jobs[split_point:])
        children_1 = np.full(n_ops, -1, dtype=int)
        children_2 = np.full(n_ops, -1, dtype=int)
        for i in range(n_ops):
            if f1[i] in J_set_1: children_1[i] = f1[i]
        f2_remaining = [op for op in f2 if op in J_set_2]
        j = 0
        for i in range(n_ops):
            if children_1[i] == -1:
                children_1[i] = f2_remaining[j]
                j += 1
        for i in range(n_ops):
            if f2[i] in J_set_2: children_2[i] = f2[i]
        f1_remaining = [op for op in f1 if op in J_set_1]
        j = 0
        for i in range(n_ops):
            if children_2[i] == -1:
                children_2[i] = f1_remaining[j]
                j += 1
        return children_1, children_2

    def _perform_levy_flight_strategy(self, gBest_pos, last_fronts):
        # print(f"  --- [ACTION EXECUTED: LÉVY FLIGHT] ---")
        if self.convergence_stagnation_counter > 10:
            alpha_levy = 0.6
        elif self.convergence_stagnation_counter > 5:
            alpha_levy = 0.3
        else:
            alpha_levy = 0.1

        rank0_indices = last_fronts[0] if last_fronts else []
        update_mask = np.ones(self.popsize, dtype=bool)

        if len(rank0_indices) < self.popsize:
            update_mask[rank0_indices] = False

        step_sizes = self.levy_flight_step(beta=1.5, alpha=alpha_levy, size=self.Pos.shape)
        diff = self.Pos[update_mask] - gBest_pos
        self.Pos[update_mask] = self.Pos[update_mask] + step_sizes[update_mask] * diff
        self.Pos = np.clip(self.Pos, 0, 1)
        self.Vel[update_mask] = 0.0

    def z_score_normalize_objectives(self, objectives_list):
        if not objectives_list: return []
        obj_array = np.array(objectives_list, dtype=float)
        mean_val = np.mean(obj_array, axis=0)
        std_val = np.std(obj_array, axis=0)
        std_val[std_val == 0] = 1
        normalized_obj_array = (obj_array - mean_val) / std_val
        return normalized_obj_array.tolist()

    def gettran(self, job, machine):
        trantime = np.ones((1, job.shape[1]))
        index = []
        k = 0
        for i in range(self.job_num):
            for j in range(len(job[0])):
                if job[0][j] == i:
                    k += 1
                    index.append(j)
                    if k > 1:
                        a = machine[0][j]
                        b = machine[0][index[-2]]
                        x = list(self.M_dicr[int(a)])[0] - 1
                        y = list(self.M_dicr[int(b)])[0] - 1
                        trantime[0][j] = self.tran_time[y][x]
                    else:
                        trantime[0][j] = 0
            index = []
            k = 0
        return trantime

    def _brownian_motion(self, dim):
        T = 1.0
        r = T / dim
        dw = np.sqrt(r) * np.random.randn(1, dim)
        return np.cumsum(dw)

    def levy_flight_step(self, beta=1.5, alpha=0.1, size=None):
        try:
            num = math.gamma(1 + beta) * math.sin(math.pi * beta / 2)
            den = math.gamma((1 + beta) / 2) * beta * (2 ** ((beta - 1) / 2))
            sigma_u = (num / den) ** (1 / beta)
        except ValueError:
            sigma_u = 0.6966
        sigma_v = 1
        u = np.random.normal(0, sigma_u, size)
        v = np.random.normal(0, sigma_v, size)
        step = u / ((np.abs(v) + 1e-10) ** (1 / beta))
        return alpha * step

    def _calculate_avg_crowding_distance(self, pop_data):
        if not pop_data: return 0.0
        all_fitnesses = [ind['fitness'] for ind in pop_data]
        if not all(isinstance(f, (list, np.ndarray)) and len(f) == 3 and all(np.isfinite(val) for val in f) for f in
                   all_fitnesses): return 0.0
        normalized_fitnesses = self.z_score_normalize_objectives(all_fitnesses)
        if not normalized_fitnesses: return 0.0
        try:
            fronts, crowds, _ = self.oh.dis(normalized_fitnesses)
            if not fronts or not crowds or not crowds[0]: return 0.01
            front0_crowding_values_raw = crowds[0]
            finite_crowding_values = [cd for cd in front0_crowding_values_raw if cd < 100000]
            if finite_crowding_values:
                return np.mean(finite_crowding_values)
            else:
                return 0.01
        except Exception:
            return 0.0

    def _get_state(self, current_pop_data):
        all_fitnesses = [d['fitness'] for d in current_pop_data]
        fronts, _, _ = self.oh.dis(self.z_score_normalize_objectives(all_fitnesses))

        current_diversity = self._calculate_avg_crowding_distance(current_pop_data)
        if current_diversity < self.diversity_threshold_low:
            state_diversity = 0
        elif current_diversity > self.diversity_threshold_high:
            state_diversity = 2
        else:
            state_diversity = 1

        if self.convergence_stagnation_counter < 3:
            state_convergence = 0
        elif self.convergence_stagnation_counter < 6:
            state_convergence = 1
        else:
            state_convergence = 2

        return state_diversity * 3 + state_convergence

    def _choose_action(self, state):
        if np.random.rand() <= self.epsilon:
            return random.choice(self.actions)
        else:
            return np.argmax(self.q_table[state])

    def _calculate_reward(self, last_hv, current_hv, last_avg_cd, current_avg_cd, old_pop_pf, new_pop_pf,
                          stagnation_broken):
        R_perf = 0.0
        hv_improvement = current_hv - last_hv
        if hv_improvement > 1e-6:
            R_perf += 1.0
            R_perf += 10.0 * hv_improvement / max(last_hv, 1e-6)
        else:
            if hv_improvement < -1e-6: R_perf = 0.0

        c_new_old = self._calculate_c_metric(new_pop_pf, old_pop_pf)
        c_old_new = self._calculate_c_metric(old_pop_pf, new_pop_pf)
        R_cmetric = c_new_old - c_old_new

        R_break = 10.0 if stagnation_broken else 0.0
        W_hv, W_record, W_prog = 1.0, 1.0, 5.0
        return W_hv * R_perf + W_prog * R_cmetric + R_break

    def _update_q_table(self, state, action, reward, next_state):
        old_value = self.q_table[state, action]
        next_max = np.max(self.q_table[next_state])
        new_value = (1 - self.alpha) * old_value + self.alpha * (reward + self.gamma * next_max)
        self.q_table[state, action] = new_value
        if self.epsilon > self.epsilon_min: self.epsilon *= self.epsilon_decay

    def _perform_sga_exploration_phase(self, gBest, Xc, worst):
        old_pos = self.Pos.copy()
        a, b, c = 4 * np.random.rand() - 2, 3 * np.random.rand() - 1.5, 2 * np.random.rand() - 1
        n1, n2 = self.popsize // 5, 4 * self.popsize // 5
        self.Pos[:n1] += a * (gBest - self.Pos[:n1])
        self.Pos[n1:n2] += b * (Xc - self.Pos[n1:n2])
        self.Pos[n2:] -= c * (worst + self.Pos[n2:])
        self.Vel = self.Pos - old_pos

    def _perform_sga_exploitation_phase(self, gBest, gen):
        coe_t = (gen + 1) / self.generation
        coe = (4 * coe_t) / np.exp(4 * coe_t) if coe_t > 0 else 0
        acc = ((gBest - self.Pos) - 1.29 * (self.Vel ** 2) * np.sin(np.random.rand() * 2 * np.pi)) * 1e-2
        self.Vel = coe * self.Vel + acc
        self.Pos += self.Vel
        if np.random.rand() > 0.5:
            self.Pos += (gBest - self.Pos) * np.random.rand(self.popsize, 1)
        else:
            self.Pos = gBest + (gBest - self.Pos) * np.random.rand(self.popsize, 1) * self._brownian_motion(
                len(self.work))

    def _calculate_c_metric(self, front_A, front_B):
        if not front_A or not front_B: return 0.0
        dominated_count = 0
        for b_solution in front_B:
            is_dominated = any(self._dominates(a_solution, b_solution) for a_solution in front_A)
            if is_dominated: dominated_count += 1
        return dominated_count / len(front_B)

    def _perform_restart_strategy(self, gBest_pos):
        indices_to_reset = range(self.popsize // 2, self.popsize)
        num_to_reset = len(indices_to_reset)
        if num_to_reset == 0: return

        opposite_gBest_pos = 1.0 - gBest_pos
        num_opposite = num_to_reset // 2
        if num_opposite > 0:
            opposite_indices = indices_to_reset[:num_opposite]
            noise = np.random.normal(loc=0.0, scale=0.1, size=(num_opposite, len(self.work)))
            self.Pos[opposite_indices] = opposite_gBest_pos + noise
            self.Vel[opposite_indices] = 0.0

        num_random = num_to_reset - num_opposite
        if num_random > 0:
            random_indices = indices_to_reset[num_opposite:]
            self.Pos[random_indices] = np.random.rand(num_random, len(self.work))
            self.Vel[random_indices] = 0.0

        self.Pos[indices_to_reset] = np.clip(self.Pos[indices_to_reset], 0, 1)

    def _create_sga_offspring(self, parent_pop_data_sorted):
        offspring = []
        for i in range(self.popsize):
            parent = parent_pop_data_sorted[i]
            index_work = self.Pos[i].argsort()
            job = np.array([[self.work[idx] for idx in index_work]])

            Ma_W, Tm_W, _, WC_W = self.to_MT(parent['job'], parent['M'], parent['T'], parent['wc'])
            M, T, wc = self.back_MT(job, Ma_W, Tm_W, WC_W)

            T = self._get_correct_time_chromosome(job, M)
            tran = self.gettran(job, M)
            res = self.to.caculate(job, M, T, tran, wc)
            fitness = [res[0], res[10], res[9]]

            offspring.append(
                {'job': job, 'M': M, 'T': T, 'tran': tran, 'wc': wc, 'fitness': fitness, 'pos': self.Pos[i],
                 'vel': self.Vel[i]})
        return offspring

    def _get_correct_time_chromosome(self, os_chromosome, ms_chromosome):
        num_ops = os_chromosome.shape[1]
        new_T = np.zeros((1, num_ops), dtype=float)
        op_counters = {job_id: 0 for job_id in range(self.job_num)}

        for i in range(num_ops):
            job_id = int(os_chromosome[0, i])
            op_seq = op_counters[job_id]
            assigned_machine_0based = int(ms_chromosome[0, i])
            available_machines = self.to.Tmachine[job_id][op_seq]
            available_times = self.to.Tmachinetime[job_id][op_seq]

            try:
                machine_index = available_machines.index(assigned_machine_0based + 1)
                new_T[0, i] = available_times[machine_index]
            except ValueError:
                new_T[0, i] = 10000.0
            op_counters[job_id] += 1
        return new_T

    def _create_crossover_offspring(self, pop_data, current_gen):
        crossed_offspring = []
        pm_job_dynamic = 0.1 + (current_gen / self.generation) * 0.1
        pm_mac_dynamic = 0.1 + (current_gen / self.generation) * 0.15

        for _ in range(self.popsize // 4):
            p1_data = random.choice(pop_data)
            p2_data = random.choice(pop_data)

            c1_os, c2_os = self.POX_improve(p1_data['job'], p2_data['job'])
            c1_os, c2_os = np.array([c1_os]), np.array([c2_os])

            Ma_W1, Tm_W1, WCross, WC_W1 = self.to_MT(p1_data['job'], p1_data['M'], p1_data['T'], p1_data['wc'])
            Ma_W2, Tm_W2, _, WC_W2 = self.to_MT(p2_data['job'], p2_data['M'], p2_data['T'], p2_data['wc'])
            MC1, TC1, MC2, TC2, C_WC1, C_WC2 = self.mac_cross(Ma_W1, Tm_W1, Ma_W2, Tm_W2, WCross, WC_W1, WC_W2)

            c1_M, c1_T, c1_wc = self.back_MT(c1_os, MC1, TC1, C_WC1)
            c1_tran = self.gettran(c1_os, c1_M)
            c2_M, c2_T, c2_wc = self.back_MT(c2_os, MC2, TC2, C_WC2)
            c2_tran = self.gettran(c2_os, c2_M)

            child1_temp = {'job': c1_os, 'M': c1_M, 'T': c1_T, 'wc': c1_wc}
            child2_temp = {'job': c2_os, 'M': c2_M, 'T': c2_T, 'wc': c2_wc}

            child1_mutated = self.mutation(child1_temp, pm_job_dynamic, pm_mac_dynamic)
            child2_mutated = self.mutation(child2_temp, pm_job_dynamic, pm_mac_dynamic)

            final_c1_job = child1_mutated['job']
            final_c1_M = child1_mutated['M']
            final_c1_T = child1_mutated['T']
            final_c1_wc = child1_mutated['wc']
            final_c1_tran = self.gettran(final_c1_job, final_c1_M)
            c1_res = self.to.caculate(final_c1_job, final_c1_M, final_c1_T, final_c1_tran, final_c1_wc)
            c1_fit = [c1_res[0], c1_res[10], c1_res[9]]

            final_c2_job = child2_mutated['job']
            final_c2_M = child2_mutated['M']
            final_c2_T = child2_mutated['T']
            final_c2_wc = child2_mutated['wc']
            final_c2_tran = self.gettran(final_c2_job, final_c2_M)
            c2_res = self.to.caculate(final_c2_job, final_c2_M, final_c2_T, final_c2_tran, final_c2_wc)
            c2_fit = [c2_res[0], c2_res[10], c2_res[9]]

            job_init_c1 = p1_data['pos'].copy()
            job_init_c2 = p2_data['pos'].copy()
            vel_child = (p1_data['vel'] + p2_data['vel']) * 0.1

            crossed_offspring.append({
                'job': final_c1_job, 'M': final_c1_M, 'T': final_c1_T,
                'tran': final_c1_tran, 'wc': final_c1_wc,
                'pos': job_init_c1, 'fitness': c1_fit, 'vel': vel_child
            })
            crossed_offspring.append({
                'job': final_c2_job, 'M': final_c2_M, 'T': final_c2_T,
                'tran': final_c2_tran, 'wc': final_c2_wc,
                'pos': job_init_c2, 'fitness': c2_fit, 'vel': vel_child
            })

        return crossed_offspring

    def _dominates(self, p, q):
        return all(x <= y for x, y in zip(p, q))

    def sga_total(self):
        evaluated_pop_data = []
        print("--- SGA-FJSP: 初始化种群 ---")
        work_job, work_M, work_T, work_tran, _, job_init, work_wc = self.to.create_job_ensga(
            self.popsize, [0.2, 0.5, 0.2, 0.1]
        )
        for i in range(self.popsize):
            C_finish, _, list_T, _, _, _, _, _, _, global_max_fatigue, E_all = self.to.caculate(
                work_job[i:i + 1], work_M[i:i + 1], work_T[i:i + 1], work_tran[i:i + 1], work_wc[i:i + 1],
                record_fatigue_history=False
            )
            fitness = [C_finish, E_all, global_max_fatigue]
            evaluated_pop_data.append({
                'job': work_job[i:i + 1], 'M': work_M[i:i + 1], 'T': work_T[i:i + 1],
                'tran': work_tran[i:i + 1], 'wc': work_wc[i:i + 1],
                'fitness': fitness, 'pos': self.Pos[i], 'vel': self.Vel[i]
            })
            self.Pos[i, :] = job_init[i, :]

        fit_every = [[], [], []]
        self.convergence_stagnation_counter = 0
        init_fitnesses = [d['fitness'] for d in evaluated_pop_data]
        init_fronts, _, _ = self.oh.dis(self.z_score_normalize_objectives(init_fitnesses))
        init_pareto = [evaluated_pop_data[i]['fitness'] for i in init_fronts[0]] if init_fronts else []
        self.last_hv = self.hv_indicator.do(
            np.array(self.min_max_normalize_pareto(init_pareto))) if init_pareto else 0.0

        self.last_avg_cd = 0.0
        diversity_data_collector = []

        print("--- SGA-FJSP: 开始主循环 ---")
        for gen in range(self.generation):
            if np.any(np.isnan(self.Pos)) or np.any(np.isnan(self.Vel)):
                print(f"  WARNING: NaN detected at start of Gen {gen + 1}. Resetting...")
                self.Pos[np.isnan(self.Pos)] = np.random.rand()
                self.Vel[np.isnan(self.Vel)] = 0.0

            last_gen_fitnesses = [d['fitness'] for d in evaluated_pop_data]
            last_fronts, _, _ = self.oh.dis(self.z_score_normalize_objectives(last_gen_fitnesses))
            old_pareto_fitness = [evaluated_pop_data[i]['fitness'] for i in last_fronts[0]] if last_fronts and \
                                                                                               last_gen_fitnesses[
                                                                                                   0] else []

            current_state = self._get_state(evaluated_pop_data)
            action = self._choose_action(current_state)

            _, _, sorted_indices = self.oh.dis(self.z_score_normalize_objectives(last_gen_fitnesses))
            evaluated_pop_data = [evaluated_pop_data[i] for i in sorted_indices]
            self.Pos = self.Pos[sorted_indices]
            self.Vel = self.Vel[sorted_indices]
            gBest_pos, worst_pos, Xc = self.Pos[0].copy(), self.Pos[-1].copy(), np.mean(self.Pos, axis=0)

            if action == 0:
                self._perform_sga_exploration_phase(gBest_pos, Xc, worst_pos)
            elif action == 1:
                self._perform_sga_exploitation_phase(gBest_pos, gen)
            elif action == 2:
                self._perform_restart_strategy(gBest_pos)
            elif action == 3:
                self._perform_levy_flight_strategy(gBest_pos, last_fronts)

            self.Pos = np.clip(self.Pos, 0, 1)
            self.Vel = np.clip(self.Vel, self.v_min, self.v_max)

            sga_offspring = self._create_sga_offspring(evaluated_pop_data)
            crossover_offspring = self._create_crossover_offspring(evaluated_pop_data, gen)

            parent_pop_full = [{'pos': self.Pos[i], 'vel': self.Vel[i], **evaluated_pop_data[i]} for i in
                               range(self.popsize)]
            combined_pop = parent_pop_full + sga_offspring + crossover_offspring
            _, _, final_indices = self.oh.dis(self.z_score_normalize_objectives([d['fitness'] for d in combined_pop]))
            next_indices = final_indices[:self.popsize]

            evaluated_pop_data = [combined_pop[idx] for idx in next_indices]
            new_all_fitnesses = [d['fitness'] for d in evaluated_pop_data]
            new_fronts, _, _ = self.oh.dis(self.z_score_normalize_objectives(new_all_fitnesses))

            if new_fronts and len(new_fronts[0]) > 0:
                for p_idx in new_fronts[0]:
                    elite_ind = evaluated_pop_data[p_idx]
                    if random.random() < 0.5:
                        mutated_elite = self.mutation(elite_ind, pm_job=0.05, pm_machine=0.1)
                        m_tran = self.gettran(mutated_elite['job'], mutated_elite['M'])
                        res_e = self.to.caculate(mutated_elite['job'], mutated_elite['M'], mutated_elite['T'], m_tran,
                                                 mutated_elite['wc'], record_fatigue_history=False)
                        e_fit = [res_e[0], res_e[10], res_e[9]]
                        if self._dominates(e_fit, elite_ind['fitness']):
                            mutated_elite['tran'] = m_tran
                            mutated_elite['fitness'] = e_fit
                            evaluated_pop_data[p_idx] = mutated_elite
            self.Pos = np.array([d['pos'] for d in evaluated_pop_data])
            self.Vel = np.array([d['vel'] for d in evaluated_pop_data])
            # 重新获取更新后的前沿
            new_all_fitnesses = [d['fitness'] for d in evaluated_pop_data]
            new_fronts, _, _ = self.oh.dis(self.z_score_normalize_objectives(new_all_fitnesses))
            new_pareto_fitness = [evaluated_pop_data[i]['fitness'] for i in new_fronts[0]] if new_fronts and new_fronts[
                0] else []

            if new_pareto_fitness and np.all(np.isfinite(new_pareto_fitness)):
                norm_pareto = self.min_max_normalize_pareto(new_pareto_fitness)
                current_hv = self.hv_indicator.do(np.array(norm_pareto))
            else:
                current_hv = 0.0

            current_avg_cd = self._calculate_avg_crowding_distance(evaluated_pop_data)
            if current_avg_cd > 0:
                diversity_data_collector.append(current_avg_cd)

            stagnation_broken = False
            if current_hv > self.last_hv + 1e-6 and self.convergence_stagnation_counter > 0:
                stagnation_broken = True

            if stagnation_broken or current_hv > self.last_hv + 1e-6:
                self.convergence_stagnation_counter = 0
            else:
                self.convergence_stagnation_counter += 1

            reward = self._calculate_reward(
                self.last_hv, current_hv,
                self.last_avg_cd, current_avg_cd,
                old_pareto_fitness, new_pareto_fitness,
                stagnation_broken,
            )
            self.reward_history.append(reward)

            next_state = self._get_state(evaluated_pop_data)
            self._update_q_table(current_state, action, reward, next_state)

            self.last_hv = current_hv
            self.last_avg_cd = current_avg_cd

            if self.convergence_stagnation_counter >= self.stagnation_reset_threshold:
                self.epsilon = 0.5
                self.convergence_stagnation_counter = 0

            action_map = {0: "Explore", 1: "Exploit", 2: "Restart", 3: "Lévy-F"}
            print(
                f"Gen {gen + 1:4d}/{self.generation} | State: {current_state}, Action: {action_map[action]:<7s}, Reward: {reward:6.2f}, Epsilon: {self.epsilon:.3f}, HV: {current_hv:.2f}")
            if new_pareto_fitness:
                min_c = min(f[0] for f in new_pareto_fitness)
                min_e = min(f[1] for f in new_pareto_fitness)
                min_s = min(f[2] for f in new_pareto_fitness)
                if gen > 0 and len(fit_every[0]) > 0:
                    if min_c > fit_every[0][-1]: min_c = fit_every[0][-1]
                    if min_e > fit_every[1][-1]: min_e = fit_every[1][-1]
                    if min_s > fit_every[2][-1]: min_s = fit_every[2][-1]
                fit_every[0].append(min_c)
                fit_every[1].append(min_e)
                fit_every[2].append(min_s)
                print(f'    Best Objectives -> Cmax={min_c:.1f}, Eall={min_e:.1f}, Fatigue={min_s:.3f}')
            else:
                if fit_every[0]:
                    fit_every[0].append(fit_every[0][-1])
                    fit_every[1].append(fit_every[1][-1])
                    fit_every[2].append(fit_every[2][-1])

        final_fitnesses = [ind['fitness'] for ind in evaluated_pop_data]
        final_front, _, _ = self.oh.dis(self.z_score_normalize_objectives(final_fitnesses))
        pareto_indices = final_front[0] if final_front else []
        pareto = [evaluated_pop_data[i]['fitness'] for i in pareto_indices]
        pareto_job = np.array([evaluated_pop_data[i]['job'][0] for i in pareto_indices])
        pareto_machine = np.array([evaluated_pop_data[i]['M'][0] for i in pareto_indices])
        pareto_time = np.array([evaluated_pop_data[i]['T'][0] for i in pareto_indices])
        pareto_tran = np.array([evaluated_pop_data[i]['tran'][0] for i in pareto_indices])
        pareto_Wc = np.array([evaluated_pop_data[i]['wc'][0] for i in pareto_indices])
        return pareto, pareto_job, pareto_machine, pareto_time, pareto_tran, fit_every, pareto_Wc, self.reward_history, diversity_data_collector