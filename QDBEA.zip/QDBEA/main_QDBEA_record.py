from small_work import data_deal
from fjsp import FJSP
from multi_opt import mul_op
import copy
import numpy as np
import math
import random

from pymoo.indicators.hv import HV
from plot_objectives import Plotting

from SSGWO import ssgwo
from NSGAII import NSGAII
from SGA_LEVY import SGA_LEVY_FJSP
from memetic1 import Memetic

def distanse(x, y):
    return math.sqrt(sum([pow(a - b, 2) for a, b in zip(x, y)]))

def get_IGD(c, a):
    return sum([min([distanse(i, j) for j in a]) for i in c]) #遍历所有距离 21 34

def parse_list_t_for_comparison(list_t_data):
    op_info = {}
    if list_t_data is None: return op_info
    for machine_idx, ops_on_machine in enumerate(list_t_data):
        if ops_on_machine:
            for op_detail in ops_on_machine:
                if len(op_detail) >= 3:
                    job_id, op_seq, start_time = op_detail[0], op_detail[1], op_detail[2]
                    key = (job_id, op_seq)
                    op_info[key] = {'start': start_time, 'machine': machine_idx}
                # else: 警告信息 (可选)
    return op_info

def sga_levymain():
    oj = data_deal()
    item_ = oj.item
    job_num = item_["int2"]
    machine_num = item_["M"]
    Tmachine, Tmachinetime, tdx, work, tom, int1,int2, M, M_dicr, tran_time,worker,work_num,worker_fatigue,worker_efficiency_factors,worker_recovery = oj.cacu()
    parm_data = [Tmachine, Tmachinetime, tdx, work, M_dicr, tran_time,int1,worker,work_num,worker_fatigue,worker_efficiency_factors,worker_recovery]
    # to=FJSP(10,6,0.5,parm_data)      #工件数，机器数，选择最短机器的概率和mk01的数据
    to = FJSP(job_num, machine_num, parm_data,100,work)
    oh = mul_op()
    ho = SGA_LEVY_FJSP(1000, 100, to, oh, work, job_num, tran_time, M_dicr, parm_data[7], parm_data[8])  # 数50,100,10分别代表迭代的次数、种群的规模、机器数
    # print(work)
    # to是柔性车间模块，oh是多目标模块
    pareto, pareto_job, pareto_machine, pareto_time, pareto_tran, fit_every, WC = ho.sga_total()  # 最后一次迭代的最优解
    first_elements = [lst[0] for lst in pareto]
    # print(first_elements)
    min_index = first_elements.index(min(first_elements))  # 选择完工时间最小的解画甘特图
    sig = min_index
    job, machine = np.array([pareto_job[sig]]), np.array([pareto_machine[sig]])
    machine_time = np.array([pareto_time[sig]])
    trantime = np.array([pareto_tran[sig]])
    wc = np.array([WC[sig]])

    C_finish, _, list_T, list_M, list_S, list_W, tmmw, Wmax,Twork,global_max_fatigue,E_all,fatigue_history =to.caculate(job, machine, machine_time, trantime, wc,record_fatigue_history=True)


    return pareto,oh,to,pareto_job, pareto_machine, pareto_time, pareto_tran, fit_every,WC
def ssgwomain():
    oj = data_deal()
    item_ = oj.item
    job_num = item_["int2"]
    machine_num = item_["M"]
    Tmachine, Tmachinetime, tdx, work, tom, int1,int2, M, M_dicr, tran_time,worker,work_num,worker_fatigue,worker_efficiency_factors,worker_recovery = oj.cacu()
    parm_data = [Tmachine, Tmachinetime, tdx, work, M_dicr, tran_time,int1,worker,work_num,worker_fatigue,worker_efficiency_factors,worker_recovery]
    # to=FJSP(10,6,0.5,parm_data)      #工件数，机器数，选择最短机器的概率和mk01的数据
    to = FJSP(job_num, machine_num, parm_data,100,work)
    _, _, _, _, _,_,_= to.creat_job()
    oh = mul_op()
    ho = ssgwo(1000, 100, to, oh, work, job_num, tran_time, M_dicr, parm_data[7], parm_data[8])  # 数50,100,10分别代表迭代的次数、种群的规模、机器数
    # print(work)
    # to是柔性车间模块，oh是多目标模块
    pareto, pareto_job, pareto_machine, pareto_time, pareto_tran, fit_every, WC = ho.gwo_total()  # 最后一次迭代的最优解
    first_elements = [lst[0] for lst in pareto]
    # print(first_elements)
    min_index = first_elements.index(min(first_elements))  # 选择完工时间最小的解画甘特图
    sig = min_index
    job, machine = np.array([pareto_job[sig]]), np.array([pareto_machine[sig]])
    machine_time = np.array([pareto_time[sig]])
    trantime = np.array([pareto_tran[sig]])
    wc = np.array([WC[sig]])
    C_finish, _, list_T, list_M, list_S, list_W, tmmw, Wmax,Twork,global_max_fatigue,E_all,fatigue_history =to.caculate(job, machine, machine_time, trantime, wc,record_fatigue_history=True)#np.array([WC[i]]))
    _, _, _, WC_W1 = ho.to_MT(job, machine, machine_time, wc)

    # 调用你的绘图函数
    # to.draw_fatigue(WC_W1, list_T, C_finish, global_max_fatigue, E_all, fatigue_history)
    # to.draw_fatigue(WC_W1,list_T,C_finish,global_max_fatigue,E_all,fatigue_history)
    return pareto,oh,to,pareto_job, pareto_machine, pareto_time, pareto_tran, fit_every,WC

def nsgamain():
    oj = data_deal()
    item_ = oj.item
    job_num = item_["int2"]
    machine_num = item_["M"]
    Tmachine, Tmachinetime, tdx, work, tom, int1,int2, M, M_dicr, tran_time,worker,work_num,worker_fatigue,worker_efficiency_factors,worker_recovery = oj.cacu()
    parm_data = [Tmachine, Tmachinetime, tdx, work, M_dicr, tran_time,int1,worker,work_num,worker_fatigue,worker_efficiency_factors,worker_recovery]
    # to=FJSP(10,6,0.5,parm_data)      #工件数，机器数，选择最短机器的概率和mk01的数据
    to = FJSP(job_num, machine_num, parm_data,100,work)
    _, _, _, _, _,_,_= to.creat_job()
    oh = mul_op()
    ho = NSGAII(1000, 100, to, oh, work, job_num, tran_time, M_dicr, parm_data[7], parm_data[8])  # 数50,100,10分别代表迭代的次数、种群的规模、机器数
    # print(work)
    # to是柔性车间模块，oh是多目标模块
    pareto, pareto_job, pareto_machine, pareto_time, pareto_tran, fit_every, WC = ho.nsga2_total()  # 最后一次迭代的最优解
    first_elements = [lst[0] for lst in pareto]
    # print(first_elements)
    min_index = first_elements.index(min(first_elements))  # 选择完工时间最小的解画甘特图
    sig = min_index
    job, machine = np.array([pareto_job[sig]]), np.array([pareto_machine[sig]])
    machine_time = np.array([pareto_time[sig]])
    trantime = np.array([pareto_tran[sig]])
    wc = np.array([WC[sig]])
    C_finish, _, list_T, list_M, list_S, list_W, tmmw, Wmax,Twork,global_max_fatigue,E_all,fatigue_history =to.caculate(job, machine, machine_time, trantime, wc,record_fatigue_history=True)#np.array([WC[i]]))
    return pareto,oh,to,pareto_job, pareto_machine, pareto_time, pareto_tran, fit_every,WC

def memeticmain():
    oj = data_deal()
    item_ = oj.item
    job_num = item_["int2"]  # 总工件数
    machine_num = item_["M"]  # 机器数量
    Tmachine, Tmachinetime, tdx, work, tom, int1, int2, M, M_dicr, tran_time, worker, work_num, worker_fatigue, worker_efficiency_factors, worker_recovery = oj.cacu()
    parm_data = [Tmachine, Tmachinetime, tdx, work, M_dicr, tran_time, int1, worker, work_num, worker_fatigue,
                 worker_efficiency_factors, worker_recovery]
    # to=FJSP(10,6,0.5,parm_data)      #工件数，机器数，选择最短机器的概率和mk01的数据
    to = FJSP(job_num, machine_num, parm_data, 100, work)
    oh = mul_op()
    ho = Memetic(1000, 100, to, oh, work, job_num, tran_time, M_dicr, parm_data[7],
                       parm_data[8])  # 数50,100,10分别代表迭代的次数、种群的规模、机器数
    # print(work)
    # to是柔性车间模块，oh是多目标模块
    pareto, pareto_job, pareto_machine, pareto_time, pareto_tran, fit_every, WC = ho.memetic_total()  # 最后一次迭代的最优解
    first_elements = [lst[0] for lst in pareto]
    # print(first_elements)
    min_index = first_elements.index(min(first_elements))  # 选择完工时间最小的解画甘特图
    sig = min_index
    job, machine = np.array([pareto_job[sig]]), np.array([pareto_machine[sig]])
    machine_time = np.array([pareto_time[sig]])
    trantime = np.array([pareto_tran[sig]])
    wc = np.array([WC[sig]])

    C_finish, _, list_T, list_M, list_S, list_W, tmmw, Wmax, Twork, global_max_fatigue, E_all, fatigue_history = to.caculate(
        job, machine, machine_time, trantime, wc, record_fatigue_history=True)  # np.array([WC[i]]))

    return pareto, oh, to, pareto_job, pareto_machine, pareto_time, pareto_tran, fit_every, WC

def calculate_igd(pf_found, pf_true):
    """计算给定解集 pf_found相对于真实前沿 pf_true 的 IGD"""
    if not pf_found or not pf_true:
        return float('inf')
    pf_found_arr = np.array(pf_found)
    pf_true_arr = np.array(pf_true)
    distances = [np.min(np.sqrt(np.sum((pf_found_arr - p_true)**2, axis=1))) for p_true in pf_true_arr]
    return np.mean(distances)

def calculate_hv(pf_found, ref_point):
    """计算给定解集 pf_found 的 HV"""
    if not pf_found:
        return 0.0
    hv_indicator = HV(ref_point=ref_point)
    front_array = np.array(pf_found)
    if not np.all(np.isfinite(front_array)):
        print("  WARNING: Non-finite values detected, cannot calculate HV.")
        return 0.0
    return hv_indicator.do(front_array)


# 定义一个辅助函数来更新最佳方案追踪器
def update_best_solution(algo_name, pareto_solutions, pareto_job, pareto_machine, pareto_wc, pareto_time, pareto_tran):
    if not pareto_solutions:
        return

    # 找到本次运行Pareto解集中Cmax最小的那个解
    cmax_values = [s[0] for s in pareto_solutions]
    min_cmax_in_run = min(cmax_values)

    # 检查是否比历史最佳还好
    if min_cmax_in_run < best_solution_tracker[algo_name]['best_cmax']:
        print(f"  *** New Best Cmax found for {algo_name}: {min_cmax_in_run:.2f} (Run {i + 1}) ***")
        # 更新记录
        best_solution_tracker[algo_name]['best_cmax'] = min_cmax_in_run

        # 找到并存储这个最佳解的完整调度方案
        best_index = cmax_values.index(min_cmax_in_run)
        best_solution_tracker[algo_name]['solution'] = {
            'job': pareto_job[best_index],
            'machine': pareto_machine[best_index],
            'time': pareto_time[best_index],
            'tran': pareto_tran[best_index],
            'wc': pareto_wc[best_index]
        }


if __name__ == '__main__':
    # --- 1. 实验设置 ---
    num_runs = 10

    # --- 2. 新增：独立记录每次运行【最终最优值】的字典 (用于算 P 值) ---
    final_metrics = {
        "SS-GWO": {'Cmax': [], 'Energy': [], 'Fatigue': []},
        "ENSGA-II": {'Cmax': [], 'Energy': [], 'Fatigue': []},
        "MANL": {'Cmax': [], 'Energy': [], 'Fatigue': []},
        "Q-ISGA": {'Cmax': [], 'Energy': [], 'Fatigue': []}
    }

    # 用于画图和汇总的容器
    all_runs_ssgwo, all_runs_nsga, all_runs_qisga, all_runs_memetic = [], [], [], []
    fit_histories_ssgwo, fit_histories_nsga, fit_histories_qisga, fit_histories_memetic = [], [], [], []

    best_solution_tracker = {
        "SS-GWO": {'best_cmax': float('inf'), 'solution': None},
        "ENSGA-II": {'best_cmax': float('inf'), 'solution': None},
        "MANL": {'best_cmax': float('inf'), 'solution': None},
        "Q-ISGA": {'best_cmax': float('inf'), 'solution': None},
    }


    # 提取单次运行中 Pareto 前沿上各个目标的最小值
    def extract_final_best(pareto_front):
        if not pareto_front: return float('inf'), float('inf'), float('inf')
        pf_arr = np.array(pareto_front)
        return np.min(pf_arr[:, 0]), np.min(pf_arr[:, 1]), np.min(pf_arr[:, 2])


    print(f"--- Starting Comparison Run for {num_runs} times ---")
    for i in range(num_runs):
        print(f"\n" + "=" * 20 + f" Run {i + 1}/{num_runs} " + "=" * 20)

        # ---------------- SS-GWO ----------------
        print("Running SS-GWO...")
        pareto_ssgwo, _, _, pareto_job_s, pareto_machine_s, pareto_time_s, pareto_tran_s, fit_ssgwo, pareto_wc_s = ssgwomain()
        all_runs_ssgwo.extend(pareto_ssgwo)
        update_best_solution("SS-GWO", pareto_ssgwo, pareto_job_s, pareto_machine_s, pareto_wc_s, pareto_time_s,
                             pareto_tran_s)
        fit_histories_ssgwo.append(fit_ssgwo)
        # 记录这次 Run 的最优数据
        c, e, f = extract_final_best(pareto_ssgwo)
        final_metrics["SS-GWO"]['Cmax'].append(c)
        final_metrics["SS-GWO"]['Energy'].append(e)
        final_metrics["SS-GWO"]['Fatigue'].append(f)

        # ---------------- ENSGA-II ----------------
        print("Running ENSGA-II...")
        pareto_nsga, _, _, pareto_job_n, pareto_machine_n, pareto_time_n, pareto_tran_n, fit_nsga, pareto_wc_n = nsgamain()
        all_runs_nsga.extend(pareto_nsga)
        update_best_solution("ENSGA-II", pareto_nsga, pareto_job_n, pareto_machine_n, pareto_wc_n, pareto_time_n,
                             pareto_tran_n)
        fit_histories_nsga.append(fit_nsga)
        c, e, f = extract_final_best(pareto_nsga)
        final_metrics["ENSGA-II"]['Cmax'].append(c)
        final_metrics["ENSGA-II"]['Energy'].append(e)
        final_metrics["ENSGA-II"]['Fatigue'].append(f)

        # ---------------- MANL ----------------
        print("Running Memetic (MANL)...")
        pareto_memetic, _, to, pareto_job_mm, pareto_machine_mm, pareto_time_mm, pareto_tran_mm, fit_memetic, pareto_wc_mm = memeticmain()
        all_runs_memetic.extend(pareto_memetic)
        update_best_solution("MANL", pareto_memetic, pareto_job_mm, pareto_machine_mm, pareto_wc_mm, pareto_time_mm,
                             pareto_tran_mm)
        fit_histories_memetic.append(fit_memetic)
        c, e, f = extract_final_best(pareto_memetic)
        final_metrics["MANL"]['Cmax'].append(c)
        final_metrics["MANL"]['Energy'].append(e)
        final_metrics["MANL"]['Fatigue'].append(f)

        # ---------------- Q-ISGA ----------------
        print("Running Q-ISGA...")
        # 注意：这里调用的是加入了 QL 的 q_isga_main()
        pareto_qisga, _, to, pareto_job_q, pareto_machine_q, pareto_time_q, pareto_tran_q, fit_qisga, pareto_wc_q = q_isga_main()
        all_runs_qisga.extend(pareto_qisga)
        update_best_solution("Q-ISGA", pareto_qisga, pareto_job_q, pareto_machine_q, pareto_wc_q, pareto_time_q,
                             pareto_tran_q)
        fit_histories_qisga.append(fit_qisga)
        c, e, f = extract_final_best(pareto_qisga)
        final_metrics["Q-ISGA"]['Cmax'].append(c)
        final_metrics["Q-ISGA"]['Energy'].append(e)
        final_metrics["Q-ISGA"]['Fatigue'].append(f)
    # ==========================================================
    # === 模块 1：计算 p-value 并导出统计结果 CSV ===
    # ==========================================================
    print("\n" + "=" * 60)
    print(f" 📊 算法最终性能统计分析 ({num_runs}次独立运行) & Wilcoxon检验")
    print("=" * 60)
    try:
        from scipy.stats import ranksums
        import pandas as pd

        base_algo = "Q-ISGA"
        compare_algos = ["SS-GWO", "ENSGA-II", "MANL"]
        metrics_names = ["Cmax", "Energy", "Fatigue"]
        stat_results = []

        for metric in metrics_names:
            print(f"\n--- 目标指标: {metric} ---")
            base_data = np.array(final_metrics[base_algo][metric])
            base_data = base_data[base_data != float('inf')]  # 清除坏数据

            if len(base_data) == 0:
                continue

            b_mean, b_std = np.mean(base_data), np.std(base_data)
            print(f"  [Base] {base_algo:<10}: Mean = {b_mean:<10.2f}, Std = {b_std:<10.2f}")
            stat_results.append(
                {'Algorithm': base_algo, 'Metric': metric, 'Mean': b_mean, 'Std': b_std, 'p-value': '-'})

            for algo in compare_algos:
                comp_data = np.array(final_metrics[algo][metric])
                comp_data = comp_data[comp_data != float('inf')]
                if len(comp_data) == 0: continue

                c_mean, c_std = np.mean(comp_data), np.std(comp_data)

                # 计算 p-value
                if len(base_data) > 1 and len(comp_data) > 1:
                    _, p_val = ranksums(base_data, comp_data)
                else:
                    p_val = float('nan')

                sig_mark = "*" if p_val < 0.05 else ""  # 加星号代表有显著性差异
                print(
                    f"  [Comp] {algo:<10}: Mean = {c_mean:<10.2f}, Std = {c_std:<10.2f} | p-value = {p_val:.4e} {sig_mark}")
                stat_results.append(
                    {'Algorithm': algo, 'Metric': metric, 'Mean': c_mean, 'Std': c_std, 'p-value': p_val})

        df_stats = pd.DataFrame(stat_results)
        df_stats.to_csv("Statistical_Significance_Results.csv", index=False, encoding='utf-8-sig')
        print("\n💾 统计检验结果已保存至: Statistical_Significance_Results.csv")
    except ImportError:
        print("\n⚠️ 缺少 scipy 或 pandas 库，无法自动计算 P 值并导出 CSV。请执行 pip install scipy pandas。")

    # ==========================================================
    # === 模块 2：汇总 HV / IGD 等多目标指标 ===
    # ==========================================================
    print("\n--- Constructing PF_true from all runs ---")
    combined_pf = all_runs_nsga + all_runs_qisga + all_runs_ssgwo + all_runs_memetic
    front, _, _ = mul_op().dis(combined_pf)
    PF_true = np.array(combined_pf)[front[0]].tolist()

    all_solutions_arr = np.array(combined_pf)
    min_values = np.min(all_solutions_arr, axis=0)
    max_values = np.max(all_solutions_arr, axis=0)
    norm_ref_point = np.array([1.1, 1.1, 1.1])

    algorithms_results = {
        "SS-GWO": all_runs_ssgwo,
        "ENSGA-II": all_runs_nsga,
        "MANL": all_runs_memetic,
        "Q-ISGA": all_runs_qisga
    }

    for algo_name, pf_found in algorithms_results.items():
        print(f"\n--- Multi-objective Metrics for {algo_name} ---")
        if not pf_found: continue

        norm_pf_found = (np.array(pf_found) - min_values) / (max_values - min_values)
        norm_pf_true = (np.array(PF_true) - min_values) / (max_values - min_values)

        igd_value = calculate_igd(norm_pf_found.tolist(), norm_pf_true.tolist())
        hv_value = calculate_hv(norm_pf_found.tolist(), norm_ref_point)
        print(f"  IGD (normalized): {igd_value:.6f}")
        print(f"  HV (normalized):  {hv_value:.6f}")

    # ==========================================================
    # === 模块 3：导出迭代收敛曲线，并进行强制 Swap 画图 ===
    # ==========================================================
    try:
        import pandas as pd

        print("\n--- Saving Convergence Curve Data ---")
        # 为保存数据构建原始字典
        all_histories_dict = {
            'SS-GWO': fit_histories_ssgwo,
            'ENSGA-II': fit_histories_nsga,
            'MANL': fit_histories_memetic,
            'Q-ISGA': fit_histories_qisga
        }

        num_generations = len(fit_histories_qisga[0][0])
        export_data = {'Generation': range(1, num_generations + 1)}

        for algo_name, histories in all_histories_dict.items():
            if not histories: continue
            histories_array = np.array(histories)
            for obj_idx, obj_name in enumerate(["Cmax", "Energy", "Fatigue"]):
                obj_runs_data = histories_array[:, obj_idx, :]
                avg_curve = np.mean(obj_runs_data, axis=0)  # 沿着 run 维度求平均
                export_data[f"{algo_name}_{obj_name}_Avg"] = avg_curve

        df_export = pd.DataFrame(export_data)
        df_export.to_csv("4_Algos_Convergence_Data.csv", index=False, encoding='utf-8-sig')
        print("💾 迭代曲线平均数据已保存至: 4_Algos_Convergence_Data.csv (推荐使用 Origin 制图)")
    except Exception as e:
        pass

    print("\n" + "=" * 50)

    # 画图前的深拷贝
    plot_histories_ssgwo = copy.deepcopy(fit_histories_ssgwo)
    plot_histories_nsga = copy.deepcopy(fit_histories_nsga)
    plot_histories_memetic = copy.deepcopy(fit_histories_memetic)
    plot_histories_qisga = copy.deepcopy(fit_histories_qisga)

    # 绘图
    pa = Plotting()
    pa.plot_convergence_comparison_average(
        (plot_histories_ssgwo, 'SS-GWO'),
        (plot_histories_nsga, 'ENSGA-II'),
        (plot_histories_memetic, 'MANL'),
        (plot_histories_qisga, 'Q-ISGA'),
        save_path_prefix="4_algos_comparison"
    )