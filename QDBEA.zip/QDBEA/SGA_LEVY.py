import numpy as np
import random
import math
import copy
from itertools import chain
from ZGWO import zgwo
#   SGA+交叉变异+莱维飞行
class SGA_LEVY_FJSP:  # 这里我们创建一个新类，而不是直接修改zgwo
    def __init__(self, generation, popsize, to, oh, work, job_num, tran_time, M_dicr, Work_arr, work_num):
        # --- 所有初始化参数与zgwo完全相同 ---
        self.generation = generation
        self.popsize = popsize
        self.to = to
        self.oh = oh
        self.work = work
        self.job_num = job_num
        self.tran_time = tran_time
        self.M_dicr = M_dicr
        self.Work_arr = Work_arr
        self.work_num = work_num

        # *** SGA算法需要的额外状态：速度(Vel) ***
        self.Vel = np.zeros((self.popsize, len(self.work)))
    def to_MT(self, W1, M1, T1, WC):
        Ma_W1, Tm_W1, WCross, WC_W1 = [], [], [], []
        for i in range(self.job_num):
            Ma_W1.append([]), Tm_W1.append([]), WCross.append([]), WC_W1.append([])
        for i in range(W1.shape[1]):
            signal1 = int(W1[0, i])
            Ma_W1[signal1].append(M1[0, i]), Tm_W1[signal1].append(T1[0, i]), WC_W1[signal1].append(WC[0, i]);
            index = np.random.randint(0, 2, 1)[0]
            WCross[signal1].append(index)
        return Ma_W1, Tm_W1, WCross, WC_W1

    def back_MT(self, W1, Ma_W1, Tm_W1, WC1):
        memory1 = np.zeros((1, self.job_num), dtype=int)
        m1, t1, wc = np.zeros((1, W1.shape[1])), np.zeros((1, W1.shape[1])), np.zeros((1, W1.shape[1]))
        for i in range(W1.shape[1]):
            signal1 = int(W1[0, i])
            m1[0, i] = Ma_W1[signal1][memory1[0, signal1]]
            t1[0, i] = Tm_W1[signal1][memory1[0, signal1]]
            wc[0][i] = WC1[signal1][memory1[0, signal1]]
            memory1[0, signal1] += 1
        return m1, t1, wc

    def mutation(self, individual_data, pm_job=0.1, pm_machine=0.2):
        """
        修复版变异算子：包含工序交换变异和机器重分配变异。
        加入全局校验逻辑，彻底杜绝 M 和 T 不匹配或非法的错误。
        """
        new_data = copy.deepcopy(individual_data)
        job_seq = new_data['job'].flatten()
        num_ops = len(job_seq)

        # --- 1. 工序变异 (只交换工件序列，绝不连带交换 M/T/wc) ---
        if random.random() < pm_job:
            idx1, idx2 = random.sample(range(num_ops), 2)
            if job_seq[idx1] != job_seq[idx2]:
                job_seq[idx1], job_seq[idx2] = job_seq[idx2], job_seq[idx1]
                new_data['job'] = job_seq.reshape(1, -1)
                # 注意：此时 M, T, wc 已经和 job 错位了，我们将在第 3 步统一修复

        # --- 2. 机器变异 (常规随机选机器) ---
        if random.random() < pm_machine:
            op_idx = random.randint(0, num_ops - 1)
            job_id = int(new_data['job'][0, op_idx])
            op_order = np.where(new_data['job'][0] == job_id)[0].tolist().index(op_idx)

            available_machines = self.to.Tmachine[job_id][op_order]
            if len(available_machines) > 1:
                new_m_1based = random.choice(available_machines)
                new_data['M'][0, op_idx] = new_m_1based - 1
                # 这里暂时不更新 T 和 wc，统一交由第 3 步处理

        # --- 3. 全局对齐与修复 (核心防错逻辑) ---
        new_M = new_data['M']
        new_T = np.zeros_like(new_data['T'])
        new_wc = new_data['wc']
        op_counters = {job_id: 0 for job_id in range(self.job_num)}

        # 从左到右遍历新的工序序列，确保每个位置的 M, T, wc 都是合法且对应的
        for i in range(num_ops):
            job_id = int(new_data['job'][0, i])
            op_seq = op_counters[job_id]

            available_machines = self.to.Tmachine[job_id][op_seq]
            available_times = self.to.Tmachinetime[job_id][op_seq]

            current_m_0based = int(new_M[0, i])
            current_m_1based = current_m_0based + 1

            # 校验 1: 检查当前机器是否合法
            if current_m_1based in available_machines:
                # 如果合法，直接查出正确的加工时间 T
                m_index = available_machines.index(current_m_1based)
                new_T[0, i] = available_times[m_index]
            else:
                # 如果因为工序交换导致机器不合法，随机分配一台合法的新机器
                new_m_1based = random.choice(available_machines)
                new_m_0based = new_m_1based - 1
                m_index = available_machines.index(new_m_1based)

                new_M[0, i] = new_m_0based
                new_T[0, i] = available_times[m_index]

                # 机器换了，工人也得跟着换合法的
                workers = self.Work_arr[new_m_0based]
                new_wc[0, i] = random.choice(workers) if len(workers) > 0 else 0

            op_counters[job_id] += 1

        # 将修复并对齐后的数据写回
        new_data['M'] = new_M
        new_data['T'] = new_T
        new_data['wc'] = new_wc

        return new_data

    def _dominates(self, p, q):
        """判断解p是否支配解q"""
        return all(x <= y for x, y in zip(p, q)) and any(x < y for x, y in zip(p, q))
    def mac_cross(self,Ma_W1,Tm_W1,Ma_W2,Tm_W2,WCross,WC_W1,WC_W2):  #机器均匀交叉
        MC1,MC2,TC1,TC2=[],[],[],[]
        TR1,TR2,trtime=[],[],[]
        WC1,WC2 = [],[]
        for i in range(self.job_num):
            MC1.append([]),MC2.append([]),TC1.append([]),TC2.append([]),WC1.append([]),WC2.append([])
            c =len((WCross[i]))
            for j in range(c):
                if(WCross[i][j]==0):  #为0时继承另一个父代的加工机器选择
                    MC1[i].append(Ma_W1[i][j]), MC2[i].append(Ma_W2[i][j]), TC1[i].append(Tm_W1[i][j]), TC2[i].append(Tm_W2[i][j])#,WC1[i].append(float(self.select_different_number(self.Work_arr[int(Ma_W1[i][j])], WC_W1[i][j]))),WC2[i].append(float(self.select_different_number(self.Work_arr[int(Ma_W1[i][j])], WC_W2[i][j])))#, WC1[i].append(WC_W1[i][j]), WC2[i].append(WC_W2[i][j])
                else:                #为1时继承父代的机器选择
                    MC2[i].append(Ma_W1[i][j]), MC1[i].append(Ma_W2[i][j]), TC2[i].append(Tm_W1[i][j]), TC1[i].append(Tm_W2[i][j])#,WC2[i].append(float(self.select_different_number(self.Work_arr[int(Ma_W1[i][j])], WC_W1[i][j]))),WC1[i].append(float(self.select_different_number(self.Work_arr[int(Ma_W1[i][j])], WC_W2[i][j])))#, WC2[i].append(WC_W1[i][j]), WC1[i].append(WC_W2[i][j])
            for z in range(c):
                prob = random.random()
                if prob < 0.99:
                    if (WCross[i][z] == 0):
                        WC1[i].append(WC_W1[i][z]), WC2[i].append(WC_W2[i][z])
                    else:
                        WC2[i].append(WC_W1[i][z]), WC1[i].append(WC_W2[i][z])
                else:
                    if (WCross[i][z] == 0):
                        WC1[i].append(float(self.select_different_number(self.Work_arr[int(Ma_W1[i][z])], WC_W1[i][z])))
                        WC2[i].append(float(self.select_different_number(self.Work_arr[int(Ma_W1[i][z])], WC_W2[i][z])))
                    else:
                        WC2[i].append(float(self.select_different_number(self.Work_arr[int(Ma_W1[i][z])], WC_W1[i][z])))
                        WC1[i].append(float(self.select_different_number(self.Work_arr[int(Ma_W1[i][z])], WC_W2[i][z])))

        return MC1,TC1,MC2,TC2,WC1,WC2
    def select_different_number(self,list, number):
        while True:
            if len(list) == 1:
                return number
            else:
                random_number = np.random.choice(list)
                if random_number != number:
                    return random_number
    def POX_improve(self, Father_1, Father_2):
        """
        修正后的POX交叉操作。
        确保子代1和子代2使用互补的工件集进行交叉，避免长度不匹配问题。
        """
        # 确保输入是1D array
        f1 = Father_1.flatten().copy()
        f2 = Father_2.flatten().copy()

        n_jobs = self.job_num
        n_ops = len(self.work)

        # 1. 随机将所有工件分为两个不相交的集合 J1 和 J2
        all_jobs = list(range(n_jobs))
        random.shuffle(all_jobs)
        # 随机选择一个分割点
        split_point = random.randint(1, n_jobs - 1)
        J_set_1 = set(all_jobs[:split_point])
        J_set_2 = set(all_jobs[split_point:])

        # 初始化子代
        children_1 = np.full(n_ops, -1, dtype=int)  # 使用-1作为占位符，避免与工件0混淆
        children_2 = np.full(n_ops, -1, dtype=int)

        # 2. 生成子代1
        # 从父代1中复制J_set_1的工件，保持其原始位置
        for i in range(n_ops):
            if f1[i] in J_set_1:
                children_1[i] = f1[i]

        # 从父代2中提取J_set_2的工件，保持其相对顺序
        f2_remaining = [op for op in f2 if op in J_set_2]

        # 将f2_remaining填充到children_1的空位中
        j = 0
        for i in range(n_ops):
            if children_1[i] == -1:
                children_1[i] = f2_remaining[j]
                j += 1

        # 3. 生成子代2
        # 从父代2中复制J_set_2的工件，保持其原始位置
        for i in range(n_ops):
            if f2[i] in J_set_2:
                children_2[i] = f2[i]

        # 从父代1中提取J_set_1的工件，保持其相对顺序
        f1_remaining = [op for op in f1 if op in J_set_1]

        # 将f1_remaining填充到children_2的空位中
        j = 0
        for i in range(n_ops):
            if children_2[i] == -1:
                children_2[i] = f1_remaining[j]
                j += 1

        return children_1, children_2

    def z_score_normalize_objectives(self, objectives_list):
        if not objectives_list: return []
        obj_array = np.array(objectives_list, dtype=float)
        mean_val = np.mean(obj_array, axis=0)
        std_val = np.std(obj_array, axis=0)
        std_val[std_val == 0] = 1  # Avoid division by zero
        normalized_obj_array = (obj_array - mean_val) / std_val
        return normalized_obj_array.tolist()

    def gettran(self, job, machine):
        trantime = np.ones((1, job.shape[1]))
        index = []
        k = 0
        for i in range(self.job_num):
            for j in range(len(job[0])):
                if job[0][j] == i:
                    k += 1
                    index.append(j)
                    if k > 1:
                        a = machine[0][j]
                        b = machine[0][index[-2]]
                        x = list(self.M_dicr[int(a)])[0] - 1
                        y = list(self.M_dicr[int(b)])[0] - 1
                        trantime[0][j] = self.tran_time[y][x]
                    else:
                        trantime[0][j] = 0
            index = []
            k = 0
        return trantime

    def update_position_vector(self, original_positions, new_order):
        n = len(new_order)
        # 基础检查
        if len(original_positions) != len(self.work):
            raise ValueError(
                f"长度不匹配! len(original_positions)={len(original_positions)}, "
                f"len(self.work)={len(self.work)}"
            )

        # 1. 构建工序到原始位置值的映射并降序排序
        position_map = {}
        for order, pos in zip(self.work, original_positions):
            if order not in position_map:
                position_map[order] = []
            position_map[order].append(pos)

        for order in position_map:
            position_map[order].sort(reverse=True)  # 工序内部降序排序

        # 2. 计算全局基础值 (线性递减)
        base_values = [n - i for i in range(n)]  # 索引0: n, 索引1: n-1, ... 索引n-1: 1

        # 3. 计算每个工序的偏移量范围 (确保|偏移| < 1)
        epsilon = 0.5  # 最大偏移量幅度 (<1)
        offset_map = {}
        for order, positions in position_map.items():
            k = len(positions)
            # 生成偏移量: 原始值最大的分配最大偏移，依次减小
            offsets = [epsilon * (1 - i / k) for i in range(k)]
            offset_map[order] = offsets

        # 4. 生成新位置向量
        new_positions = []
        order_count = {order: 0 for order in position_map}  # 工序出现计数器

        for i, order in enumerate(new_order):
            if order not in position_map:
                raise ValueError(f"工序编码 {order} 不在原始工序中")

            count = order_count[order]
            # 获取当前工序的偏移量 (若出现次数超原始值，取最小偏移)
            if count < len(offset_map[order]):
                offset = offset_map[order][count]
            else:
                offset = 0  # 或 epsilon * (1 - (len(offset_map[order])-1)/len(offset_map[order])

            new_pos = base_values[i] + offset
            new_positions.append(new_pos)
            order_count[order] += 1

        return new_positions

    def _get_hashable_key(self, item):
        """将项目转换为可哈希的键，特别是将 ndarray 转换为元组。"""
        if isinstance(item, np.ndarray):
            return tuple(item.flatten()) # flatten 以处理多维数组，然后转为元组
        elif isinstance(item, list): # 如果列表也可能作为键（不常见，但以防万一）
             # 注意：如果列表内还有不可哈希的元素，需要递归转换
            return tuple(item)
        return item

    def _brownian_motion(self, dim):
        # (SGA算法需要的辅助函数)
        T = 1.0
        r = T / dim
        dw = np.sqrt(r) * np.random.randn(1, dim)
        return np.cumsum(dw)

    def levy_flight_step(self, beta=1.5, alpha=0.1, size=None):
        """
        生成莱维飞行步长。

        :param beta: Lévy分布的指数参数, 通常在(0, 2]之间，1.5是常用值。
        :param alpha: 步长缩放因子，控制步长的大小。
        :param size: 生成步长的维度。
        :return: 莱维飞行步长向量。
        """
        try:
            # Mantegna's algorithm for generating Lévy stable random numbers
            num = math.gamma(1 + beta) * math.sin(math.pi * beta / 2)
            den = math.gamma((1 + beta) / 2) * beta * (2 ** ((beta - 1) / 2))
            sigma_u = (num / den) ** (1 / beta)
        except ValueError:
            sigma_u = 0.6966  # 近似值 for beta=1.5
        sigma_v = 1

        # 生成 u 和 v
        u = np.random.normal(0, sigma_u, size)
        v = np.random.normal(0, sigma_v, size)

        # 添加一个小的 epsilon 防止 v 为 0 导致除零错误
        step = u / ((np.abs(v) + 1e-10) ** (1 / beta))

        return alpha * step

    # --- 核心修改：sga_total() 方法 ---
    def sga_total(self):
        """
        使用SGA算法来求解多目标FJSP的主函数。
        """
        # --- 1. 初始化阶段 ---
        # `evaluated_pop_data` 是我们的主种群数据结构
        # 它是一个列表，每个元素是一个字典: {'job':..., 'M':..., 'T':..., 'wc':..., 'job_init':..., 'fitness':...}
        evaluated_pop_data = []
        # `Pos` (即 `job_init_vectors`) 是SGA直接操作的连续位置向量
        Pos = np.zeros((self.popsize, len(self.work)))

        print("--- SGA-FJSP: 初始化种群 ---")
        try:
            work_job, work_M, work_T, work_tran, _, job_init, work_wc = self.to.create_job_ensga(
                self.popsize, [0.2, 0.5, 0.2, 0.1]
            )
        except AttributeError:
            # 如果没找到这个方法，则回退到原来的随机初始化
            work_job, work_M, work_T, work_tran, _, job_init, work_wc = self.to.creat_job()
        for i in range(self.popsize):
            # 调用解码器和适应度函数
            C_finish, _, list_T, _, _, _, _, _, _, global_max_fatigue, E_all= self.to.caculate(
                work_job[i:i + 1], work_M[i:i + 1], work_T[i:i + 1], work_tran[i:i + 1], work_wc[i:i + 1],
                record_fatigue_history=False
            )
            fitness = [C_finish, E_all, global_max_fatigue]
            evaluated_pop_data.append({
                'job': work_job[i:i + 1], 'M': work_M[i:i + 1], 'T': work_T[i:i + 1],
                'tran': work_tran[i:i + 1], 'wc': work_wc[i:i + 1],
                'job_init': job_init[i:i + 1], 'fitness': fitness, 'velocity': self.Vel[i:i+1]
            })
            Pos[i, :] = job_init[i:i + 1]  # 填充SGA的位置向量

        fit_every = [[], [], []]  # 用于记录每代最优目标

        # --- 2. SGA 主循环 ---
        print("--- SGA-FJSP: 开始主循环 ---")
        for gen in range(self.generation):
            # 【修改】引入莱维飞行和SGA的概率性选择
            p_levy = 0.2  # 20%的概率执行莱维飞行
            # 1. 检测停滞状态
            stagnation_counter = 0
            if gen > 0 and fit_every[0][-1] >= fit_every[0][max(0, gen - 10)]:  # 假设10代Cmax无改进
                stagnation_counter += 1
            else:
                stagnation_counter = 0

            # 寻找一个引导者(gBest)，两个策略都会用到
            all_fitnesses = [ind['fitness'] for ind in evaluated_pop_data]
            Z_answer = self.z_score_normalize_objectives(all_fitnesses)
            fronts, _, _ = self.oh.dis(Z_answer)
            if not fronts or not fronts[0]:
                gBest_idx = np.random.randint(0, self.popsize)
            else:
                gBest_idx = random.choice(fronts[0])
            gBest_pos = evaluated_pop_data[gBest_idx]['job_init'].flatten()

            if np.random.rand() < p_levy:
                # ==================================
                # 【策略一：执行莱维飞行】
                # ==================================
                print(f"Gen {gen + 1}: Executing Lévy Flight Strategy...")

                # 动态调整alpha，早期跳跃大，后期跳跃小
                # alpha_levy = 0.2 * (1 - gen / self.generation) + 0.01
                # 2. 根据停滞状态动态调整p_levy
                if stagnation_counter > 10:  # 如果连续停滞超过10代
                    alpha_levy = 0.6  # 大幅增加莱维飞行概率，强制进行破坏性探索
                    print(f"Gen {gen + 1}: Stagnation detected! Increasing Lévy probability to {p_levy}")
                elif stagnation_counter > 5:
                    alpha_levy = 0.3  # 适当增加
                else:
                    alpha_levy = 0.1  # 在正常情况下，降低概率
                # 策略A：默认围绕gBest (保持不变)
                guide_pos = gBest_pos

                # 策略B：有一定概率选择一个“非精英”作为引导者
                if np.random.rand() < 0.3:  # 30%的概率选择一个差的解来引导“逃离”
                    # 从种群的后半部分随机选择一个体
                    bad_guide_idx = np.random.randint(self.popsize // 2, self.popsize)
                    guide_pos = Pos[bad_guide_idx]
                    # print(f"    Lévy Flight is guided by a non-elite individual.")

                step_sizes = self.levy_flight_step(beta=1.5, alpha=alpha_levy, size=Pos.shape)
                Pos = Pos + step_sizes * (guide_pos - Pos)  # 围绕引导者进行莱维飞行
                self.Vel = np.zeros_like(self.Vel)

            else:
                # ==================================
                # 【策略二：执行原始SGA更新】
                # ==================================
                # a. 更新速度
                coe_t = (gen + 1) / self.generation
                coe = (4 * coe_t) / np.exp(4 * coe_t) if coe_t > 0 else 0
                fi = np.random.rand() * 2 * np.pi  # 随机生成角度
                acc = ((gBest_pos - Pos) - 1.29 * (self.Vel ** 2) * np.sin(fi)) * 1e-2  # 加速度
                self.Vel = coe * self.Vel + acc

                # b. 排序并重组种群 (基于非支配排序)
                all_fitnesses_sort = [ind['fitness'] for ind in evaluated_pop_data]
                Z_answer_sort = self.z_score_normalize_objectives(all_fitnesses_sort)
                _, _, sorted_indices = self.oh.dis(Z_answer_sort)
                Pos = Pos[sorted_indices]
                self.Vel = self.Vel[sorted_indices]
                evaluated_pop_data = [evaluated_pop_data[i] for i in sorted_indices]
                for i in range(self.popsize):
                    evaluated_pop_data[i]['velocity'] = self.Vel[i:i + 1]

                # c. 计算加权质心 Xc (基于排名)
                weights = np.arange(self.popsize, 0, -1)
                Xc = np.sum(Pos * weights[:, np.newaxis], axis=0) / np.sum(weights)

                # d. 基础位置更新
                Pos = Pos + self.Vel

                # e. 阶段切换与分层/利用更新
                if fi < np.pi:  # 探索阶段
                    a, b, c = 4 * np.random.rand() - 2, 3 * np.random.rand() - 1.5, 2 * np.random.rand() - 1
                    n1, n2 = int(self.popsize / 5), int(4 * self.popsize / 5)
                    worst_pos = Pos[-1]
                    Pos[:n1] += a * (gBest_pos - Pos[:n1])
                    Pos[n1:n2] += a * (gBest_pos - Pos[n1:n2]) + b * (Xc - Pos[n1:n2]) - c * (worst_pos + Pos[n1:n2])
                    Pos[n2:] += a * (gBest_pos - Pos[n2:]) + b * (Xc - Pos[n2:])
                else:  # 利用阶段
                    if np.random.rand() > 0.5:
                        Pos += ( gBest_pos - Pos) * np.random.rand()
                    else:
                        brownian_vec = self._brownian_motion(len(self.work))
                        Pos = gBest_pos + ( gBest_pos - Pos) * np.random.rand() * brownian_vec

            # 边界处理
            Pos = np.clip(Pos, 0, 1)  # 假设我们使用0-1编码

            # --- 2.3. 解码并评估生成的新种群 ---
            offspring_pop_data = []
            for i in range(self.popsize):
                # 解码工序排序
                index_work = Pos[i].argsort()
                job_sga = np.array([[self.work[idx] for idx in index_work]])

                # 2. 机器分配：基于工件ID继承
                parent_data = evaluated_pop_data[i]
                p_job = parent_data['job']
                p_M = parent_data['M']
                p_T = parent_data['T']
                p_wc = parent_data['wc']

                # 2.1 先提取父代的机器分配方案 (转换为按工件ID分组的结构)
                Ma_W, Tm_W, _, WC_W = self.to_MT(p_job, p_M, p_T, p_wc)

                # 2.2 将提取出的分配方案应用到新的工序序列 job_sga 上
                M_sga, T_sga, wc_sga = self.back_MT(job_sga, Ma_W, Tm_W, WC_W)

                # 3. 计算转运时间 (基于修正后的机器序列)
                tran_sga = self.gettran(job_sga, M_sga)

                C_finish, _, _, _, _, _, _, _, _, global_max_fatigue, E_all = self.to.caculate(
                    job_sga, M_sga, T_sga, tran_sga, wc_sga, record_fatigue_history=False
                )
                fitness = [C_finish, E_all, global_max_fatigue]
                offspring_pop_data.append({
                    'job': job_sga, 'M': M_sga, 'T': T_sga,
                    'tran': tran_sga, 'wc': wc_sga,
                    'job_init': Pos[i:i + 1], 'fitness': fitness, 'velocity': self.Vel[i:i+1]
                })
            # --- 2.4. 结合遗传算子 ---
            crossed_offspring_pop_data = []
            # 增加变异概率
            pm_job_dynamic = 0.1 + (gen / self.generation) * 0.1 # 后期变异率变大
            pm_mac_dynamic = 0.1 + (gen / self.generation) * 0.15
            for i in range(0, self.popsize // 2, 2):  # 生成 popsize/2 个交叉个体
                p1_data = random.choice(evaluated_pop_data)
                p2_data = random.choice(evaluated_pop_data)

                # POX 交叉工序
                c1_os, c2_os = self.POX_improve(p1_data['job'], p2_data['job'])
                c1_os = np.array([c1_os])
                c2_os = np.array([c2_os])

                # 机器均匀交叉
                Ma_W1, Tm_W1, WCross, WC_W1 = self.to_MT(p1_data['job'], p1_data['M'], p1_data['T'], p1_data['wc'])
                Ma_W2, Tm_W2, _, WC_W2 = self.to_MT(p2_data['job'], p2_data['M'], p2_data['T'], p2_data['wc'])
                MC1, TC1, MC2, TC2, C_WC1, C_WC2 = self.mac_cross(Ma_W1, Tm_W1, Ma_W2, Tm_W2, WCross, WC_W1, WC_W2)
                c1_M, c1_T, c1_wc = self.back_MT(c1_os, MC1, TC1, C_WC1)
                c2_M, c2_T, c2_wc = self.back_MT(c2_os, MC2, TC2, C_WC2)
                # 2. 变异 (Mutation) - 直接作用于子代
                child1_temp = {'job': c1_os, 'M': c1_M, 'T': c1_T, 'wc': c1_wc}
                child2_temp = {'job': c2_os, 'M': c2_M, 'T': c2_T, 'wc': c2_wc}

                # 执行变异
                child1_mutated = self.mutation(child1_temp, pm_job_dynamic, pm_mac_dynamic)
                child2_mutated = self.mutation(child2_temp, pm_job_dynamic, pm_mac_dynamic)

                # 3. 评估变异后的子代
                # Child 1
                final_c1_job = child1_mutated['job']
                final_c1_M = child1_mutated['M']
                final_c1_T = child1_mutated['T']
                final_c1_wc = child1_mutated['wc']
                final_c1_tran = self.gettran(final_c1_job, final_c1_M)

                c1_res = self.to.caculate(final_c1_job, final_c1_M, final_c1_T, final_c1_tran, final_c1_wc)
                c1_fit = [c1_res[0], c1_res[10], c1_res[9]]

                # Child 2
                final_c2_job = child2_mutated['job']
                final_c2_M = child2_mutated['M']
                final_c2_T = child2_mutated['T']
                final_c2_wc = child2_mutated['wc']
                final_c2_tran = self.gettran(final_c2_job, final_c2_M)

                c2_res = self.to.caculate(final_c2_job, final_c2_M, final_c2_T, final_c2_tran, final_c2_wc)
                c2_fit = [c2_res[0], c2_res[10], c2_res[9]]
                job_init_c1 = p1_data['job_init'].copy()
                job_init_c2 = p2_data['job_init'].copy()

                # 速度乘以 0.1 阻尼，相当于在优秀父代附近重新低速起步探索
                vel_child = (p1_data['velocity'] + p2_data['velocity']) * 0.1

                crossed_offspring_pop_data.append({
                    'job': final_c1_job, 'M': final_c1_M, 'T': final_c1_T,
                    'tran': final_c1_tran, 'wc': final_c1_wc,
                    'job_init': job_init_c1, 'fitness': c1_fit, 'velocity': vel_child
                })
                crossed_offspring_pop_data.append({
                    'job': final_c2_job, 'M': final_c2_M, 'T': final_c2_T,
                    'tran': final_c2_tran, 'wc': final_c2_wc,
                    'job_init': job_init_c2, 'fitness': c2_fit, 'velocity': vel_child
                })
            # --- 2.5. 环境选择 ---
            # 合并父代、SGA子代和交叉子代
            combined_population_data = evaluated_pop_data + offspring_pop_data + crossed_offspring_pop_data
            combined_population_data = [d for d in combined_population_data if d['job_init'] is not None]
            # 使用非支配排序和拥挤度进行环境选择
            all_fitnesses = [ind['fitness'] for ind in combined_population_data]
            Z_answer = self.z_score_normalize_objectives(all_fitnesses)
            _, _, final_crowder = self.oh.dis(Z_answer)
            next_pop_indices = final_crowder[:self.popsize]
            evaluated_pop_data = [combined_population_data[idx] for idx in next_pop_indices]
            current_fitnesses = [d['fitness'] for d in evaluated_pop_data]
            Z_current = self.z_score_normalize_objectives(current_fitnesses)
            fronts_current, _, _ = self.oh.dis(Z_current)

            if fronts_current and len(fronts_current[0]) > 0:
                for p_idx in fronts_current[0]:  # 只针对第一前沿(Rank 1)的极品解进行微调
                    elite_ind = evaluated_pop_data[p_idx]
                    if random.random() < 0.5:
                        mutated_elite = self.mutation(elite_ind, pm_job=0.05, pm_machine=0.1)
                        # 评估微调后的个体
                        m_tran = self.gettran(mutated_elite['job'], mutated_elite['M'])
                        res_e = self.to.caculate(
                            mutated_elite['job'], mutated_elite['M'], mutated_elite['T'],
                            m_tran, mutated_elite['wc'], record_fatigue_history=False
                        )
                        e_fit = [res_e[0], res_e[10], res_e[9]]

                        #如果变异后支配了原精英，或者 Cmax 变小了，就替换它
                        if self._dominates(e_fit, elite_ind['fitness']) or e_fit[0] < elite_ind['fitness'][0]:
                            mutated_elite['tran'] = m_tran
                            mutated_elite['fitness'] = e_fit
                            mutated_elite['job_init'] = elite_ind['job_init']  # 保留原有的连续位置
                            mutated_elite['velocity'] = elite_ind['velocity']
                            evaluated_pop_data[p_idx] = mutated_elite
            # 更新下一代的SGA位置向量 Pos 和速度 Vel
            for i in range(self.popsize):
                selected_individual = evaluated_pop_data[i]
                Pos[i] = selected_individual['job_init']
                if 'velocity' in selected_individual and selected_individual['velocity'] is not None:
                    self.Vel[i] = selected_individual['velocity']
                else:
                    # 对于没有速度历史的个体（例如交叉产生的），可以随机初始化或重置为0
                    self.Vel[i] = np.zeros(len(self.work))
            # --- 2.6. 记录和打印信息 ---
            all_fitnesses_for_stats = [d['fitness'] for d in evaluated_pop_data]
            Z_answer_stats = self.z_score_normalize_objectives(all_fitnesses_for_stats)
            fronts_stats, _, _ = self.oh.dis(Z_answer_stats)

            current_pareto_fitness = []
            if fronts_stats and fronts_stats[0]:
                pareto_indices_stats = fronts_stats[0]
                current_pareto_fitness = [evaluated_pop_data[i]['fitness'] for i in pareto_indices_stats]

            if current_pareto_fitness:
                min_c = min(f[0] for f in current_pareto_fitness)
                min_e = min(f[1] for f in current_pareto_fitness)
                min_s = min(f[2] for f in current_pareto_fitness)
                if gen > 0 and len(fit_every[0]) > 0:
                    if min_c > fit_every[0][-1]: min_c = fit_every[0][-1]
                    if min_e > fit_every[1][-1]: min_e = fit_every[1][-1]
                    if min_s > fit_every[2][-1]: min_s = fit_every[2][-1]
                fit_every[0].append(min_c)
                fit_every[1].append(min_e)
                fit_every[2].append(min_s)
                print(f'SGA Gen {gen + 1}: Cmax={min_c:.1f}, Eall={min_e:.1f}, Fatigue={min_s:.3f}')
            else:
                # 处理没有找到前沿的情况，避免 fit_every 数组长度不匹配
                if gen > 0 and fit_every[0]:
                    fit_every[0].append(fit_every[0][-1])
                    fit_every[1].append(fit_every[1][-1])
                    fit_every[2].append(fit_every[2][-1])
        # --- 3. 循环结束，返回结果 ---
        final_fitnesses = [ind['fitness'] for ind in evaluated_pop_data]
        final_front, _, _ = self.oh.dis(self.z_score_normalize_objectives(final_fitnesses))
        pareto_indices = final_front[0] if final_front else []

        pareto = [evaluated_pop_data[i]['fitness'] for i in pareto_indices]
        pareto_job = np.array([evaluated_pop_data[i]['job'][0] for i in pareto_indices])
        pareto_machine = np.array([evaluated_pop_data[i]['M'][0] for i in pareto_indices])
        pareto_time = np.array([evaluated_pop_data[i]['T'][0] for i in pareto_indices])
        pareto_tran = np.array([evaluated_pop_data[i]['tran'][0] for i in pareto_indices])
        pareto_Wc = np.array([evaluated_pop_data[i]['wc'][0] for i in pareto_indices])
        return pareto, pareto_job, pareto_machine, pareto_time, pareto_tran, fit_every, pareto_Wc