import numpy as np
import math

from matplotlib.patches import Patch

from small_work import data_deal
import random
import copy
import collections
import matplotlib.pyplot as plt
from matplotlib.pylab import mpl
mpl.rcParams['font.sans-serif'] = ['SimHei']  # 添加这条可以让图形显示中文
from scipy.interpolate import PchipInterpolator
mpl.rcParams['axes.unicode_minus'] = False # 解决负号显示问题

class FJSP():
	def __init__(self,job_num,machine_num,parm_data,popsize,work):
		self.popsize = popsize  # 种群规模
		self.job_num=job_num     			#工件数
		self.machine_num=machine_num		#机器数
		# self.pi=pi  				#随机挑选机器的概率
		self.Tmachine,self.Tmachinetime,self.tdx,self.work,self.M_dicr, self.tran_time,self.all_num,self.work_arr,\
		self.work_num,self.worker_fatigue,self.worker_efficiency_factors,self.worker_recovery=parm_data[0],parm_data[1],parm_data[2],parm_data[3],parm_data[4],parm_data[5],parm_data[6],parm_data[7],parm_data[8],parm_data[9],parm_data[10],parm_data[11]
		self.work=work
		self.MAXFG = 0.85  # 最大疲劳阈值
		self.u = 0.038  # 定义疲劳恢复速率

		# 新增状态变量
		self.breakdown_time = None
		self.completed_ops = set()
	def axis(self):
		index=['M1','M2','M3','M4','M5','M6','M7','M8','M9','M10','M11','M12',
		'M13','M14','M15','M16','M17','M18','M19','M20']
		scale_ls,index_ls=[],[]
		for i in range(self.machine_num):
			scale_ls.append(i+1)
			index_ls.append(index[i])
		return index_ls,scale_ls  #返回坐标轴信息，按照工件数返回，最多画20个机器，需要在后面添加
	def getind(self,list_T,job):
		ind = np.zeros((1, self.job_num))
		# print(job,len(job[0]))
		# print(self.job_num)
		# print(list_T)
		for i in range(len(job[0])):
			# print(i)
			if job[0][i] == list_T[0]:

				ind[0][list_T[0]]+=1
				# print(ind)
				# print("-----")

				if list_T[1]==ind[0][list_T[0]]:

					break
		return i
	def gettran(self,job,machine):
		trantime = np.ones((1, job.shape[1]))
		index = []
		k = 0
		for i in range(self.job_num):

			for j in range(len(job[0])):
				if job[0][j] == i:
					k += 1
					index.append(j)
					if k == 1:
						trantime[0][j] = 0
					else:
						a = machine[0][j]  # 当前工序机器序号
						b = machine[0][index[-2]]  # 该工件前一个工序机器编号
						x = list(self.M_dicr[int(a)])[0] - 1
						y = list(self.M_dicr[int(b)])[0] - 1
						# print(x,y)

						trantime[0][j] = self.tran_time[y][x]
			# 获取两个工序机器对应的车间

			index = []
			k = 0
		return trantime

	def update_position_vector(self,original_positions, new_order):
		"""
        根据工序加工顺序的变化更新位置向量

        参数:
        original_positions (list): 原始位置向量
        original_order (list): 原始位置向量对应的工序编码
        new_order (list): 新的工序编码

        返回:
        list: 更新后的位置向量
        """
		# 确保输入合法
		original_order = copy.deepcopy(self.work)
		if len(original_positions) != len(original_order) or len(original_order) != len(new_order):
			raise ValueError("所有输入列表的长度必须相同")

		# 创建原始位置向量和工序编码的映射
		position_map = {}
		for pos, order in zip(original_positions, original_order):
			if order not in position_map:
				position_map[order] = []
			position_map[order].append(pos)

		# 对每个工序编码的位置向量进行升序排序
		for order in position_map:
			position_map[order].sort(reverse=True)

		# 根据新的工序编码生成新的位置向量
		new_positions = []
		used_counts = {order: 0 for order in position_map}

		for order in new_order:
			if order not in position_map:
				raise ValueError(f"新的工序编码 {order} 不在原始工序编码中")

			# 获取该工序编码对应的下一个位置值
			pos_list = position_map[order]
			index = used_counts[order]

			if index >= len(pos_list):
				# 如果位置值不够用，则生成一个比当前最小值略小的值
				min_val = min(pos_list)
				new_val = min_val - 0.1 * (index - len(pos_list) + 1)
				new_positions.append(new_val)
			else:
				new_positions.append(pos_list[index])
				used_counts[order] += 1

		return new_positions
	def creat_job(self):
		work_F, work_tran, work_job, work_M, work_T = np.zeros((self.popsize, len(self.work))), np.zeros(
			(self.popsize, len(self.work))), np.zeros((self.popsize, len(self.work))), np.zeros(
			(self.popsize, len(self.work))), np.zeros((self.popsize, len(self.work)))
		job_init = np.zeros((self.popsize, len(self.work)))
		work_W = np.zeros((self.popsize,len(self.work)))
		for size in range(self.popsize):
			initial_a = np.random.rand(len(self.work))  # 通过本函数可以返回一个或一组服从“0~1”均匀分布的随机样本值。随机样本取值范围是[0,1)array = {NdArrayItemsContainer}  Show Value，不包括1
			index_work = np.array(initial_a).argsort()  # 将随机样本值由小到大排列，排列出其对应的索引
			job = []
			# print(index_work)
			for i in range(len(self.work)):
				job.append(self.work[index_work[i]])

			initial_a = self.update_position_vector(initial_a,job)

			job = np.array(job).reshape(1, len(self.work))
			factor = np.zeros((1, self.all_num))
			machine = np.zeros((1, self.all_num))
			machine_time = np.zeros((1, self.all_num))

			# GLR
			# print(self.popsize)
			rate_G, rate_L, rate_R = 0.5, 0.4, 0.1
			indx = np.zeros((1, self.job_num))
			# print(self.Tmachine)
			# print(self.Tmachinetime)
			if (size + 1) <= self.popsize * rate_G:  # 全局选择  选择最小化整个车间的总负载 从所有可选机器中，选择那台预计算后新累计完工时间最小的机器
				Time = np.zeros((1, self.machine_num))  # 时间轴
				T = np.zeros((1, self.machine_num))  # 临时时间轴
				for j in range(self.job_num):
					for z in range(len(job[0])):
						if job[0, z] == j:
							min_index = 0
							min_mt = 0
							for m in range(len(self.Tmachine[j][int(indx[0, j])])):
								T[0][self.Tmachine[j][int(indx[0, j])][m] - 1] += self.Tmachinetime[j][int(indx[0, j])][
									m]
								if min_index == 0:
									min_index = T[0][self.Tmachine[j][int(indx[0, j])][m] - 1]
									min_mt = m
								elif min_index > T[0][self.Tmachine[j][int(indx[0, j])][m] - 1]:
									min_index = T[0][self.Tmachine[j][int(indx[0, j])][m] - 1]
									min_mt = m
								else:
									min_index = min_index
							min_wh = np.argwhere(T[0] == min_index)
							machine[0, z] = self.Tmachine[j][int(indx[0, j])][min_mt] - 1
							factor[0, z] = self.M_dicr[machine[0, z]][0]
							machine_time[0, z] = self.Tmachinetime[j][int(indx[0, j])][min_mt]
							Time[0][min_wh[0, 0]] = T[0][min_wh[0, 0]]
							T = np.copy(Time)
							indx[0, j] = indx[0, j] + 1
				#print("机器排序",machine)

			# 局部选择 遍历可选机器，预计算，选择能使T最小的机器
			elif ((size + 1) > self.popsize * rate_G) and ((size + 1) <= self.popsize * (rate_G + rate_L)):
				for j in range(self.job_num):
					Time = np.zeros((1, self.machine_num))  # 时间轴
					T = np.zeros((1, self.machine_num))  # 临时时间轴
					for z in range(len(job[0])):
						if job[0, z] == j:
							min_index = 0
							min_mt = 0
							for m in range(len(self.Tmachine[j][int(indx[0, j])])):
								T[0][self.Tmachine[j][int(indx[0, j])][m] - 1] += self.Tmachinetime[j][int(indx[0, j])][
									m]
								if min_index == 0:
									min_index = T[0][self.Tmachine[j][int(indx[0, j])][m] - 1]
									min_mt = m
								elif min_index > T[0][self.Tmachine[j][int(indx[0, j])][m] - 1]:
									min_index = T[0][self.Tmachine[j][int(indx[0, j])][m] - 1]
									min_mt = m
								else:
									min_index = min_index

							min_wh = np.argwhere(T[0] == min_index)
							# print("索引",min_wh)

							machine[0, z] = self.Tmachine[j][int(indx[0, j])][min_mt] - 1
							factor[0, z] = self.M_dicr[machine[0, z]][0]
							machine_time[0, z] = self.Tmachinetime[j][int(indx[0, j])][min_mt]
							Time[0][min_wh[0, 0]] = T[0][min_wh[0, 0]]
							T = np.copy(Time)
							indx[0, j] = indx[0, j] + 1
				#print("机器排序2", machine)
			else:
				# 完全随机地选择一台机器
				for j in range(self.job_num):
					for z in range(len(job[0])):
						if job[0, z] == j:
							x = self.Tmachine[j][int(indx[0, j])]
							y = random.choice(x)
							machine[0][z] = y - 1
							factor[0][z] = self.M_dicr[machine[0, z]][0]
							for min_mt in range(len(self.Tmachine[j][int(indx[0, j])])):
								if self.Tmachine[j][int(indx[0, j])][min_mt] == y:
									machine_time[0][z] = self.Tmachinetime[j][int(indx[0, j])][min_mt]
							indx[0, j] = indx[0, j] + 1
			# print("机器排序3", machine)
			# print(job)
			# print(machine)
			# print(machine_time)
			# print(factor)
			trantime =self.gettran(job,machine)
			index = []
			k = 0
			for i in range(self.job_num):

				for j in range(len(job[0])):
					if job[0][j] == i:
						k += 1
						index.append(j)
						if k == 1:
							trantime[0][j] = 0
						else:
							a = machine[0][j]  # 当前工序机器序号
							b = machine[0][index[-2]]  # 该工件前一个工序机器编号
							x = list(self.M_dicr[int(a)])[0] - 1
							y = list(self.M_dicr[int(b)])[0] - 1
							# print(x,y)

							trantime[0][j] = self.tran_time[y][x]
				# 获取两个工序机器对应的车间

				index = []
				k=0
			work_F[size], work_tran[size], work_job[size], work_M[size], work_T[size] = factor[0], trantime[0], job[0], machine[0], machine_time[0]
			job_init[size] = initial_a
		# WS根据MS生成人员编码
			WC=np.zeros((self.popsize, work_job.shape[1]))
			for i in range(self.popsize):
				for j in range(work_job.shape[1]):
					if j==1:
						WC[i][j] = np.random.choice(self.work_arr[int(work_M[i][j])])
					else:
						WC[i][j] = self.select_different_number1(self.work_arr[int(work_M[i][j])],WC[i][j-1])  #连续不相同
		return work_job, work_M, work_T, work_tran, work_F, job_init,WC

	def caculate(self, job, machine, machine_time, trantime, WC, record_fatigue_history=False):
		jobtime = np.zeros((1, self.job_num))
		tmm = np.zeros((1, self.machine_num))
		work_time = np.zeros((1, self.work_num))  # 记录工人完成上个任务的时间
		tmmw = np.zeros((1, self.machine_num))  # 理论工作时间 (仅加工)
		max_fatigue_per_worker = np.zeros((1, self.work_num))
		worker_fatigue_level = np.zeros((1, self.work_num))  # 当前疲劳状态
		worker_recovery = self.worker_recovery
		list_M, list_S, list_W, list_WO = [], [], [], []
		list_T = [[] for _ in range(self.machine_num)]
		inde = np.zeros((1, self.job_num))

		# 初始化疲劳历史记录
		fatigue_history = {w: [(0, 0.0)] for w in range(self.work_num)} if record_fatigue_history else None
		worker_efficiency = self.worker_efficiency_factors
		for i in range(job.shape[1]):
			svg, sig, swg = int(job[0, i]), int(machine[0, i]), int(WC[0, i] - 1)
			op_duration = machine_time[0, i] * worker_efficiency[swg]
			transfer_t = trantime[0, i]
			op_seq = int(inde[0, svg] + 1)  # 当前工序号 (从1开始)

			# --- 1. 计算基础开始时间 (不含休息) ---
			last_finish_time = work_time[0, swg]
			base_start_time = max(jobtime[0, svg] + transfer_t,
								  tmm[0, sig],
								  last_finish_time)

			# --- 2. 计算并应用自然空闲恢复 ---
			current_worker_recovery_rate = worker_recovery[swg]
			natural_idle_time = max(0, base_start_time - last_finish_time)
			fatigue_before_idle = worker_fatigue_level[0, swg]
			fatigue_after_idle = fatigue_before_idle * math.exp(-current_worker_recovery_rate * natural_idle_time)
			fatigue_after_idle = max(0.0, fatigue_after_idle)

			# 记录空闲恢复点
			if record_fatigue_history and natural_idle_time > 1e-6:
				time_point = base_start_time
				fatigue_point = fatigue_after_idle
				if not fatigue_history[swg] or fatigue_history[swg][-1][0] < time_point:
					fatigue_history[swg].append((time_point, fatigue_point))
				elif fatigue_history[swg][-1][0] == time_point:
					fatigue_history[swg][-1] = (time_point, min(fatigue_history[swg][-1][1], fatigue_point))

			# --- 3. 计算强制休息时间 ---
			current_fatigue_for_rest_calc = fatigue_after_idle  # 使用空闲恢复后的疲劳
			final_rest_duration = 0
			predicted_fatigue_final = 1 - (1 - current_fatigue_for_rest_calc) * math.exp(
				-self.worker_fatigue[swg] * op_duration)
			if predicted_fatigue_final > self.MAXFG:
				required_rest = self._calculate_required_rest(current_fatigue_for_rest_calc, op_duration,
															  self.worker_fatigue[swg], current_worker_recovery_rate, self.MAXFG)
				final_rest_duration = math.ceil(required_rest)

			# --- 4. 计算最终开始时间 ---
			startime = base_start_time + final_rest_duration
			endtime = startime + op_duration

			# --- 5. 更新疲劳状态和记录历史 ---
			# a. 计算强制休息后的疲劳值
			fatigue_after_forced_rest = fatigue_after_idle * math.exp(-current_worker_recovery_rate * final_rest_duration)
			fatigue_after_forced_rest = max(0.0, fatigue_after_forced_rest)

			# b. 记录工序实际开始时的疲劳点
			if record_fatigue_history:
				time_point = startime
				fatigue_point = fatigue_after_forced_rest
				if not fatigue_history[swg] or fatigue_history[swg][-1][0] < time_point:
					fatigue_history[swg].append((time_point, fatigue_point))
				elif fatigue_history[swg][-1][0] == time_point:
					fatigue_history[swg][-1] = (time_point, fatigue_point)

			# c. 计算工序完成后的疲劳
			fatigue_at_op_start = fatigue_after_forced_rest
			fatigue_after_work = 1 - (1 - fatigue_at_op_start) * math.exp(-self.worker_fatigue[swg] * op_duration)
			fatigue_after_work = min(fatigue_after_work, self.MAXFG)
			worker_fatigue_level[0, swg] = fatigue_after_work  # 更新工人当前状态
			if fatigue_after_work > max_fatigue_per_worker[0, swg]:
				max_fatigue_per_worker[0, swg] = fatigue_after_work

			# d. 记录工序结束点
			if record_fatigue_history:
				time_point = endtime
				fatigue_point = fatigue_after_work
				if not fatigue_history[swg] or fatigue_history[swg][-1][0] < time_point:
					fatigue_history[swg].append((time_point, fatigue_point))
				elif fatigue_history[swg][-1][0] == time_point:
					fatigue_history[swg][-1] = (time_point, fatigue_point)

			# --- 6. 更新时间表和 list_T ---
			inde[0, svg] += 1
			tmm[0, sig] = endtime
			jobtime[0, svg] = endtime
			work_time[0, swg] = endtime  # *** 更新工人完成时间 ***

			list_M.append(sig)
			list_S.append(startime)
			list_W.append(op_duration)
			list_T[sig].append(
				[svg, op_seq, int(round(startime)), int(round(op_duration)), int(round(transfer_t)), swg + 1])
			tmmw[0, sig] += op_duration  # 只累加实际加工时间
			list_WO.append(swg)

		# --- 计算最终目标值 ---
		C_finish = np.max(tmm[0]) if tmm[0].size > 0 else 0
		Twork = np.sum(tmmw[0])  # 总理论加工时间
		p1 = np.array([self.M_dicr[m][1] for m in range(self.machine_num)])
		p2 = np.array([self.M_dicr[m][2] for m in range(self.machine_num)])
		# 精确空载时间
		machine_idle_time = np.zeros_like(tmmw)
		for m in range(self.machine_num):
			machine_finish_time = tmm[0, m]
			processing_time_on_m = sum(item[3] for item in list_T[m])
			machine_idle_time[0, m] = max(0, machine_finish_time - processing_time_on_m)
		trest = machine_idle_time

		total_transfer_time_sum = np.sum(trantime[0])
		transfer_energy = total_transfer_time_sum * 1.5
		E_all = np.sum(tmmw * p1) + np.sum(trest * p2) + transfer_energy
		tmax = np.argmax(tmm[0]) + 1
		Wmax = np.argmax(work_time[0])
		global_max_fatigue = np.max(max_fatigue_per_worker) if max_fatigue_per_worker.size > 0 else 0
		# *** 计算平均最大疲劳度 ***
		active_fatigues = max_fatigue_per_worker[0][max_fatigue_per_worker[0] > 1e-6]
		avg_max_fatigue = np.mean(active_fatigues) if active_fatigues.size > 0 else 0.0
		# --- 返回结果 ---
		final_list_M, final_list_S, final_list_W = [], [], []  # 假设不再需要

		# *** 根据标志返回不同内容 ***
		if record_fatigue_history:
			# 清理 fatigue_history
			for w_idx in fatigue_history:
				if len(fatigue_history[w_idx]) > 1:
					# ... (清理逻辑同上) ...
					cleaned_history = [fatigue_history[w_idx][0]]
					for k in range(1, len(fatigue_history[w_idx]) - 1):
						if fatigue_history[w_idx][k][1] != fatigue_history[w_idx][k - 1][1] or \
								fatigue_history[w_idx][k][1] != fatigue_history[w_idx][k + 1][1]:
							cleaned_history.append(fatigue_history[w_idx][k])
					cleaned_history.append(fatigue_history[w_idx][-1])
					fatigue_history[w_idx] = cleaned_history

			return (C_finish, tmax, list_T, list_M, list_S, list_W, tmmw[0], Wmax, Twork,
					global_max_fatigue,
					E_all, fatigue_history)  # 返回历史
		else:
			# 标准返回
			return (C_finish, tmax, list_T, list_M, list_S, list_W, tmmw[0], Wmax, Twork,
					global_max_fatigue,  # 返回单个值
					E_all)

	def _calculate_required_rest(self, f0, op_time, lambda_, u, MAXFG):
		"""计算需要的最小休息时间（数学解析解）"""
		# 目标方程：1 - (1 - f0*exp(-u*tau)) * exp(-lambda*op_time) <= MAXFG
		# 整理得：f0*exp(-u*tau) >= [1 - (1 - MAXFG)/exp(-lambda*op_time)]

		numerator = 1 - (1 - MAXFG) / math.exp(-lambda_ * op_time)
		if numerator <= 0:
			return 0  # 无需休息

		threshold = numerator / f0
		if threshold >= 1:
			return 0  # 即使不休息也满足条件

		# 计算最小休息时间
		tau = -math.log(threshold) / u
		return max(tau, 0)  # 休息时间不能为负

	# === 新增：辅助方法用于选择工人 ===
	def _select_worker_for_machine(self, machine_idx, current_worker_idx, strategy='random'):
		"""为指定机器选择一个工人"""
		available_workers_1based = self.work_arr[machine_idx]
		if not available_workers_1based:
			return current_worker_idx  # 返回原工人作为后备，但这可能不合适

		available_workers_0based = [w - 1 for w in available_workers_1based]

		if strategy == 'random':
			# 尝试选择一个不同于当前工人的工人，如果只有一个工人则返回该工人
			if len(available_workers_0based) == 1:
				return available_workers_0based[0]
			else:
				chosen_worker = current_worker_idx
				while chosen_worker == current_worker_idx:  # 确保选一个不同的
					chosen_worker = random.choice(available_workers_0based)
				return chosen_worker
		# elif strategy == 'least_fatigued': # 可以后续实现
		#     # 需要传入 worker_fatigue_level
		#     pass
		else:
			# 默认随机
			return random.choice(available_workers_0based)

	# === 修改 recaculate 方法以包含重分配逻辑 ===
	def recaculate(self, job, machine, machine_time, trantime, WC, breakdowns,
				   p_shortest_time=0.6,
				   p_random_capable=0.3,
				   record_fatigue_history=False
				   ):
		# --- 初始化 ---
		jobtime = np.zeros((1, self.job_num))
		tmm = np.zeros((1, self.machine_num))
		work_time = np.zeros((1, self.work_num))  # 记录工人完成上一个任务的时间
		tmmw = np.zeros((1, self.machine_num))  # 理论工作时间 (仅加工)
		max_fatigue_per_worker = np.zeros((1, self.work_num))
		worker_fatigue_level = np.zeros((1, self.work_num))  # 工人当前疲劳状态
		worker_recovery = self.worker_recovery
		list_M, list_S, list_W, list_WO = [], [], [], []  # 这些列表可能不再需要完整填充
		list_T = [[] for _ in range(self.machine_num)]  # 核心结果列表
		inde = np.zeros((1, self.job_num))
		machine_reassigned_count = 0
		worker_reassignment_log = []  # 可选日志
		fatigue_history = {w: [(0, 0.0)] for w in range(self.work_num)}  # 疲劳历史
		# --- 结束初始化 ---

		for i in range(job.shape[1]):
			svg = int(job[0, i])
			original_sig = int(machine[0, i])
			original_swg = int(WC[0, i] - 1)
			original_op_duration = machine_time[0, i]
			transfer_t = trantime[0, i]
			op_seq = int(inde[0, svg] + 1)

			# --- 1. 确定最终执行者和时长 ---
			final_sig = original_sig
			final_swg = original_swg
			final_op_duration = original_op_duration
			strategy_used = "None"
			conflict = False
			conflict_bd_end = -1
			reassigned_machine = False

			# a. 预估开始时间 (用于冲突检测)
			tentative_start_no_rest = max(jobtime[0, svg] + transfer_t,
										  tmm[0, original_sig],
										  work_time[0, original_swg])
			# b. 检查原始冲突
			if original_sig in breakdowns:
				for bd_start, bd_duration in breakdowns[original_sig]:
					bd_end = bd_start + bd_duration
					potential_end_time_no_rest = tentative_start_no_rest + original_op_duration
					if max(tentative_start_no_rest, bd_start) < min(potential_end_time_no_rest, bd_end):
						conflict = True
						conflict_bd_end = bd_end
						break

			# c. 如果冲突，执行重分配或延迟决策
			if conflict:
				# 查找可用替代方案 (检查替代机器本身是否故障)
				capable_machines_1based = self.Tmachine[svg][op_seq - 1]
				alternative_machine_options = []
				for k, m_id_1based in enumerate(capable_machines_1based):
					alt_m_idx = m_id_1based - 1
					if alt_m_idx == original_sig: continue
					alt_m_time = self.Tmachinetime[svg][op_seq - 1][k]
					estimated_start_on_alt = max(jobtime[0, svg] + transfer_t, tmm[0, alt_m_idx])
					estimated_end_on_alt = estimated_start_on_alt + alt_m_time
					is_alt_machine_broken = False
					if alt_m_idx in breakdowns:
						for bd_start, bd_duration in breakdowns[alt_m_idx]:
							bd_end = bd_start + bd_duration
							if max(estimated_start_on_alt, bd_start) < min(estimated_end_on_alt, bd_end):
								is_alt_machine_broken = True
								break
					if not is_alt_machine_broken:
						alternative_machine_options.append((alt_m_idx, alt_m_time))

				# 概率决策
				rand_val = random.random()
				attempt_reassign = False
				if not alternative_machine_options:
					strategy_used = "Delay (No Viable Alternatives)"
				elif rand_val < p_shortest_time:
					strategy_used = "Shortest Time Reassignment"
					attempt_reassign = True
					alternative_machine_options.sort(key=lambda x: x[1])
					final_sig = alternative_machine_options[0][0]
					final_op_duration = alternative_machine_options[0][1]
				elif rand_val < p_shortest_time + p_random_capable:
					strategy_used = "Random Reassignment"
					attempt_reassign = True
					chosen_option = random.choice(alternative_machine_options)
					final_sig = chosen_option[0]
					final_op_duration = chosen_option[1]
				else:
					strategy_used = "Delay (Probabilistic)"

				# 处理重分配尝试结果
				if attempt_reassign:
					new_swg_candidate = self._select_worker_for_machine(final_sig, original_swg, strategy='random')
					if new_swg_candidate == -1:
						# print(f"    !!! 警告: 无法为替代机器 M{final_sig+1} 分配工人！回退到延迟策略。")
						strategy_used = "Delay (Worker Assign Failed)"
						final_sig = original_sig
						final_swg = original_swg
						final_op_duration = original_op_duration
					else:
						reassigned_machine = True
						machine_reassigned_count += 1
						final_swg = new_swg_candidate
						if final_swg != original_swg: worker_reassignment_log.append(
							(svg, op_seq, original_swg, final_swg))
			else:
				strategy_used = "None (No Conflict)"
			# --- 结束确定执行者 ---

			# --- 2. 计算到达基础开始时间点的疲劳 (含空闲恢复) ---
			last_task_finish_time = work_time[0, final_swg]
			base_start_time = max(jobtime[0, svg] + transfer_t, tmm[0, final_sig], last_task_finish_time)
			natural_idle_time = max(0, base_start_time - last_task_finish_time)
			fatigue_before_op_base = worker_fatigue_level[0, final_swg] * math.exp(-self.u * natural_idle_time)
			fatigue_before_op_base = max(0.0, fatigue_before_op_base)

			# 记录空闲恢复点
			if record_fatigue_history and natural_idle_time > 1e-6:
				time_point = base_start_time
				fatigue_point = fatigue_before_op_base
				if not fatigue_history[final_swg] or fatigue_history[final_swg][-1][0] < time_point:
					fatigue_history[final_swg].append((time_point, fatigue_point))
				elif fatigue_history[final_swg][-1][0] == time_point:
					fatigue_history[final_swg][-1] = (time_point, min(fatigue_history[final_swg][-1][1], fatigue_point))

			# --- 3. 计算强制休息时间 ---
			final_rest_duration = 0
			predicted_fatigue_check = 1 - (1 - fatigue_before_op_base) * math.exp(
				-self.worker_fatigue[final_swg] * final_op_duration)
			if predicted_fatigue_check > self.MAXFG:
				required_rest = self._calculate_required_rest(fatigue_before_op_base, final_op_duration,
															  self.worker_fatigue[final_swg], self.u, self.MAXFG)
				final_rest_duration = math.ceil(required_rest)

			# --- 5. 计算最终实际开始时间 ---
			# a. 计算基础开始时间 (不含休息)
			base_start_time = max(jobtime[0, svg] + transfer_t,
								  tmm[0, final_sig],
								  work_time[0, final_swg]
								  )

			# b. 计算强制休息时间 final_rest_duration
			# ... (计算 final_rest_duration) ...

			# c. 计算暂定开始时间 (基础 + 休息)
			tentative_final_startime = base_start_time + final_rest_duration
			tentative_final_endtime = tentative_final_startime + final_op_duration

			# d. *** 检查与最终机器 final_sig 的故障冲突 ***
			final_actual_startime = tentative_final_startime  # 默认值
			latest_forced_end_time = -1  # 重置
			if final_sig in breakdowns:
				for bd_s, bd_d in breakdowns[final_sig]:
					bd_e = bd_s + bd_d
					# 检查 [暂定最终开始, 暂定最终结束] 是否与 *本机* 故障重叠
					if max(tentative_final_startime, bd_s) < min(tentative_final_endtime, bd_e):
						latest_forced_end_time = max(latest_forced_end_time, bd_e)  # 记录最晚故障结束时间

			# e. *** 应用故障延迟 (如果检测到最终冲突) ***
			if latest_forced_end_time > -1:
				# 新的开始时间必须在故障结束后，也要在原暂定时间之后
				final_actual_startime = max(tentative_final_startime, latest_forced_end_time)

			# --- 5. 更新疲劳状态 (基于最终开始时间) ---
			# a. 计算从上次完成到实际开始工作前的总空闲/等待时间
			time_before_actual_work_start = final_actual_startime - final_rest_duration
			total_non_work_duration = max(0, time_before_actual_work_start - last_task_finish_time)

			# b. 计算考虑了所有等待恢复后的疲劳值（准备强制休息）
			fatigue_recovered_total = worker_fatigue_level[0, final_swg] * math.exp(-self.u * total_non_work_duration)
			fatigue_recovered_total = max(0.0, fatigue_recovered_total)

			# c. 计算强制休息后的疲劳值（工序开始时的疲劳）
			fatigue_at_actual_op_start = fatigue_recovered_total * math.exp(-self.u * final_rest_duration)
			fatigue_at_actual_op_start = max(0.0, fatigue_at_actual_op_start)

			# d. 记录工序开始时的点
			if record_fatigue_history:
				time_point = final_actual_startime
				fatigue_point = fatigue_at_actual_op_start
				if not fatigue_history[final_swg] or fatigue_history[final_swg][-1][0] < time_point:
					fatigue_history[final_swg].append((time_point, fatigue_point))
				elif fatigue_history[final_swg][-1][0] == time_point:
					fatigue_history[final_swg][-1] = (time_point, fatigue_point)

			# e. 计算工作完成后的疲劳
			final_fatigue_level = 1 - (1 - fatigue_at_actual_op_start) * math.exp(
				-self.worker_fatigue[final_swg] * final_op_duration)
			final_fatigue_level = min(final_fatigue_level, self.MAXFG)
			worker_fatigue_level[0, final_swg] = final_fatigue_level  # 更新工人当前状态
			if final_fatigue_level > max_fatigue_per_worker[0, final_swg]:
				max_fatigue_per_worker[0, final_swg] = final_fatigue_level

			# f. 记录工序结束时的点
			actual_finish_time = final_actual_startime + final_op_duration
			if record_fatigue_history:
				time_point = actual_finish_time
				fatigue_point = final_fatigue_level
				if not fatigue_history[final_swg] or fatigue_history[final_swg][-1][0] < time_point:
					fatigue_history[final_swg].append((time_point, fatigue_point))
				elif fatigue_history[final_swg][-1][0] == time_point:
					fatigue_history[final_swg][-1] = (time_point, fatigue_point)

			# --- 6. 更新时间表和 list_T ---
			tmm[0, final_sig] = actual_finish_time
			jobtime[0, svg] = actual_finish_time
			work_time[0, final_swg] = actual_finish_time  # *** 更新工人完成时间 ***
			inde[0, svg] = op_seq
			list_M.append(final_sig)
			list_S.append(final_actual_startime)
			list_W.append(final_op_duration)
			list_T[final_sig].append(
				[svg, op_seq, int(round(final_actual_startime)), int(round(final_op_duration)), int(round(transfer_t)),
				 final_swg + 1]
			)
			tmmw[0, final_sig] += final_op_duration  # 只累加实际加工时间
			list_WO.append(final_swg)
		# --- 结束更新 ---

		# --- 计算最终目标值 ---
		C_finish = np.max(tmm[0]) if tmm[0].size > 0 else 0
		Twork = np.sum(tmmw[0])
		# ... (计算 E_all, tmax, Wmax) ...
		p1 = np.array([self.M_dicr[m][1] for m in range(self.machine_num)])
		p2 = np.array([self.M_dicr[m][2] for m in range(self.machine_num)])
		machine_idle_time = np.zeros_like(tmmw)
		for m in range(self.machine_num):
			machine_finish_time = tmm[0, m]
			processing_time_on_m = sum(item[3] for item in list_T[m])
			machine_idle_time[0, m] = max(0, machine_finish_time - processing_time_on_m)
		trest = machine_idle_time
		total_transfer_time = np.sum(trantime[0])
		transfer_energy = total_transfer_time * 1.5
		E_all = np.sum(tmmw * p1) + np.sum(trest * p2) + transfer_energy
		tmax = np.argmax(tmm[0]) if tmm[0].size > 0 else -1
		Wmax = np.argmax(work_time[0]) if work_time[0].size > 0 else -1
		# *** 计算平均最大疲劳度 ***
		active_fatigues = max_fatigue_per_worker[0][max_fatigue_per_worker[0] > 1e-6]
		avg_max_fatigue = np.mean(active_fatigues) if active_fatigues.size > 0 else 0.0
		global_max_fatigue = np.max(max_fatigue_per_worker) if max_fatigue_per_worker.size > 0 else 0
		# --- 返回结果 ---
		final_list_M, final_list_S, final_list_W = [], [], []

		# *** 返回值修改：返回 max_fatigue_per_worker 数组本身 ***
		if record_fatigue_history:
			# ... (清理 fatigue_history) ...
			for w_idx in fatigue_history:
				if len(fatigue_history[w_idx]) > 1:
					cleaned_history = [fatigue_history[w_idx][0]]
					for k in range(1, len(fatigue_history[w_idx]) - 1):
						if fatigue_history[w_idx][k][1] != fatigue_history[w_idx][k - 1][1] or \
								fatigue_history[w_idx][k][1] != fatigue_history[w_idx][k + 1][1]:
							cleaned_history.append(fatigue_history[w_idx][k])
					cleaned_history.append(fatigue_history[w_idx][-1])
					fatigue_history[w_idx] = cleaned_history


			return (C_finish, Twork, E_all, tmax, list_T,
					final_list_M, final_list_S, final_list_W, tmmw[0], Wmax,
					global_max_fatigue,
					machine_reassigned_count, fatigue_history)
		else:
			# *** 标准返回也包含疲劳数组 ***
			return (C_finish, Twork, E_all, tmax, list_T,
					final_list_M, final_list_S, final_list_W, tmmw[0], Wmax,
					global_max_fatigue,
					machine_reassigned_count)

	def plugin(self,list_T,list_M,list_S,list_W,job,tmmw,trantime):  #插件规则
			# print(job)
			p1, p2 = [], []
			# print(type(job))
			job=job.tolist()
			# print(type(job))
			for i in range(self.machine_num):
				p1.append(self.M_dicr[i][1])
				p2.append(self.M_dicr[i][2])

			for i in range(self.machine_num):
				for j in range(len(list_T[i])):

					if (list_T[i][j][1]>1) and (j>0):  #list_T[i][j][1] 工件完成的工序数   15 2 177 17 0
						a,b=int(list_T[i][j][0]),int(list_T[i][j][1])        #工件号 工序号

						# print("-----------------------")
						for x in range(len(list_T)):
							for y in range(len(list_T[x])):
								if (list_T[x][y][0]==a) and (list_T[x][y][1]==b):
									for z in range(j-1):
										if (list_T[x][y][2]+list_T[x][y][3]+list_T[i][j][4]<=list_T[i][z][2]+list_T[i][z][3]) and (list_T[i][z][2]+list_T[i][z][3]+list_T[i][j][3]<=list_T[i][z+1][2]):

											list_T[i][j][2]=list_T[i][z][2]+list_T[i][z][3]
											list_T[i].insert(z+1,list_T[i][j])
											# print(list_T[i][j+1])
											del list_T[i][j+1]

											this_job=self.getind(list_T[i][z+1],job)
											next_job=self.getind(list_T[i][z+2],job)

											# print(this_job, next_job)
											# print("---")
											job[0].insert(next_job,job[0][this_job])
											del job[0][this_job+1]



											# print(z)
											# print(j)
											#
											# print(list_T)
											# print("------------------")
											break
										elif (list_T[x][y][2]+list_T[x][y][3]<=list_T[i][z][2]+list_T[i][z][3]) and (list_T[x][y][2]+list_T[x][y][3]+list_T[i][j][4]>=list_T[i][z][2]+list_T[i][z][3]) and (list_T[x][y][2]+list_T[x][y][3]+list_T[i][j][4]+list_T[i][j][3]<=list_T[i][z+1][2]):
											list_T[i][j][2] = list_T[x][y][2] + list_T[x][y][3]+list_T[i][j][4]
											# print(list_T[i][j])
											# print("------------------")
											list_T[i].insert(z + 1, list_T[i][j])

											del list_T[i][j + 1]
											this_job = self.getind(list_T[i][z + 1], job)
											next_job = self.getind(list_T[i][z + 2], job)
											job[0].insert(next_job,job[0][this_job])
											del job[0][this_job + 1]


											break
										elif (list_T[x][y][2]+list_T[x][y][3]>=list_T[i][z][2]+list_T[i][z][3]) and (list_T[x][y][2]+list_T[x][y][3]+list_T[i][j][4]+list_T[i][j][3]<=list_T[i][z+1][2]):
											list_T[i][j][2] = list_T[x][y][2] + list_T[x][y][3] + list_T[i][j][4]
											# print(list_T[i][j])
											# print(list_T[x][y])
											# print("------------------")
											list_T[i].insert(z + 1, list_T[i][j])

											del list_T[i][j + 1]
											this_job = self.getind(list_T[i][z + 1], job)
											next_job = self.getind(list_T[i][z + 2], job)

											job[0].insert(next_job,job[0][this_job])

											del job[0][this_job + 1]

											# print(list_T)
											break
										elif (j==len(list_T[i]) and list_T[x][y][2]+list_T[x][y][3]+list_T[i][j][4]>=list_T[i][z][2]+list_T[i][z][3]):
											list_T[i][j][2]=list_T[x][y][2]+list_T[x][y][3]
											break
										elif (j==len(list_T[i]) and list_T[x][y][2]+list_T[x][y][3]+list_T[i][j][4]<=list_T[i][z][2]+list_T[i][z][3]):
											list_T[i][j][2] = list_T[i][z][2] + list_T[i][z][3]
											break

			job=np.array(job)

			tmm = np.zeros((1, self.machine_num))
			ind= np.zeros((1, self.job_num))
			list_M, list_S, list_W, = [], [], []
			for i in range(job.shape[1]):
				x = int(job[0, i])
				ind[0, int(job[0][i])] += 1
				y=int(ind[0, int(job[0][i])])
				# print(type(y))
				# print(y)
				# print(x)
				for j in range(len(list_T)):
					for k in range(len(list_T[j])):
						if(list_T[j][k][0]==x) and (list_T[j][k][1]==y):
							list_S.append(list_T[j][k][2])
							list_M.append(j)
							list_W.append(list_T[j][k][3])
							tmm[0,j]=max(list_T[j][k][2]+list_T[j][k][3],tmm[0,j])



			trest = tmm - tmmw
			E_all = sum((tmmw * p1)[0]) + sum((trest * p2)[0 - 1]) + sum((trantime*1.5)[0])#加工功率+空载功率+运输功率
			tmax = np.argmax(tmm[0])		#结束最晚的机器

			C_finish=max(tmm[0])			#最晚完工时间
			Twork = sum(tmmw[0])  # 机器负荷

			# print(C_finish)
			# print("-----------------")
			# print(job)
			#
			# print(trantime)
			return C_finish, Twork, E_all, list_M, list_S, list_W, tmax, list_T

	# *** 新增：疲劳历史绘图函数 ***
	def plot_fatigue_history(self, fatigue_history, max_fatigue_threshold=None, title="工人疲劳变化曲线 (插值模拟)",
							 points_per_segment=20):
		"""
        绘制工人疲劳历史曲线，对恢复段进行指数插值以获得更平滑的视觉效果。

        Args:
            fatigue_history (dict): {worker_idx: [(time, fatigue_level), ...]}
            max_fatigue_threshold (float, optional): 要绘制的疲劳阈值线。
            title (str): 图表标题。
            points_per_segment (int): 在每个恢复段插入的点数，用于平滑曲线。
        """
		if not fatigue_history:
			print("没有疲劳历史数据可绘制。")
			return

		plt.figure(figsize=(18, 8))  # 稍微加宽
		num_workers = self.work_num
		cmap = plt.cm.get_cmap('tab10' if num_workers <= 10 else ('tab20' if num_workers <= 20 else 'viridis'),
							   num_workers)

		max_time = 0
		active_workers = 0

		print("开始绘制疲劳曲线 (带插值)...")
		for worker_idx in range(num_workers):
			if worker_idx in fatigue_history and len(fatigue_history[worker_idx]) > 1:
				# 获取并排序数据点
				history_sorted = sorted(fatigue_history[worker_idx], key=lambda x: x[0])
				times, fatigues = zip(*history_sorted)

				plot_times = []
				plot_fatigues = []

				# 遍历时间段进行插值
				for i in range(len(times) - 1):
					t1, f1 = times[i], fatigues[i]
					t2, f2 = times[i + 1], fatigues[i + 1]
					duration = t2 - t1

					# 添加段的起始点
					plot_times.append(t1)
					plot_fatigues.append(f1)

					if duration <= 0:  # 避免零时长或时间倒流
						continue

					# 判断是工作段还是恢复段
					# 注意：简单比较 f2 和 f1 可能不准确，因为工作后也可能因取整等原因疲劳不变或微降
					# 更可靠的方式是判断 t1 到 t2 是否有任务执行，但这需要额外信息
					# 简化处理：如果疲劳下降，认为是恢复段；否则认为是工作段或平台期
					if f2 < f1 - 1e-6:  # 认为是恢复段 (减去一个小的容差)
						# *** 指数插值恢复段 ***
						# 在 t1 和 t2 之间生成 points_per_segment 个时间点
						interp_times = np.linspace(t1, t2, points_per_segment + 2)[1:-1]  # 排除首尾点
						for t_interp in interp_times:
							time_elapsed = t_interp - t1
							# 应用恢复公式: f = f1 * exp(-u * time_elapsed)
							f_interp = f1 * math.exp(-self.u * time_elapsed)
							f_interp = max(0.0, f_interp)  # 确保不为负
							plot_times.append(t_interp)
							plot_fatigues.append(f_interp)
					else:
						# *** 线性绘制工作段或平台期 ***
						# (可选) 如果需要更精确的工作段曲线，可以在此实现工作累积公式的插值
						# 这里简单地用直线连接，即只添加了起始点，下一个循环会添加结束点
						pass  # Matplotlib 会自动用直线连接 (t1, f1) 和 (t2, f2)

				# 添加段的结束点 (下一个循环的起始点会处理)
				# 但为了确保最后一个点被绘制，需要在循环外添加
				# 这里逻辑有点重复，改进：在循环开始前加第一个点，循环内加结束点

				# --- 改进后的循环逻辑 ---
				plot_times_new = []
				plot_fatigues_new = []
				if times:  # 确保有数据
					plot_times_new.append(times[0])  # 添加第一个点
					plot_fatigues_new.append(fatigues[0])

				for i in range(len(times) - 1):
					t1, f1 = times[i], fatigues[i]
					t2, f2 = times[i + 1], fatigues[i + 1]
					duration = t2 - t1

					if duration <= 0: continue

					if f2 < f1 - 1e-6:  # 恢复段 - 指数插值
						interp_times = np.linspace(t1, t2, points_per_segment + 2)[1:]  # 包含结束点 t2
						for t_interp in interp_times:
							time_elapsed = t_interp - t1
							f_interp = f1 * math.exp(-self.u * time_elapsed)
							plot_times_new.append(t_interp)
							plot_fatigues_new.append(max(0.0, f_interp))
					else:  # 工作段或平台期 - 只添加结束点，让 plot 画直线
						plot_times_new.append(t2)
						plot_fatigues_new.append(f2)

				# --- 结束改进循环 ---

				# 绘制最终的插值/连接后的曲线
				if plot_times_new:
					plt.plot(plot_times_new, plot_fatigues_new, marker='.', markersize=3, linestyle='-',
							 color=cmap(worker_idx), label=f'工人 {worker_idx + 1}')
					max_time = max(max_time, plot_times_new[-1])
					active_workers += 1

		if active_workers == 0:
			print("所有工人都无有效活动记录，无法绘制疲劳曲线。")
			plt.close()
			return

		if max_fatigue_threshold is not None:
			plt.axhline(y=max_fatigue_threshold, color='r', linestyle='--', linewidth=1.5,
						label=f'疲劳阈值 ({max_fatigue_threshold:.2f})')

		plt.xlabel("时间")
		plt.ylabel("疲劳水平")
		plt.title(title)
		plt.ylim(-0.05, 1.05)
		plt.xlim(0, max_time * 1.05 if max_time > 0 else 10)
		plt.legend(bbox_to_anchor=(1.02, 1), loc='upper left', title="图例")
		plt.grid(True, linestyle=':', alpha=0.7)
		plt.tight_layout(rect=[0, 0, 0.88, 1])  # 调整右边距给图例
		save_path = "fatigue_history_interpolated.png"
		plt.savefig(save_path, dpi=300)
		# print(f"带插值的疲劳历史曲线已保存为 {save_path}")
		plt.show()

	def draw(self,breakdowns, list_T,C_finish,Twork,E_all):
		# C_finish, Twork, E_all,_,list_T, list_M, list_S, list_W, tmmw, Wmax, _ ,_= self.recaculate(job, machine,
		# 																						 machine_time, trantime,
		# 																						 Wc,breakdowns,record_fatigue_history=False)

		plt.figure(figsize=(15, 8))
		colors = [
					 '#FFB6C1', '#87CEFA', '#98FB98', '#DDA0DD', '#FFA07A',
					 '#20B2AA', '#9370DB', '#F08080', '#7B68EE', '#FFD700',
					 '#7FFF00', '#BA55D3', '#00FA9A', '#FF69B4', '#4169E1',
					 '#8B4513', '#8FBC8F', '#B22222', '#4B0082', '#2E8B57'
				 ] * 3  # 扩展颜色列表保证足够颜色

		# ========== 绘制故障区间==========
		if not isinstance(breakdowns, dict):
			print(f"警告：'breakdowns' 格式非字典，跳过故障绘制。")
		else:
			# 遍历字典: machine_idx_actual 是机器索引(key), bd_list 是 [(start, duration),...] 列表(value)
			for machine_idx_actual, bd_list in breakdowns.items():
				# 检查 machine_idx_actual 是否在有效范围内
				if not (isinstance(machine_idx_actual, int) and 0 <= machine_idx_actual < self.machine_num):
					print(f"警告: 故障机器索引 {machine_idx_actual} 无效，跳过。")
					continue

				y_pos = machine_idx_actual  # *** 直接使用机器索引作为Y轴位置 ***

				if not isinstance(bd_list, list):
					print(f"警告：机器 {machine_idx_actual} 的故障数据格式不是列表，跳过。")
					continue

				# 循环处理该机器上的每一个故障区间
				for bd_idx, (bd_start, bd_duration) in enumerate(bd_list):  # 使用 enumerate 获取索引用于偏移（如果需要）
					if not (isinstance(bd_start, (int, float)) and isinstance(bd_duration,
																			  (int, float)) and bd_duration > 0):
						print(f"警告: 机器 {machine_idx_actual} 的故障时间数据无效 ({bd_start}, {bd_duration})，跳过。")
						continue

					# print(
					# 	f"  绘制故障: M{machine_idx_actual + 1} at y={y_pos}, time=[{bd_start}, {bd_start + bd_duration}]")
					# 绘制故障条 (置于顶层，带图案)
					# vertical_offset = 0.1 * (bd_idx % 3) # 可以选择性保留或移除偏移
					vertical_offset = 0  # 移除垂直偏移，直接画在机器行上
					plt.barh(y=y_pos + vertical_offset,  # 使用 Y 位置
							 width=bd_duration,  # 故障持续时间
							 left=bd_start,  # 故障开始时间
							 height=0.6,  # 条的高度
							 color='grey',  # 颜色
							 edgecolor='red',  # 边框颜色
							 hatch='///',  # 填充图案
							 alpha=0.75,  # 透明度
							 zorder=3)  # *** 确保在工序条之上 ***

					# 添加故障文本标注
					plt.text(x=bd_start + bd_duration / 2,
							 y=y_pos + vertical_offset + 0.35,  # 文本在条上方
							 s=f'故障\n[{bd_start}-{bd_start + bd_duration}]',  # 文本内容
							 ha='center',
							 va='bottom',
							 fontsize=8,
							 color='darkred',
							 bbox=dict(facecolor='white', alpha=0.7, boxstyle="round,pad=0.1"),
							 zorder=4)  # 确保文本在最上层
		# ========== 绘制工序块 ==========
		for i in range(self.job_num):
			for j in range(len(list_T)):
				for z in range(len(list_T[j])):
					if list_T[j][z][0] == i:
						machine_idx = j
						start_time = list_T[j][z][2]
						duration = list_T[j][z][3]
						worker_id = list_T[j][z][5]

						# 绘制主工序块
						plt.barh(y=machine_idx,
								 width=duration,
								 left=start_time,
								 height=0.5,
								 color=colors[i % len(colors)],
								 edgecolor='black',
								 zorder=2)  # 设置图层在顶层

						# 添加工序信息
						plt.text(start_time + duration / 2,
								 machine_idx,
								 # f'J{i + 1}\nW{int(worker_id)}',
								 f'{int(worker_id)}\n{i + 1}',
								 ha='center',
								 va='center',
								 color='black',
								 fontsize=12)

						# 绘制运输时间（如果存在）
						if list_T[j][z][4] > 0:
							plt.barh(y=machine_idx + 0.35,
									 width=list_T[j][z][4],
									 left=start_time - list_T[j][z][4],
									 height=0.1,
									 color=colors[i % len(colors)],
									 edgecolor='black',
									 alpha=0.6)

		# ========== 图表美化 ==========
		plt.xlabel("Time", fontsize=14, fontweight='bold')
		plt.ylabel("Machine", fontsize=14, fontweight='bold')
		plt.yticks(
			ticks=range(self.machine_num),
			labels=[f'M{i + 1}' for i in range(self.machine_num)],
			fontsize=12
		)
		plt.xticks(fontsize=12)
		plt.grid(axis='x', linestyle='--', alpha=0.6)
		legend_elements_breakdown = [Patch(facecolor='grey', edgecolor='red', hatch='///', alpha=0.75, label='故障期')]
		# 添加工艺路线图例
		legend_elements = [
			plt.Rectangle((0, 0), 1, 1, fc=colors[i], ec='black')
			for i in range(self.job_num)
		]
		plt.legend(legend_elements,
				   [f'Job {i + 1}' for i in range(self.job_num)],
				   bbox_to_anchor=(1.05, 1),
				   loc='upper left')

		plt.title(f"Schedule breakdown Gantt Chart\nMakespan: {C_finish} | Energy: {E_all:.1f}", pad=20)
		plt.tight_layout()
		plt.savefig('GTT-breakdown.png', dpi=300, bbox_inches='tight')
		plt.show()
	def select_different_number(self, list, number):
		while True:
			if len(list) == 1:
				return number,0
			else:
				random_number = np.random.choice(list)
				random_index = list.index(random_number)
				if random_number != number:
					return random_number,random_index

	def select_different_number1(self, list, number):
		while True:
			if len(list) == 1:
				return number
			else:
				random_number = np.random.choice(list)
				if random_number != number:
					return random_number
	def find_time(self,List_T,job_id,gx_id):
		for i in range(0,self.machine_num):
			for j in range(0,len(List_T[i])):

				if List_T[i][j][0] == job_id and List_T[i][j][1] == gx_id :
					return List_T[i][j][2]+List_T[i][j][3]



# Tmachine:为工件工序的可选机器集 [][][]
# Tmachinetime：上边列表对应的时间
# tdx：工序可选机器个数 [][]
# work：工件工序表  012222 333这种
# # work-arr：机器可选工人集 [][]
# work_num 工人数
	def draw2(self, job, machine, machine_time, trantime, Wc,WC_W1,list_T,C_finish,Twork,E_all):#画图
		# C_finish, _, list_T, list_M, list_S, list_W, tmmw, Wmax, Twork, _, E_all = self.caculate(job, machine, machine_time, trantime, Wc)
		# C_finish, Twork, E_all, list_M, list_S, list_W, tmax, a = self.plugin(list_T, M, S, W, job, tmmw, trantime)
		plt.figure(figsize=(15, 8))
		colors = [
					 '#FFB6C1', '#87CEFA', '#98FB98', '#DDA0DD', '#FFA07A',
					 '#20B2AA', '#9370DB', '#F08080', '#7B68EE', '#FFD700',
					 '#7FFF00', '#BA55D3', '#00FA9A', '#FF69B4', '#4169E1',
					 '#8B4513', '#8FBC8F', '#B22222', '#4B0082', '#2E8B57'
				 ] * 3  # 扩展颜色列表保证足够颜色
		# ========== 绘制工序块 ==========
		for i in range(self.job_num):
			for j in range(len(list_T)):
				for z in range(len(list_T[j])):
					if list_T[j][z][0] == i:
						machine_idx = j
						start_time = list_T[j][z][2]
						duration = list_T[j][z][3]
						worker_id = WC_W1[i][int(list_T[j][z][1] - 1)]

						# 绘制主工序块
						plt.barh(y=machine_idx,
								 width=duration,
								 left=start_time,
								 height=0.5,
								 color=colors[i % len(colors)],
								 edgecolor='black',
								 zorder=2)  # 设置图层在顶层

						# 添加工序信息
						plt.text(start_time + duration / 2,
								 machine_idx,
								 # f'J{i + 1}\nW{int(worker_id)}',
								 f'{int(worker_id)}\n{i + 1}',
								 ha='center',
								 va='center',
								 color='black',
								 fontsize=12)

						# 绘制运输时间（如果存在）
						if list_T[j][z][4] > 0:
							plt.barh(y=machine_idx + 0.35,
									 width=list_T[j][z][4],
									 left=start_time - list_T[j][z][4],
									 height=0.1,
									 color=colors[i % len(colors)],
									 edgecolor='black',
									 alpha=0.6)

		# ========== 图表美化 ==========
		plt.xlabel("Time", fontsize=14, fontweight='bold')
		plt.ylabel("Machine", fontsize=14, fontweight='bold')
		plt.yticks(
			ticks=range(self.machine_num),
			labels=[f'M{i + 1}' for i in range(self.machine_num)],
			fontsize=12
		)
		plt.xticks(fontsize=12)
		plt.grid(axis='x', linestyle='--', alpha=0.6)

		# 添加工艺路线图例
		legend_elements = [
			plt.Rectangle((0, 0), 1, 1, fc=colors[i], ec='black')
			for i in range(self.job_num)
		]
		plt.legend(legend_elements,
				   [f'Job {i + 1}' for i in range(self.job_num)],
				   bbox_to_anchor=(1.05, 1),
				   loc='upper left')

		plt.title(f"Schedule Gantt Chart\nMakespan: {C_finish} | Energy: {E_all:.1f}", pad=20)
		plt.tight_layout()
		plt.savefig('GTT.png', dpi=300, bbox_inches='tight')
		plt.show()

	def set_breakpoint(self, time, completed_ops):
		"""设置故障断点信息"""
		self.breakdown_time = time
		self.completed_ops = set(completed_ops)

	def rebuild_problem(self, job, machine, completed_ops):
		# 初始化新的三维结构
		new_Tmachine = []
		new_Tmachinetime = []

		# 遍历每个工件
		for job_id in range(self.job_num):
			job_ops = []  # 当前工件的所有工序（未完成的）
			time_ops = []  # 当前工序的加工时间选项

			# 获取该工件的原始工序总数
			total_ops = len(self.Tmachine[job_id])

			# 遍历该工件的每个工序
			for op_idx in range(total_ops):
				# 检查是否已完成 (job_id, op_idx+1)
				if (job_id, op_idx + 1) in completed_ops:
					continue  # 跳过已完成的工序

				# 保留未完成工序的机器选项和加工时间
				job_ops.append(self.Tmachine[job_id][op_idx])
				time_ops.append(self.Tmachinetime[job_id][op_idx])

			# 将该工件的剩余工序添加到新结构中
			new_Tmachine.append(job_ops)
			new_Tmachinetime.append(time_ops)

		# 更新类属性
		self.Tmachine = new_Tmachine
		self.Tmachinetime = new_Tmachinetime


	def breakdown(self,job,machine,machine_time,trantime,WC,List_T,Machine,To,Tr):   #job machine machine_time 为1*n的np数组
		Machine1 = int(Machine)-1
		Ra = 0.5
		Rb = 0.3
		Rc = 0.2
		temp =0
		tx = 0
		for i in range(0,len(List_T[Machine1])):
			if(List_T[Machine1][i][2]>=To +Tr) or (List_T[Machine1][i][2] + List_T[Machine1][i][3]<=To):
				tx=tx+1
				continue
			#else:
			j = List_T[Machine1][i][0]   #j从0开始
			temp = temp+1
			index = List_T[Machine1][i][1]  #从1开始
			inde =List_T[Machine1][i][1]
			for z in range(0,len(self.work)):
				if job[0][z] == j:
					if index == 1:
						Ro = random.random()
						if Ro <=Ra:
							Mac_cho = self.Tmachine[j][inde-1]
							for ma in Mac_cho:
								ma =ma - 1
								if ma ==Machine1:
									continue
								#else:
								ind = Mac_cho.index(ma+1)
								gx_comp = self.find_time(List_T, j, inde)
								for t in range(0,len((List_T[ma]))):
									if List_T[ma][t][2] >= To and List_T[ma][t][2] - self.Tmachinetime[j][inde -1][ind] >= List_T[ma][t-1][2]+List_T[ma][t-1][3] and List_T[ma][t][2] - self.Tmachinetime[j][inde -1][ind] >= gx_comp:
										machine[0, z] = ma
										machine_time[0, z] = self.Tmachinetime[j][inde - 1][ind]
										WC[0, z], tx = self.select_different_number(
											self.work_arr[int(machine[0, z] - 1)], WC[0, z])







						if Ro >Ra and Ro <= Ra + Rb:
							ind = np.argmin(self.Tmachinetime[j][inde-1])
							if machine[0,z] == self.Tmachine[j][inde-1][ind]:
								ind = np.argsort(self.Tmachinetime[j][inde-1])
								machine[0,z] =self.Tmachine[j][inde-1][ind[1]]-1
								machine_time[0,z]= self.Tmachinetime[j][inde-1][ind[1]]
								WC[0, z], tx = self.select_different_number(self.work_arr[int(machine[0, z] - 1)],
																			WC[0, z])

							else:
								machine[0,z] = self.Tmachine[j][inde-1][ind]-1
								machine_time[0, z] = self.Tmachinetime[j][inde - 1][ind]
								WC[0, z], tx = self.select_different_number(self.work_arr[int(machine[0, z] - 1)],
																			WC[0, z])





						if Ro > Ra + Rb and Ro <= Ra + Rb +Rc :
							machine[0,z],ind=self.select_different_number(self.Tmachine[j][inde-1],machine[0,z]+1)    #变成-1了
							machine[0,z] = machine[0,z]-1
							machine_time[0,z] = self.Tmachinetime[j][inde-1][ind]
							machine_time[0,z] = machine_time[0,z]

							WC[0,z],tx= self.select_different_number(self.work_arr[int(machine[0,z]-1)],WC[0,z])

					else:
						index=index-1


		return machine,machine_time,trantime,WC,temp

	def displaced(self,job,machine,machine_time,trantime,WC,list_T,out_p,To,Tr):
		tx = 0
		temp = 0
		for w in range(10):
			for i in range(0,len(list_T)):
				for j in range(0,len(list_T[i])):
					if ((list_T[i][j][2] >= To + Tr) or (list_T[i][j][2] + list_T[i][j][3] <= To)) and list_T[i][j][5] != out_p:
						tx = tx + 1
						continue

					jo = list_T[i][j][0]  # j从0开始
					temp = temp + 1
					index = list_T[i][j][1]  # 从1开始
					inde = list_T[i][j][1]
					for z in range(0, len(self.work)):
						if job[0][z] == jo:
							if index == 1:
								WC[0,z]= self.select_different_number1(self.work_arr[i],WC[0,z])


							else:
								index = index - 1

			C_finish, tmax, list_T, list_M, list_S, list_W, tmmw, Wmax = self.caculate(job,machine,machine_time,trantime,WC)
		return WC
	def draw_fatigue(self, WC_W1, list_T, C_finish,global_max_fatigue, E_all, fatigue_history=None):
		if fatigue_history is None:
			print("错误：缺少 fatigue_history 数据。")
			fatigue_history = {}

		fig, ax1 = plt.subplots(figsize=(16, 8))
		gantt_colors = plt.cm.get_cmap('tab20', self.job_num)

		# ========== 1. 绘制 Gantt 图工序块 (与之前相同) ==========
		job_legend_handles = {}
		if list_T:
			for j in range(len(list_T)):
				if j < self.machine_num and list_T[j]:
					for z in range(len(list_T[j])):
						op_detail = list_T[j][z]
						if isinstance(op_detail, (list, tuple)) and len(op_detail) >= 6:
							job_id, op_seq, start_time, duration, transfer_dur, worker_id_1based = op_detail
							machine_idx = j
							job_color = gantt_colors(job_id / max(1, self.job_num - 1))
							bar = ax1.barh(y=machine_idx, width=duration, left=start_time, height=0.5,
										   color=job_color, edgecolor='black', zorder=2)
							ax1.text(start_time + duration / 2, machine_idx,
									 f'{int(worker_id_1based)}\n{job_id + 1}-{op_seq}',
									 ha='center', va='center', color='black', fontsize=8, weight='medium', zorder=2.1)
							if transfer_dur > 0:
								ax1.barh(y=machine_idx + 0.3, width=transfer_dur, left=start_time - transfer_dur,
										 height=0.1, color=job_color, edgecolor='grey', alpha=0.6, zorder=1)
							if job_id not in job_legend_handles: job_legend_handles[job_id] = bar

		# ========== 2. 设置 Gantt 图坐标轴 (与之前相同) ==========
		ax1.set_xlabel("时间 (Time)", fontsize=14, fontweight='bold')
		ax1.set_ylabel("机器 (Machine)", fontsize=14, fontweight='bold')
		ax1.set_yticks(ticks=range(self.machine_num))
		ax1.set_yticklabels([f'M{i + 1}' for i in range(self.machine_num)], fontsize=11)
		if C_finish > 0:
			tick_step = max(25, int(C_finish / 15 / 25) * 25)
			ax1.set_xticks(np.arange(0, C_finish + tick_step, tick_step))
		ax1.tick_params(axis='x', labelsize=11)
		ax1.grid(axis='x', linestyle=':', alpha=0.5, color='grey', zorder=0)
		ax1.set_xlim(left=-5)
		ax1.set_ylim(bottom=-0.5, top=self.machine_num - 0.5)

		# ========== 3. 绘制疲劳曲线 (使用 B-spline 平滑所有段，用不同虚线) ==========
		ax2 = ax1.twinx()
		fatigue_legend_handles = []
		max_time_fatigue = 0

		if fatigue_history:
			fatigue_colors = plt.cm.get_cmap('tab10', self.work_num)
			# *** 定义虚线样式列表 ***
			fatigue_linestyles = [':']

			for worker_idx in range(self.work_num):
				history = fatigue_history.get(worker_idx)
				# 需要至少 k+1 个点才能进行 k 次样条插值 (k=3)
				if history and len(history) > 3:
					history_sorted = sorted(history, key=lambda x: x[0])
					times_orig, fatigues_orig = zip(*history_sorted)

					# 查找首次工作时间点 (或疲劳 > 0 的点)
					start_plot_index = 0
					for idx, f_val in enumerate(fatigues_orig):
						if f_val > 1e-6 and idx > 0:
							start_plot_index = max(0, idx - 1)
							break
						elif idx == len(fatigues_orig) - 1:
							start_plot_index = -1

					if start_plot_index != -1 and (len(times_orig) - start_plot_index) > 3:  # 确保剩余点数仍大于3
						times_to_plot = np.array(times_orig[start_plot_index:])
						fatigues_to_plot = np.array(fatigues_orig[start_plot_index:])

						# *** 使用 PCHIP 插值 ***
						try:
							unique_times, unique_indices = np.unique(times_to_plot, return_index=True)
							if len(unique_times) > 1:  # PCHIP 至少需要2个点
								unique_fatigues = fatigues_to_plot[unique_indices]
								pchip = PchipInterpolator(unique_times, unique_fatigues)
								times_smooth = np.linspace(unique_times.min(), unique_times.max(), 300)
								fatigues_smooth = pchip(times_smooth)
								# 仍然需要裁剪，因为 PCHIP 不保证严格在数据点范围内
								fatigues_smooth = np.clip(fatigues_smooth, 0, self.MAXFG + 0.01)  # 稍微放宽一点点
							else:
								times_smooth = times_to_plot;
								fatigues_smooth = fatigues_to_plot
						except Exception as e:
							print(f"警告: 工人 {worker_idx + 1} PCHIP 插值失败 ({e})，将使用原始折线。")
							times_smooth = times_to_plot;
							fatigues_smooth = fatigues_to_plot

						# 绘制平滑曲线，使用不同的虚线样式
						worker_color = fatigue_colors(worker_idx / max(1, self.work_num - 1)) if hasattr(fatigue_colors,
																										 'viridis') else fatigue_colors(
							worker_idx % fatigue_colors.N)
						worker_ls = fatigue_linestyles[worker_idx % len(fatigue_linestyles)]  # *** 获取虚线样式 ***
						line, = ax2.plot(times_smooth, fatigues_smooth,
										 linestyle=worker_ls,  # *** 应用虚线样式 ***
										 color=worker_color,
										 linewidth=1.5,
										 alpha=0.9,
										 label=f'工人 {worker_idx + 1}')
						fatigue_legend_handles.append(line)
						max_time_fatigue = max(max_time_fatigue, times_to_plot.max())
			# (如果历史记录点数不足，则不绘制该工人曲线)

			# 绘制疲劳阈值线 (虚线，较低 zorder)
			if self.MAXFG is not None:
				thresh_line = ax2.axhline(y=self.MAXFG, color='red', linestyle=':', linewidth=1.2,
										  label=f'疲劳阈值 ({self.MAXFG:.2f})', zorder=1.5)
				fatigue_legend_handles.append(thresh_line)

			# 设置疲劳轴
			ax2.set_ylabel("疲劳水平 (Fatigue Level)", fontsize=12, color='dimgrey')
			y_min, y_max = -0.05, self.MAXFG + 0.15
			ax2.set_ylim(y_min, y_max)
			ax2.tick_params(axis='y', labelsize=10, colors='dimgrey')
			tick_interval = 0.1
			yticks_major = np.arange(0, y_max + tick_interval / 2, tick_interval)
			# 应用主要刻度
			ax2.set_yticks(yticks_major)
			# 设置刻度标签格式 (可选，例如保留两位小数)
			ax2.yaxis.set_major_formatter(plt.FormatStrFormatter('%.1f'))  # 保留一位小数
			ax2.tick_params(axis='y', labelsize=10, colors='dimgrey')
			ax2.spines['right'].set_color('dimgrey')
			# 增加 Y 轴网格线 (可选)
			ax2.grid(axis='y', linestyle=':', alpha=0.5, color='grey')
		else:
			ax2.set_visible(False)

		# 调整整体 X 轴范围
		final_max_time = max(C_finish, max_time_fatigue)
		ax1.set_xlim(left=-5, right=final_max_time * 1.05 if final_max_time > 0 else 100)

		# ========== 4. 合并图例 ==========
		handles1 = list(job_legend_handles.values())
		labels1 = [f'Job {i + 1}' for i in job_legend_handles.keys()]
		handles2 = fatigue_legend_handles
		labels2 = [h.get_label() for h in handles2]

		ax1.legend(handles1 + handles2, labels1 + labels2,
				   bbox_to_anchor=(1.05, 1), loc='upper left', fontsize=9,
				   title="图例 (Legend)", title_fontsize='10')

		# ========== 5. 设置标题和布局 ==========
		# plt.title(f"甘特图与工人疲劳曲线\n完工时间: {C_finish:.1f} | 能耗: {E_all:.1f}| 疲劳: {global_max_fatigue}", pad=20, fontsize=16)
		fig.tight_layout(rect=[0, 0, 1, 1])
		save_path = 'GTT_with_Fatigue.png'
		plt.savefig(save_path, dpi=300)
		print(f"改进后的组合图已保存为 {save_path}")
		plt.show()

	def NSGA_caculate(self, job, machine, machine_time, trantime, WC, record_fatigue_history=False):
		# --- 初始变量定义 (保持不变) ---
		jobtime = np.zeros((1, self.job_num))
		tmm = np.zeros((1, self.machine_num))
		work_time = np.zeros((1, self.work_num))  # 记录工人完成上个任务的时间
		tmmw = np.zeros((1, self.machine_num))  # 理论工作时间 (仅加工)
		max_fatigue_per_worker = np.zeros((1, self.work_num))
		worker_fatigue_level = np.zeros((1, self.work_num))  # 当前疲劳状态

		list_M, list_S, list_W, list_WO = [], [], [], []
		list_T = [[] for _ in range(self.machine_num)]
		inde = np.zeros((1, self.job_num))

		fatigue_history = {w: [(0, 0.0)] for w in range(self.work_num)} if record_fatigue_history else None
		worker_efficiency = self.worker_efficiency_factors
		worker_recovery = self.worker_recovery
		# 创建一个字典来存储详细的调度信息，用于回溯关键路径
		scheduling_details = {}

		# 为了回溯，我们需要知道每个机器和工人上一个完成的任务是什么
		# key: 资源索引 (e.g., machine_id), value: 工序标识元组 (job_id, op_seq)
		last_op_on_machine = {}
		last_op_for_worker = {}

		# --- 主循环 (对每个工序进行调度) ---
		for i in range(job.shape[1]):
			svg, sig, swg = int(job[0, i]), int(machine[0, i]), int(WC[0, i] - 1)
			op_duration = machine_time[0, i] * worker_efficiency[swg]
			transfer_t = trantime[0, i]
			op_seq = int(inde[0, svg] + 1)  # 当前工序号 (从1开始)

			# 记录决定开始时间的三个前驱时间点
			machine_ready_time = tmm[0, sig]
			worker_ready_time = work_time[0, swg]
			job_ready_time = jobtime[0, svg] + transfer_t

			# --- 1. 计算基础开始时间 (不含休息) ---
			base_start_time = max(job_ready_time, machine_ready_time, worker_ready_time)

			# --- 2. 计算并应用自然空闲恢复 ---
			current_worker_recovery_rate = worker_recovery[swg]
			natural_idle_time = max(0, base_start_time - work_time[0, swg])  # 空闲时间是相对于工人上次完成时间
			fatigue_before_idle = worker_fatigue_level[0, swg]
			fatigue_after_idle = fatigue_before_idle * math.exp(-current_worker_recovery_rate * natural_idle_time)
			fatigue_after_idle = max(0.0, fatigue_after_idle)

			# 记录空闲恢复点
			if record_fatigue_history and natural_idle_time > 1e-6:
				time_point = base_start_time
				fatigue_point = fatigue_after_idle
				if not fatigue_history[swg] or fatigue_history[swg][-1][0] < time_point:
					fatigue_history[swg].append((time_point, fatigue_point))
				elif fatigue_history[swg][-1][0] == time_point:
					fatigue_history[swg][-1] = (time_point, min(fatigue_history[swg][-1][1], fatigue_point))

			# --- 3. 计算强制休息时间 ---
			current_fatigue_for_rest_calc = fatigue_after_idle
			final_rest_duration = 0
			predicted_fatigue_final = 1 - (1 - current_fatigue_for_rest_calc) * math.exp(
				-self.worker_fatigue[swg] * op_duration)
			if predicted_fatigue_final > self.MAXFG:
				required_rest = self._calculate_required_rest(current_fatigue_for_rest_calc, op_duration,
															  self.worker_fatigue[swg], current_worker_recovery_rate, self.MAXFG)
				final_rest_duration = math.ceil(required_rest)

			# --- 4. 计算最终开始时间 ---
			startime = base_start_time + final_rest_duration
			endtime = startime + op_duration

			# --- 5. 更新疲劳状态和记录历史 ---
			fatigue_after_forced_rest = fatigue_after_idle * math.exp(-current_worker_recovery_rate * final_rest_duration)
			fatigue_after_forced_rest = max(0.0, fatigue_after_forced_rest)

			if record_fatigue_history:
				# 记录工序实际开始时的疲劳点
				time_point = startime
				fatigue_point = fatigue_after_forced_rest
				if not fatigue_history[swg] or fatigue_history[swg][-1][0] < time_point:
					fatigue_history[swg].append((time_point, fatigue_point))
				elif fatigue_history[swg][-1][0] == time_point:
					fatigue_history[swg][-1] = (time_point, fatigue_point)

			fatigue_at_op_start = fatigue_after_forced_rest
			fatigue_after_work = 1 - (1 - fatigue_at_op_start) * math.exp(-self.worker_fatigue[swg] * op_duration)
			fatigue_after_work = min(fatigue_after_work, self.MAXFG)
			worker_fatigue_level[0, swg] = fatigue_after_work
			if fatigue_after_work > max_fatigue_per_worker[0, swg]:
				max_fatigue_per_worker[0, swg] = fatigue_after_work

			if record_fatigue_history:
				# 记录工序结束点
				time_point = endtime
				fatigue_point = fatigue_after_work
				if not fatigue_history[swg] or fatigue_history[swg][-1][0] < time_point:
					fatigue_history[swg].append((time_point, fatigue_point))
				elif fatigue_history[swg][-1][0] == time_point:
					fatigue_history[swg][-1] = (time_point, fatigue_point)

			# --- 6. 更新时间表和 list_T ---
			inde[0, svg] += 1
			tmm[0, sig] = endtime
			jobtime[0, svg] = endtime
			work_time[0, swg] = endtime

			list_M.append(sig)
			list_S.append(startime)
			list_W.append(op_duration)
			list_T[sig].append(
				[svg, op_seq, int(round(startime)), int(round(op_duration)), int(round(transfer_t)), swg + 1]
			)
			tmmw[0, sig] += op_duration
			list_WO.append(swg)

			# 【新增】存储详细信息用于关键路径回溯
			op_key = (svg, op_seq)
			predecessor_op_key = (svg, op_seq - 1) if op_seq > 1 else None

			scheduling_details[op_key] = {
				'start_time': startime,
				'end_time': endtime,
				'machine_id': sig,
				'worker_id': swg,
				'op_duration': op_duration,
				'job_predecessor': predecessor_op_key,  # 工件的前驱 (op_key)
				'machine_predecessor': last_op_on_machine.get(sig, None),  # 机器上的前驱 (op_key)
				'worker_predecessor': last_op_for_worker.get(swg, None),  # 工人上的前驱 (op_key)
				'machine_ready_time': machine_ready_time,  # 记录三个关键时间
				'worker_ready_time': worker_ready_time,
				'job_ready_time': job_ready_time
			}

			# 更新 last_op 记录
			last_op_on_machine[sig] = op_key
			last_op_for_worker[swg] = op_key

		# --- 计算最终目标值 (保持不变) ---
		C_finish = np.max(tmm[0]) if tmm[0].size > 0 else 0
		Twork = np.sum(tmmw[0])
		p1 = np.array([self.M_dicr[m][1] for m in range(self.machine_num)])
		p2 = np.array([self.M_dicr[m][2] for m in range(self.machine_num)])

		machine_idle_time = np.zeros_like(tmmw)
		for m in range(self.machine_num):
			machine_finish_time = tmm[0, m]
			processing_time_on_m = sum(item[3] for item in list_T[m])
			machine_idle_time[0, m] = max(0, machine_finish_time - processing_time_on_m)
		trest = machine_idle_time

		total_transfer_time_sum = np.sum(trantime[0])
		transfer_energy = total_transfer_time_sum * 1.5
		E_all = np.sum(tmmw * p1) + np.sum(trest * p2) + transfer_energy

		tmax_idx = np.argmax(tmm[0]) if tmm[0].size > 0 else -1
		tmax = tmax_idx + 1 if tmax_idx != -1 else 0

		Wmax_idx = np.argmax(work_time[0]) if work_time[0].size > 0 else -1
		Wmax = Wmax_idx + 1 if Wmax_idx != -1 else 0

		global_max_fatigue = np.max(max_fatigue_per_worker) if max_fatigue_per_worker.size > 0 else 0

		# 【修改】统一返回值格式，并在末尾添加 scheduling_details
		result_tuple = (
			C_finish, tmax, list_T, list_M, list_S, list_W,
			tmmw[0], Wmax, Twork, global_max_fatigue, E_all,
			scheduling_details
		)

		if record_fatigue_history:
			for w_idx in fatigue_history:
				if len(fatigue_history[w_idx]) > 1:
					cleaned_history = [fatigue_history[w_idx][0]]
					for k in range(1, len(fatigue_history[w_idx])):
						# 仅保留值发生变化的点
						if abs(fatigue_history[w_idx][k][1] - cleaned_history[-1][1]) > 1e-9:
							cleaned_history.append(fatigue_history[w_idx][k])
					fatigue_history[w_idx] = cleaned_history
			# 将fatigue_history添加到返回元组的末尾
			return result_tuple + (fatigue_history,)
		else:
			return result_tuple

	def _predict_fatigue_increase(self, worker_0based_idx, current_fatigue, op_duration):
		"""
        一个轻量级的函数，用于预估单个任务对工人疲劳度的影响。
        逻辑来源于NSGA_caculate，但只计算疲劳增量，不进行完整调度。

        :param worker_0based_idx: 操作工人的索引 (0-based)。
        :param current_fatigue: 该工人在执行此任务前的当前累计疲劳度。
        :param op_duration: 该任务的加工时长。
        :return: 执行完此任务后，工人的新累计疲劳度。
        """
		# 论文中的疲劳累积公式: F_new = 1 - (1 - F_old) * exp(-lambda * T)
		# lambda 是该工人的疲劳累积系数
		lambda_fatigue = self.worker_fatigue[worker_0based_idx]

		# 注意：这里的模型没有考虑休息和空闲恢复，因为它是一个启发式的预估。
		# 这是一个合理的简化，因为在初始化阶段，我们无法知道确切的开始/结束时间。
		new_fatigue = 1 - (1 - current_fatigue) * math.exp(-lambda_fatigue * op_duration)

		# 确保疲劳度不超过阈值 (虽然在预估中，可以暂时忽略)
		# new_fatigue = min(new_fatigue, self.MAXFG)

		return new_fatigue

	def create_job_ensga(self, pop_size, rule_proportions=None):
		"""
        根据ENSGA-II论文中的四种调度规则生成高质量的初始种群。
        :param pop_size: 要生成的种群大小。
        :param rule_proportions: 一个包含四种规则比例的列表或元组，
                                 例如 [0.2, 0.5, 0.2, 0.1] 对应 [GSWF, LSWF, GSWT, LSWT]。
                                 这是论文中通过实验确定的经验值。
        :return: work_job, work_M, work_T, work_tran, work_F, job_init, WC
        """
		if rule_proportions is None:
			# 如果未提供比例，则使用论文中推荐的经验值
			rule_proportions = [0.2, 0.5, 0.2, 0.1]

		# 计算每种规则需要生成的个体数量
		num_gswf = int(pop_size * rule_proportions[0])
		num_lswf = int(pop_size * rule_proportions[1])
		num_gswt = int(pop_size * rule_proportions[2])
		num_lswt = pop_size - num_gswf - num_lswf - num_gswt

		# print(
		# 	f"Initializing population with ENSGA-II rules: GSWF({num_gswf}), LSWF({num_lswf}), GSWT({num_gswt}), LSWT({num_lswt})")

		all_solutions = []
		# 按顺序调用每种规则生成器
		if num_gswf > 0: all_solutions.extend(self._dispatch_rule_generator('GSWF', num_gswf))
		if num_lswf > 0: all_solutions.extend(self._dispatch_rule_generator('LSWF', num_lswf))
		if num_gswt > 0: all_solutions.extend(self._dispatch_rule_generator('GSWT', num_gswt))
		if num_lswt > 0: all_solutions.extend(self._dispatch_rule_generator('LSWT', num_lswt))

		# 将生成的解决方案列表解包成NumPy数组
		work_job_list = [s['job'] for s in all_solutions]
		work_M_list = [s['M'] for s in all_solutions]
		work_T_list = [s['T'] for s in all_solutions]
		work_wc_list = [s['wc'] for s in all_solutions]

		work_job = np.array(work_job_list)
		work_M = np.array(work_M_list)
		work_T = np.array(work_T_list)
		work_wc = np.array(work_wc_list)

		# 重新计算tran和F (work_F在这里没有明确的物理意义，通常设为0)
		work_tran = np.zeros_like(work_job, dtype=float)
		work_F = np.zeros_like(work_job, dtype=float)
		for i in range(pop_size):
			work_tran[i, :] = self.gettran(work_job[i:i + 1], work_M[i:i + 1])

		# 这种启发式方法不直接产生连续的job_init, 我们为每个解创建一个随机的连续编码
		# 这是为了与需要连续编码的算法（如GWO, SGA）兼容
		job_init = np.random.rand(pop_size, len(self.work))

		return work_job, work_M, work_T, work_tran, work_F, job_init, work_wc

	def _dispatch_rule_generator(self, rule_type, num_to_generate):
		"""
        一个通用的调度规则生成器核心逻辑。
        根据指定的规则类型生成调度方案。
        """
		generated_solutions = []
		for _ in range(num_to_generate):
			# 确定评估标准。我们使用加工时间作为疲劳和工时的代理。
			criterion = 'fatigue' if 'F' in rule_type else 'time'
			# 确定是全局(Global)还是局部(Local)重置
			is_global = 'G' in rule_type

			# 1. 确定工件的处理顺序
			job_processing_order = list(range(self.job_num))
			random.shuffle(job_processing_order)

			# 2. 初始化编码和状态数组
			num_total_ops = len(self.work)
			machine_assignment = np.zeros(num_total_ops, dtype=int)
			worker_assignment = np.zeros(num_total_ops, dtype=int)
			time_assignment = np.zeros(num_total_ops, dtype=float)

			# 维护工人疲劳的数组
			worker_load = np.zeros(self.work_num)

			# 追踪每个工件已调度的工序数
			op_counts_per_job = collections.defaultdict(int)

			# 3. 按随机工件顺序，逐个调度所有工序
			for job_id in job_processing_order:
				if not is_global:
					# LSWF/LSWT规则: 在处理新工件时重置负载
					worker_load.fill(0)

				num_ops_in_this_job = np.count_nonzero(np.array(self.work) == job_id)
				for _ in range(num_ops_in_this_job):
					op_seq_in_job = op_counts_per_job[job_id]  # 当前是该工件的第几道工序 (0-based)

					# a. 找到当前工序所有可能的"机器-工人"组合
					possible_assignments = []
					# self.Tmachine的索引是0-based
					available_machines = self.Tmachine[job_id][op_seq_in_job]

					for k, machine_1based in enumerate(available_machines):
						machine_0based = machine_1based - 1
						processing_time = self.Tmachinetime[job_id][op_seq_in_job][k]

						available_workers = self.work_arr[machine_0based]
						for worker_1based in available_workers:
							worker_0based = worker_1based - 1
							possible_assignments.append({
								'machine': machine_0based,
								'worker': worker_0based,
								'time': processing_time
							})

					# b. 评估每个可能分配的“成本” (标准差)，找到最优选择
					best_assignment = None
					min_std_dev = float('inf')

					for assignment in possible_assignments:
						temp_worker_load = worker_load.copy()
						worker_idx = assignment['worker']
						op_duration = assignment['time']

						# 【核心修改】根据规则类型计算负载增量
						if criterion == 'fatigue':
							# 调用疲劳预估函数
							current_fatigue = temp_worker_load[worker_idx]
							new_fatigue = self._predict_fatigue_increase(worker_idx, current_fatigue, op_duration)
							# 更新的是该工人的总疲劳度
							temp_worker_load[worker_idx] = new_fatigue
						else:  # criterion == 'time'
							# 对于时间规则，负载就是加工时间
							temp_worker_load[worker_idx] += op_duration

						current_std_dev = np.std(temp_worker_load)

						if current_std_dev < min_std_dev:
							min_std_dev = current_std_dev
							best_assignment = assignment
						elif abs(current_std_dev - min_std_dev) < 1e-9 and random.random() < 0.5:
							best_assignment = assignment

					# c. 找到这个(job_id, op_seq_in_job)在self.work中的原始绝对索引
					op_abs_idx = -1
					count = 0
					for i in range(len(self.work)):
						if self.work[i] == job_id:
							if count == op_seq_in_job:
								op_abs_idx = i
								break
							count += 1

					# d. 确定了最佳分配，先按原始顺序存储
					machine_assignment[op_abs_idx] = best_assignment['machine']
					worker_assignment[op_abs_idx] = best_assignment['worker'] + 1
					time_assignment[op_abs_idx] = best_assignment['time']

					# 更新工人真实负载
					if criterion == 'fatigue':
						worker_load[best_assignment['worker']] = self._predict_fatigue_increase(
							best_assignment['worker'], worker_load[best_assignment['worker']], best_assignment['time']
						)
					else:
						worker_load[best_assignment['worker']] += best_assignment['time']

					# 更新工件的工序计数器
					op_counts_per_job[job_id] += 1

			# 4. 生成一个随机的工序排序OS，并据此重排MS, WS, TS
			final_os = np.array(self.work, dtype=int)
			np.random.shuffle(final_os)

			final_M = np.zeros_like(machine_assignment, dtype=int)
			final_Wc = np.zeros_like(worker_assignment, dtype=int)
			final_T = np.zeros_like(time_assignment, dtype=float)

			op_counts_for_remap = collections.defaultdict(int)
			for i in range(len(final_os)):
				job_id = final_os[i]
				op_seq = op_counts_for_remap[job_id]  # 0-based

				# 再次找到这个(job_id, op_seq)在self.work中的原始索引
				original_abs_idx = -1
				count = 0
				for k in range(len(self.work)):
					if self.work[k] == job_id:
						if count == op_seq:
							original_abs_idx = k
							break
						count += 1

				# 从之前按原始顺序存储的分配结果中，取出对应的值，放到新的随机顺序的位置上
				final_M[i] = machine_assignment[original_abs_idx]
				final_Wc[i] = worker_assignment[original_abs_idx]
				final_T[i] = time_assignment[original_abs_idx]

				op_counts_for_remap[job_id] += 1

			generated_solutions.append({
				'job': final_os,
				'M': final_M,
				'T': final_T,
				'wc': final_Wc
			})

		return generated_solutions

