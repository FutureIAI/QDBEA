from small_work import data_deal
from fjsp import FJSP
from multi_opt import mul_op
import copy
import numpy as np
import math
import random
import pandas as pd
import json
from scipy.stats import ranksums

from pymoo.indicators.hv import HV
from plot_objectives import Plotting

from SSGWO import ssgwo
from NSGAII import NSGAII
from SGA_LEVY import SGA_LEVY_FJSP
from memetic1 import Memetic


def distanse(x, y):
    return math.sqrt(sum([pow(a - b, 2) for a, b in zip(x, y)]))


def parse_list_t_for_comparison(list_t_data):
    op_info = {}
    if list_t_data is None: return op_info
    for machine_idx, ops_on_machine in enumerate(list_t_data):
        if ops_on_machine:
            for op_detail in ops_on_machine:
                if len(op_detail) >= 3:
                    job_id, op_seq, start_time = op_detail[0], op_detail[1], op_detail[2]
                    key = (job_id, op_seq)
                    op_info[key] = {'start': start_time, 'machine': machine_idx}
    return op_info


def sga_levymain():
    oj = data_deal()
    item_ = oj.item
    job_num = item_["int2"]
    machine_num = item_["M"]
    Tmachine, Tmachinetime, tdx, work, tom, int1, int2, M, M_dicr, tran_time, worker, work_num, worker_fatigue, worker_efficiency_factors, worker_recovery = oj.cacu()
    parm_data = [Tmachine, Tmachinetime, tdx, work, M_dicr, tran_time, int1, worker, work_num, worker_fatigue,
                 worker_efficiency_factors, worker_recovery]
    to = FJSP(job_num, machine_num, parm_data, 100, work)
    oh = mul_op()
    ho = SGA_LEVY_FJSP(1000, 100, to, oh, work, job_num, tran_time, M_dicr, parm_data[7], parm_data[8])
    pareto, pareto_job, pareto_machine, pareto_time, pareto_tran, fit_every, WC = ho.sga_total()

    first_elements = [lst[0] for lst in pareto]
    sig = first_elements.index(min(first_elements))
    job, machine = np.array([pareto_job[sig]]), np.array([pareto_machine[sig]])
    machine_time, trantime, wc = np.array([pareto_time[sig]]), np.array([pareto_tran[sig]]), np.array([WC[sig]])
    to.caculate(job, machine, machine_time, trantime, wc, record_fatigue_history=True)

    return pareto, oh, to, pareto_job, pareto_machine, pareto_time, pareto_tran, fit_every, WC


def ssgwomain():
    oj = data_deal()
    item_ = oj.item
    job_num = item_["int2"]
    machine_num = item_["M"]
    Tmachine, Tmachinetime, tdx, work, tom, int1, int2, M, M_dicr, tran_time, worker, work_num, worker_fatigue, worker_efficiency_factors, worker_recovery = oj.cacu()
    parm_data = [Tmachine, Tmachinetime, tdx, work, M_dicr, tran_time, int1, worker, work_num, worker_fatigue,
                 worker_efficiency_factors, worker_recovery]
    to = FJSP(job_num, machine_num, parm_data, 100, work)
    _, _, _, _, _, _, _ = to.creat_job()
    oh = mul_op()
    ho = ssgwo(1000, 100, to, oh, work, job_num, tran_time, M_dicr, parm_data[7], parm_data[8])
    pareto, pareto_job, pareto_machine, pareto_time, pareto_tran, fit_every, WC = ho.gwo_total()

    first_elements = [lst[0] for lst in pareto]
    sig = first_elements.index(min(first_elements))
    job, machine = np.array([pareto_job[sig]]), np.array([pareto_machine[sig]])
    machine_time, trantime, wc = np.array([pareto_time[sig]]), np.array([pareto_tran[sig]]), np.array([WC[sig]])
    to.caculate(job, machine, machine_time, trantime, wc, record_fatigue_history=True)

    return pareto, oh, to, pareto_job, pareto_machine, pareto_time, pareto_tran, fit_every, WC


def nsgamain():
    oj = data_deal()
    item_ = oj.item
    job_num = item_["int2"]
    machine_num = item_["M"]
    Tmachine, Tmachinetime, tdx, work, tom, int1, int2, M, M_dicr, tran_time, worker, work_num, worker_fatigue, worker_efficiency_factors, worker_recovery = oj.cacu()
    parm_data = [Tmachine, Tmachinetime, tdx, work, M_dicr, tran_time, int1, worker, work_num, worker_fatigue,
                 worker_efficiency_factors, worker_recovery]
    to = FJSP(job_num, machine_num, parm_data, 100, work)
    _, _, _, _, _, _, _ = to.creat_job()
    oh = mul_op()
    ho = NSGAII(1000, 100, to, oh, work, job_num, tran_time, M_dicr, parm_data[7], parm_data[8])
    pareto, pareto_job, pareto_machine, pareto_time, pareto_tran, fit_every, WC = ho.nsga2_total()

    first_elements = [lst[0] for lst in pareto]
    sig = first_elements.index(min(first_elements))
    job, machine = np.array([pareto_job[sig]]), np.array([pareto_machine[sig]])
    machine_time, trantime, wc = np.array([pareto_time[sig]]), np.array([pareto_tran[sig]]), np.array([WC[sig]])
    to.caculate(job, machine, machine_time, trantime, wc, record_fatigue_history=True)

    return pareto, oh, to, pareto_job, pareto_machine, pareto_time, pareto_tran, fit_every, WC


def memeticmain():
    oj = data_deal()
    item_ = oj.item
    job_num = item_["int2"]
    machine_num = item_["M"]
    Tmachine, Tmachinetime, tdx, work, tom, int1, int2, M, M_dicr, tran_time, worker, work_num, worker_fatigue, worker_efficiency_factors, worker_recovery = oj.cacu()
    parm_data = [Tmachine, Tmachinetime, tdx, work, M_dicr, tran_time, int1, worker, work_num, worker_fatigue,
                 worker_efficiency_factors, worker_recovery]
    to = FJSP(job_num, machine_num, parm_data, 100, work)
    oh = mul_op()
    ho = Memetic(1000, 100, to, oh, work, job_num, tran_time, M_dicr, parm_data[7], parm_data[8])
    pareto, pareto_job, pareto_machine, pareto_time, pareto_tran, fit_every, WC = ho.memetic_total()

    first_elements = [lst[0] for lst in pareto]
    sig = first_elements.index(min(first_elements))
    job, machine = np.array([pareto_job[sig]]), np.array([pareto_machine[sig]])
    machine_time, trantime, wc = np.array([pareto_time[sig]]), np.array([pareto_tran[sig]]), np.array([WC[sig]])
    to.caculate(job, machine, machine_time, trantime, wc, record_fatigue_history=True)

    return pareto, oh, to, pareto_job, pareto_machine, pareto_time, pareto_tran, fit_every, WC


def calculate_igd(pf_found, pf_true):
    if not pf_found or not pf_true:
        return float('inf')
    pf_found_arr = np.array(pf_found)
    pf_true_arr = np.array(pf_true)
    distances = [np.min(np.sqrt(np.sum((pf_found_arr - p_true) ** 2, axis=1))) for p_true in pf_true_arr]
    return np.mean(distances)


def calculate_hv(pf_found, ref_point):
    if not pf_found:
        return 0.0
    hv_indicator = HV(ref_point=ref_point)
    front_array = np.array(pf_found)
    if not np.all(np.isfinite(front_array)):
        return 0.0
    return hv_indicator.do(front_array)


# 追踪最优解用于画甘特图
def update_best_solution(algo_name, pareto_solutions, pareto_job, pareto_machine, pareto_wc, pareto_time, pareto_tran,
                         run_idx, best_solution_tracker):
    if not pareto_solutions: return
    cmax_values = [s[0] for s in pareto_solutions]
    min_cmax_in_run = min(cmax_values)

    if min_cmax_in_run < best_solution_tracker[algo_name]['best_cmax']:
        best_solution_tracker[algo_name]['best_cmax'] = min_cmax_in_run
        best_index = cmax_values.index(min_cmax_in_run)
        best_solution_tracker[algo_name]['solution'] = {
            'job': pareto_job[best_index], 'machine': pareto_machine[best_index],
            'time': pareto_time[best_index], 'tran': pareto_tran[best_index], 'wc': pareto_wc[best_index]
        }


if __name__ == '__main__':
    # ==========================================================
    # === 1. 初始化设置与运行环境 ===
    # ==========================================================
    num_runs = 10
    algorithms = ["SS-GWO", "ENSGA-II", "MANL", "ISGA"]

    # 存储每次运行的Pareto解集和收敛曲线
    results_pf_per_run = {algo: [] for algo in algorithms}
    fit_histories = {algo: [] for algo in algorithms}

    best_solution_tracker = {
        algo: {'best_cmax': float('inf'), 'solution': None} for algo in algorithms
    }

    # ==========================================================
    # === 2. 运行所有算法 (独立运行 10 次) ===
    # ==========================================================
    print(f"--- 启动多算法独立 {num_runs} 次运行测试 ---")
    for i in range(num_runs):
        print(f"\n" + "=" * 20 + f" Run {i + 1}/{num_runs} " + "=" * 20)

        # SS-GWO
        print("Running SS-GWO...")
        pareto_ssgwo, _, _, pareto_job_s, pareto_machine_s, pareto_time_s, pareto_tran_s, fit_ssgwo, pareto_wc_s = ssgwomain()
        results_pf_per_run["SS-GWO"].append(pareto_ssgwo)
        fit_histories["SS-GWO"].append(fit_ssgwo)
        update_best_solution("SS-GWO", pareto_ssgwo, pareto_job_s, pareto_machine_s, pareto_wc_s, pareto_time_s,
                             pareto_tran_s, i, best_solution_tracker)

        # ENSGA-II
        print("Running ENSGA-II...")
        pareto_nsga, _, _, pareto_job_n, pareto_machine_n, pareto_time_n, pareto_tran_n, fit_nsga, pareto_wc_n = nsgamain()
        results_pf_per_run["ENSGA-II"].append(pareto_nsga)
        fit_histories["ENSGA-II"].append(fit_nsga)
        update_best_solution("ENSGA-II", pareto_nsga, pareto_job_n, pareto_machine_n, pareto_wc_n, pareto_time_n,
                             pareto_tran_n, i, best_solution_tracker)

        # MANL
        print("Running Memetic (MANL)...")
        pareto_memetic, _, _, pareto_job_mm, pareto_machine_mm, pareto_time_mm, pareto_tran_mm, fit_memetic, pareto_wc_mm = memeticmain()
        results_pf_per_run["MANL"].append(pareto_memetic)
        fit_histories["MANL"].append(fit_memetic)
        update_best_solution("MANL", pareto_memetic, pareto_job_mm, pareto_machine_mm, pareto_wc_mm, pareto_time_mm,
                             pareto_tran_mm, i, best_solution_tracker)

        # ISGA
        print("Running ISGA...")
        pareto_isga, _, _, pareto_job_sl, pareto_machine_sl, pareto_time_sl, pareto_tran_sl, fit_sgalevy, pareto_wc_sl = sga_levymain()
        results_pf_per_run["ISGA"].append(pareto_isga)
        fit_histories["ISGA"].append(fit_sgalevy)
        update_best_solution("ISGA", pareto_isga, pareto_job_sl, pareto_machine_sl, pareto_wc_sl, pareto_time_sl,
                             pareto_tran_sl, i, best_solution_tracker)

    # ==========================================================
    # === 3. 提取全局 PF_true，逐次计算详细指标 ===
    # ==========================================================
    print("\n" + "=" * 50)
    print("--- 正在提取全局真实前沿 (PF_true) 并计算单次指标 ---")

    # 汇总所有解，筛选全局最优
    combined_pf_all = []
    for algo_runs in results_pf_per_run.values():
        for pf in algo_runs:
            combined_pf_all.extend(pf)

    if not combined_pf_all:
        print("所有运行均未找到有效解，程序退出。")
        exit()

    front, _, _ = mul_op().dis(combined_pf_all)
    PF_true = np.array(combined_pf_all)[front[0]].tolist()

    # 确定归一化边界
    all_solutions_arr = np.array(combined_pf_all)
    min_values = np.min(all_solutions_arr, axis=0)
    max_values = np.max(all_solutions_arr, axis=0)
    max_values = np.where(max_values == min_values, max_values + 1e-6, max_values)
    norm_ref_point = np.array([1.1, 1.1, 1.1])

    detailed_metrics_records = []

    for run_idx in range(num_runs):
        for algo_name in algorithms:
            pf_found = results_pf_per_run[algo_name][run_idx]

            if not pf_found:
                igd_val, hv_val = float('inf'), 0.0
                c_min, e_min, f_min = float('inf'), float('inf'), float('inf')
            else:
                norm_pf_found = (np.array(pf_found) - min_values) / (max_values - min_values)
                norm_pf_true = (np.array(PF_true) - min_values) / (max_values - min_values)

                igd_val = calculate_igd(norm_pf_found.tolist(), norm_pf_true.tolist())
                hv_val = calculate_hv(norm_pf_found.tolist(), norm_ref_point)

                pf_found_arr = np.array(pf_found)
                c_min = np.min(pf_found_arr[:, 0])
                e_min = np.min(pf_found_arr[:, 1])
                f_min = np.min(pf_found_arr[:, 2])

            detailed_metrics_records.append({
                'Run': run_idx + 1,
                'Algorithm': algo_name,
                'IGD': round(igd_val, 6),
                'HV': round(hv_val, 6),
                'Best_Cmax': round(c_min, 2),
                'Best_Energy': round(e_min, 2),
                'Best_Fatigue': round(f_min, 4)
            })

    df_detailed = pd.DataFrame(detailed_metrics_records)

    # ==========================================================
    # === 4. 统计与计算 p-value (Wilcoxon 秩和检验) ===
    # ==========================================================
    print("\n" + "=" * 50)
    print("--- 正在计算统计特征与 P-value 显著性检验 ---")

    metrics_to_test = ['IGD', 'HV', 'Best_Cmax', 'Best_Energy', 'Best_Fatigue']
    base_algo = "ISGA"
    compare_algos = ["SS-GWO", "ENSGA-II", "MANL"]

    stat_records = []
    for metric in metrics_to_test:
        # 获取基准算法的10次数据
        base_data = df_detailed[(df_detailed['Algorithm'] == base_algo) & (df_detailed[metric] != float('inf'))][
            metric].values

        if len(base_data) == 0:
            continue

        b_mean, b_std = np.mean(base_data), np.std(base_data)

        stat_records.append({
            'Metric': metric,
            'Algorithm': base_algo,
            'Mean': round(b_mean, 4),
            'Std': round(b_std, 4),
            'p-value': '-'
        })

        for algo in compare_algos:
            comp_data = df_detailed[(df_detailed['Algorithm'] == algo) & (df_detailed[metric] != float('inf'))][
                metric].values

            if len(comp_data) == 0:
                continue

            c_mean, c_std = np.mean(comp_data), np.std(comp_data)

            # 计算 Wilcoxon 秩和检验 p-value
            if len(base_data) > 1 and len(comp_data) > 1:
                # 注意：如果两组数据完全相同，ranksums会报警告，通常p-value为1.0
                try:
                    _, p_val = ranksums(base_data, comp_data)
                except Exception:
                    p_val = float('nan')
            else:
                p_val = float('nan')

            sig_mark = "(*)" if p_val < 0.05 else ""

            stat_records.append({
                'Metric': metric,
                'Algorithm': algo,
                'Mean': round(c_mean, 4),
                'Std': round(c_std, 4),
                'p-value': f"{p_val:.4e} {sig_mark}" if not np.isnan(p_val) else "NaN"
            })

    df_stats = pd.DataFrame(stat_records)
    print("\n统计检验结果概览:")
    print(df_stats)

    # ==========================================================
    # === 5. 导出所有 CSV 和 JSON 数据文件 ===
    # ==========================================================
    print("\n" + "=" * 50)
    print("--- 正在导出数据文件 ---")

    try:
        # 3. 保存收敛曲线 JSON 原始数据
        clean_history = {}
        for algo, runs in fit_histories.items():
            clean_runs = []
            for run in runs:
                clean_run = [[float(v) for v in obj_list] for obj_list in run]
                clean_runs.append(clean_run)
            clean_history[algo] = clean_runs

        with open("Convergence_History_Raw.json", 'w', encoding='utf-8') as f:
            json.dump(clean_history, f, ensure_ascii=False, indent=4)
        print("✅ 完整迭代历史记录 JSON 保存至: Convergence_History_Raw.json")

        # 4. 导出平滑对齐的迭代均值 CSV (供 Origin/Excel 画图使用)
        export_data_raw = {}
        global_max_len = 0

        for algo_name, histories in fit_histories.items():
            if not histories: continue
            for obj_idx, obj_name in enumerate(["Cmax", "Energy", "Fatigue"]):
                curves = []
                for run in histories:
                    if len(run) > obj_idx and len(run[obj_idx]) > 0:
                        curves.append(run[obj_idx])

                if not curves: continue

                local_max_len = max(len(c) for c in curves)
                aligned_curves = []
                for c in curves:
                    c_list = list(c)
                    if len(c_list) < local_max_len:
                        c_list.extend([c_list[-1]] * (local_max_len - len(c_list)))
                    aligned_curves.append(c_list)

                avg_curve = np.mean(aligned_curves, axis=0)
                export_data_raw[f"{algo_name}_{obj_name}_Avg"] = avg_curve

                if len(avg_curve) > global_max_len:
                    global_max_len = len(avg_curve)

        export_data = {'Generation': range(1, global_max_len + 1)}
        for key, curve in export_data_raw.items():
            c_list = list(curve)
            if len(c_list) < global_max_len:
                c_list.extend([c_list[-1]] * (global_max_len - len(c_list)))
            export_data[key] = c_list

        df_export = pd.DataFrame(export_data)
        # df_export.to_csv("Convergence_Data_Avg.csv", index=False, encoding='utf-8-sig')
        # print("✅ 平均迭代曲线绘图数据 CSV 保存至: Convergence_Data_Avg.csv")

    except Exception as e:
        print(f"❌ 数据保存出错: {e}")

    # ==========================================================
    # === 6. 生成曲线图 ===
    # ==========================================================
    print("\n" + "=" * 50)
    print("--- 正在绘制比较图 ---")

    # [注：原有的强行交换排名(SWAP)逻辑已移除。由于这是严谨的科学统计版本，图表必须与数据真实匹配]
    pa = Plotting()
    pa.plot_convergence_comparison_average(
        (fit_histories['SS-GWO'], 'SS-GWO'),
        (fit_histories['ENSGA-II'], 'ENSGA-II'),
        (fit_histories['MANL'], 'MANL'),
        (fit_histories['ISGA'], 'ISGA'),
        save_path_prefix="4_algos_comparison"
    )
    print("✅ 执行完毕！所有图表和数据均已生成。")