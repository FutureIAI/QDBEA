# -*- coding: utf-8 -*-
# @Time    : 2022/4/13 20:23
# @Author  : ht
# @File    : small_work.py
# @Software: PyCharmjob
import json
import numpy as np
from pathlib import Path
import re
class data_deal:
    def __init__(self):
        self.name_list = ["job", "daoda_time", "jiezhi_time", "M", "job_num", "job_dicr", "int1", "int2",  "M_dicr", "tran_time","worker","work_num","worker_fatigue","worker_machine_efficiency","worker_recovery"]
        # "job":每个工件的工序在不同机器上处理的时间
        # "daoda_time"：到达时间
        # "jiezhi_time"：截止日期
        # "M"：机器数量
        # "job_num"：每个工件工序数量
        # "job_dicr"：每个工件对应的工序数字典
        # "int1"：总工序数
        # "int2"：总工件数
        # "M_dicr"：机器编号与所属车间,机器加工功率,空载功率的字典
        # "tran_time"：车间之间的运输时间
        # "worker":可参与机器，每个机器对应的可加工工人编号
        # "work_num"：工人数量
        self.item = {}
        self.get_item()



    def precess_(self, data):
            if "[" in data and "," not in data:
                data = data.strip().replace("[ ", "[").replace(" ]", "]").replace("  ", ",").replace(" ", ",").replace("][", "], [")
            elif "{" in data:
                data = data.strip().replace("：", ":")
            return eval(data)


    def get_item(self):
        with open("data/Z_DATA/D00-D10-20x9x3.txt") as fp:
            datas = fp.readlines()
            for i in range(len(self.name_list)-3):
                data = self.precess_(datas[i])
                self.item[self.name_list[i]] = data
            worker_fatigue_factors = list(map(float, re.findall(r'\S+', datas[-2])))
            worker_efficiency_factors = list(map(float, re.findall(r'\S+', datas[-3])))
            worker_recovery = list(map(float, re.findall(r'\S+', datas[-1])))
            self.item[self.name_list[-3]] = worker_efficiency_factors
            self.item[self.name_list[-2]] = worker_fatigue_factors
            self.item[self.name_list[-1]] = worker_recovery
        return self.item

    def widthxx(self):
        widthx = []
        int2 = self.item["int2"]
        data = self.item['job']
        siga=0
        for i in range(int2):
            for j in range(len(data[i])):
                for k in range(10):
                    if data[i][j][k] > 0:
                        siga+=1
            widthx.append(siga)
            siga=0
        width = max(widthx)
        return width

    def tcaculate(self):
        int2=self.item["int2"]
        jobnum=self.item["job_num"]

        # width = self.widthxx()
        # Tmachine, Tmachinetime = np.zeros((int2, width)), np.zeros((int2, width))
        Tmachine = [ [ [] for j in range(jobnum[i])] for i in range(int2)]
        Tmachinetime = [ [ [] for j in range(jobnum[i])] for i in range(int2)]
        tdx,sdx,tom,toe=[],[],[],[]
        M=self.item['M']
        data=self.item['job']
        q=0
        a=0
        for i in range(len(data)):
            for j in range(len(data[i])):
                for k in range(M):
                    if data[i][j][k] > 0:
                        Tmachine[i][j].append(k+1)
                        Tmachinetime[i][j].append(data[i][j][k])
                        q += 1
                        a += 1
                sdx.append(a)
                a=0
                toe.append(q)
            tdx.append(sdx)
            sdx=[]
            q = 0
            tom.append(toe)
            toe = []
        return Tmachine,Tmachinetime,tdx,tom


    def cacu(self):
        int2 = self.item["int2"]
        int1 = self.item["int1"]
        M=self.item["M"]
        M_dicr = self.item["M_dicr"]
        tran_time = self.item["tran_time"]
        worker = self.item["worker"]
        work_num = self.item["work_num"]
        worker_fatigue = self.item["worker_fatigue"]
        Tmachine, Tmachinetime, tdx ,tom= self.tcaculate()
        worker_machine_efficiency = self.item["worker_machine_efficiency"]
        worker_recovery = self.item["worker_recovery"]
        to, work = 0, []
        for i in range(int2):
            to += len(tdx[i])
            for j in range(1, len(tdx[i]) + 1, 1):
                work.append(i)
        return Tmachine, Tmachinetime, tdx, work, tom, int1,int2, M, M_dicr, tran_time,worker,work_num,worker_fatigue,worker_machine_efficiency,worker_recovery

oj = data_deal()

item_ = oj.item
job_num = item_["int2"]
machine_num = item_["M"]
