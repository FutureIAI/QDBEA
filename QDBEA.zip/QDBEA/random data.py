import numpy as np
import sys
# --- 参数定义 ---
num_workers = 15# 需要生成的工人数量
np.set_printoptions(precision=5, suppress=True, linewidth=sys.maxsize)

# --- 生成疲劳累积率 (λ) ---
# 在 0.011 和 0.035 之间随机生成 40 个浮点数
fatigue_accumulation_rates = np.random.uniform(low=0.011, high=0.035, size=num_workers)

# --- 生成疲劳恢复率 (μ) ---
# 在 0.030 和 0.045 之间随机生成 40 个浮点数
fatigue_recovery_rates = np.random.uniform(low=0.030, high=0.045, size=num_workers)

# --- 生成工人效率 (μ) ---
# 在 0.030 和 0.045 之间随机生成 40 个浮点数
worker_efficieny_rates = np.random.uniform(low=0.80, high=1, size=num_workers)

# --- 打印结果 ---
print("--- 随机生成的工人的疲劳累积率 (λ) ---")
print(fatigue_accumulation_rates)

print("\n--- 随机生成工人的效率 (μ) ---")
print(worker_efficieny_rates)

print("\n--- 随机生成工人的疲劳恢复率 (μ) ---")
print(fatigue_recovery_rates)

