import numpy as np
import random
import math
import copy
from itertools import chain
from matplotlib.pylab import mpl
mpl.rcParams['font.sans-serif'] = ['SimHei']  # 添加这条可以让图形显示中文

class zgwo():
    def __init__(self,generation,popsize,to,oh,work,job_num,tran_time,M_dicr,Work_arr,work_num):
        self.generation = generation  # 迭代次数
        self.popsize = popsize  # 种群规模
        self.to = to
        self.oh = oh
        self.work = work
        self.job_num = job_num                  # 种群规模
        self.tran_time=tran_time
        self.M_dicr=M_dicr
        # print(self.job_num)
        self.Work_arr = Work_arr
        self.work_num = work_num
        # Lévy 飞行
        self.initial_levy_alpha = 0.5 # Lévy 飞行的 alpha 参数 (步长缩放因子)
        self.late_stage_levy_alpha = 1.0  # *** 后期增大的 alpha 值 ***
        self.levy_beta = 1.5  # Lévy 飞行的 beta 参数
        self.late_stage_start_generation = 100  # *** 从第几代开始增大 alpha ***
        self.levy_alpha_schedule = {0: 0.6, 100: 0.7, 300: 0.8, 500: 0.9}  # 代数: alpha 值
        # *** 新增：锦标赛选择参数 ***
        # self.tournament_size = 5 # 二元锦标赛
    def to_MT(self,W1,M1,T1,WC): #把加工机器编码和加工时间编码转化为对应列表，目的是记录工件的加工时间和加工机器
        Ma_W1, Tm_W1, WCross, WC_W1=[],[],[],[]
        for i in range(self.job_num):#添加工件个数的空列表
            Ma_W1.append([]),Tm_W1.append([]),WCross.append([]),WC_W1.append([])
        for i in range(W1.shape[1]):
            signal1=int(W1[0,i])
            Ma_W1[signal1].append(M1[0,i]),Tm_W1[signal1].append(T1[0,i]),WC_W1[signal1].append(WC[0,i]); #记录每个工件【】的加工机器
            index=np.random.randint(0,2,1)[0]
            WCross[signal1].append(index)       #随机生成一个为0或者1的列表，用于后续的机器的均匀交叉
        return Ma_W1, Tm_W1, WCross, WC_W1         #工件的加工机器和加工时间 分为20个数列
    def back_MT(self,W1,Ma_W1,Tm_W1,WC1):  #列表返回机器及加工时间编码
        memory1=np.zeros((1,self.job_num),dtype=int)
        # print(W1)
        # print(Ma_W1)
        # print(Tr_W1)
        # print(len((Tr_W1)))
        m1,t1,wc=np.zeros((1,W1.shape[1])),np.zeros((1,W1.shape[1])),np.zeros((1,W1.shape[1]))
        for i in range(W1.shape[1]):
            signal1=int(W1[0,i])
            # print(signal1)
            # print(Tr_W1[signal1][memory1[0,signal1]])
            m1[0,i]=Ma_W1[signal1][memory1[0,signal1]] #读取对应工序的加工机器             一个工件的多个工序加工机器    得出机器和加工时间的序列
            t1[0,i]=Tm_W1[signal1][memory1[0,signal1]]
            wc[0][i]=WC1[signal1][memory1[0,signal1]]
            # r1[0,i]=Tr_W1[signal1][memory1[0,signal1]]
            memory1[0,signal1]+=1
            # print(memory1)
        return m1,t1,wc
    def mac_cross(self,Ma_W1,Tm_W1,Ma_W2,Tm_W2,WCross,WC_W1,WC_W2):  #机器均匀交叉
        MC1,MC2,TC1,TC2=[],[],[],[]
        TR1,TR2,trtime=[],[],[]
        WC1,WC2 = [],[]
        # print(WCross)
        # print(Ma_W1)
        # print(Ma_W2)
        for i in range(self.job_num):
            MC1.append([]),MC2.append([]),TC1.append([]),TC2.append([]),WC1.append([]),WC2.append([])
            c =len((WCross[i]))
            for j in range(c):
                if(WCross[i][j]==0):  #为0时继承另一个父代的加工机器选择
                    MC1[i].append(Ma_W1[i][j]), MC2[i].append(Ma_W2[i][j]), TC1[i].append(Tm_W1[i][j]), TC2[i].append(Tm_W2[i][j])#,WC1[i].append(float(self.select_different_number(self.Work_arr[int(Ma_W1[i][j])], WC_W1[i][j]))),WC2[i].append(float(self.select_different_number(self.Work_arr[int(Ma_W1[i][j])], WC_W2[i][j])))#, WC1[i].append(WC_W1[i][j]), WC2[i].append(WC_W2[i][j])
                else:                #为1时继承父代的机器选择
                    MC2[i].append(Ma_W1[i][j]), MC1[i].append(Ma_W2[i][j]), TC2[i].append(Tm_W1[i][j]), TC1[i].append(Tm_W2[i][j])#,WC2[i].append(float(self.select_different_number(self.Work_arr[int(Ma_W1[i][j])], WC_W1[i][j]))),WC1[i].append(float(self.select_different_number(self.Work_arr[int(Ma_W1[i][j])], WC_W2[i][j])))#, WC2[i].append(WC_W1[i][j]), WC1[i].append(WC_W2[i][j])
            for z in range(c):
                prob = random.random()
                if prob < 0.99:
                    if (WCross[i][z] == 0):
                        WC1[i].append(WC_W1[i][z]), WC2[i].append(WC_W2[i][z])
                    else:
                        WC2[i].append(WC_W1[i][z]), WC1[i].append(WC_W2[i][z])
                else:
                    if (WCross[i][z] == 0):
                        WC1[i].append(float(self.select_different_number(self.Work_arr[int(Ma_W1[i][z])], WC_W1[i][z])))
                        WC2[i].append(float(self.select_different_number(self.Work_arr[int(Ma_W1[i][z])], WC_W2[i][z])))
                    else:
                        WC2[i].append(float(self.select_different_number(self.Work_arr[int(Ma_W1[i][z])], WC_W1[i][z])))
                        WC1[i].append(float(self.select_different_number(self.Work_arr[int(Ma_W1[i][z])], WC_W2[i][z])))

        return MC1,TC1,MC2,TC2,WC1,WC2

    def select_different_number(self,list, number):
        while True:
            if len(list) == 1:
                return number
            else:
                random_number = np.random.choice(list)
                if random_number != number:
                    return random_number

    def gettran(self, job, machine):
        trantime = np.ones((1, job.shape[1]))
        index = []
        k = 0
        for i in range(self.job_num):

            for j in range(len(job[0])):
                if job[0][j] == i:
                    k += 1
                    index.append(j)
                    if k == 1:
                        trantime[0][j] = 0
                    else:
                        a = machine[0][j]  # 当前工序机器序号
                        b = machine[0][index[-2]]  # 该工件前一个工序机器编号
                        x = list(self.M_dicr[int(a)])[0] - 1
                        y = list(self.M_dicr[int(b)])[0] - 1
                        # print(x,y)

                        trantime[0][j] = self.tran_time[y][x]
            # 获取两个工序机器对应的车间

            index = []
            k = 0
        return trantime

    def POX_improve(self, Father_1, Father_2):
        """先选折一部分种群进行pox交叉操作，看看结果
        Father_1,Father_2父代的DNA序列
        """
        Father_1 = Father_1[0:len(self.work)].copy()
        #print(Father_1)
        Father_2 = Father_2[0:len(self.work)].copy()
        # Father_1 = Father_1.tolist()
        # print(Father_1)
        # Father_2 = Father_2.tolist()
        children_1 = np.zeros(len(self.work), dtype=int)
        children_2 = np.zeros(len(self.work), dtype=int)
        # 建立工件集合
        Job_set = [i_ for i_ in range(self.job_num)]  # 有10个工件
        J_set_1 = np.random.choice(Job_set, 2, replace=False)
        J_set_2 = np.random.choice(Job_set, 2, replace=False)
        index_J2_of_F1_set = []
        index_J1_of_F2_set = []
        for i in range(len(J_set_1)):
            index_J1_of_F1 = np.where(Father_1[0] == J_set_1[i])[0]
            #print(index_J1_of_F1)
            index_J1_of_F2 = np.where(Father_2[0] == J_set_1[i])[0]
            index_J2_of_F1 = np.where(Father_1[0] == J_set_2[i])[0]
            index_J2_of_F2 = np.where(Father_2[0] == J_set_2[i])[0]
            index_J2_of_F1_set.append(index_J2_of_F1)
            index_J1_of_F2_set.append(index_J1_of_F2)
            for i_1 in range(np.size(index_J1_of_F1)):
                a_1 = index_J1_of_F1[i_1]
                #print(a_1)
                # print(Father_1[a_1])
                children_1[a_1] = Father_1[0][a_1]
            for i_1 in range(np.size(index_J2_of_F2)):
                a_2 = index_J2_of_F2[i_1]
                # print(Father_1[a_1])
                children_2[a_2] = Father_2[0][a_2]
                # 第二部将F1的转接到C2
        # 将二维数组转化为一维数组
        index_delet_1 = list(chain.from_iterable(index_J2_of_F1_set))
        index_delet_2 = list(chain.from_iterable(index_J1_of_F2_set))
        Father_1_deleted = np.delete(Father_1[0], index_delet_1)
        Father_2_deleted = np.delete(Father_2[0], index_delet_2)
        index_0_insert_1 = np.where(children_2 == 0)[0]
        index_0_insert_2 = np.where(children_1 == 0)[0]
        for j in range(np.size(Father_1_deleted)):
            a_3 = index_0_insert_1[j]
            children_2[a_3] = Father_1_deleted[j]
        for j in range(np.size(Father_2_deleted)):
            a_4 = index_0_insert_2[j]
            children_1[a_4] = Father_2_deleted[j]
        return children_1, children_2

    def complete(self,list1,list2):
        temp = 0
        for i in range(len(list2)):
            if(list1[i] != list2[i]):
                temp = temp+1
        return temp

    def parse_list_t_for_comparison(self,list_t_data):
        op_info = {}
        if list_t_data is None: return op_info
        for machine_idx, ops_on_machine in enumerate(list_t_data):
            if ops_on_machine:
                for op_detail in ops_on_machine:
                    if len(op_detail) >= 3:
                        job_id, op_seq, start_time = op_detail[0], op_detail[1], op_detail[2]
                        key = (job_id, op_seq)
                        op_info[key] = {'start': start_time, 'machine': machine_idx}
                    # else: 警告信息 (可选)
        return op_info

    def sta_record(self, list_t, list_t_recalc):
        # 工序偏移记录
        op_info_original = self.parse_list_t_for_comparison(list_t)
        op_info_rescheduled = self.parse_list_t_for_comparison(list_t_recalc)
        delayed_ops_count = 0  # 开始时间发生变化的工序计数
        machine_reassigned_count = 0  # 机器分配发生变化的工序计数
        num_compared_ops = 0  # 成功比较的工序总数
        time_tolerance = 1e-6  # 用于比较浮点数开始时间的容差
        all_op_keys = set(op_info_original.keys()) | set(op_info_rescheduled.keys())
        for key in all_op_keys:
            if key in op_info_original and key in op_info_rescheduled:
                orig_info = op_info_original[key]
                resched_info = op_info_rescheduled[key]
                num_compared_ops += 1
                # 检查开始时间是否变化 (考虑容差)
                if abs(resched_info['start'] - orig_info['start']) > time_tolerance:
                    delayed_ops_count += 1
                # 检查机器分配是否变化
                if resched_info['machine'] != orig_info['machine']:
                    machine_reassigned_count += 1
        return delayed_ops_count,machine_reassigned_count

    def levy_flight_step(self,beta=1.5, alpha=0.1, size=None):
        try:
            num = math.gamma(1 + beta) * math.sin(math.pi * beta / 2)
            den = math.gamma((1 + beta) / 2) * beta * (2 ** ((beta - 1) / 2))
            sigma_u = (num / den) ** (1 / beta)
        except ValueError:
            sigma_u = 0.6966  # 近似值 for beta=1.5
        sigma_v = 1
        if size is None:
            u = random.normalvariate(0, sigma_u);
            v = random.normalvariate(0, sigma_v)
        else:
            u = np.random.normal(0, sigma_u, size);
            v = np.random.normal(0, sigma_v, size)
        # 添加一个小的 epsilon 防止 v 为 0 导致除零错误
        step = u / ((np.abs(v) + 1e-10) ** (1 / beta))
        return alpha * step

    def _tournament_selection(self, combined_population_data: list, num_to_select: int):
        all_fitness_list = [ind['fitness'] for ind in combined_population_data]
        Z_answer = self.z_score_normalize_objectives(all_fitness_list)
        fronts, crowd_values_per_front, _ = self.oh.dis(Z_answer)

        # 构建每个个体在 combined_population_data 中的索引到其等级和拥挤度的映射
        individual_ranks = {}
        individual_crowding = {}
        for rank_idx, front_level in enumerate(fronts):
            for i, original_pop_idx in enumerate(front_level):
                individual_ranks[original_pop_idx] = rank_idx
                if rank_idx < len(crowd_values_per_front) and i < len(crowd_values_per_front[rank_idx]):
                    individual_crowding[original_pop_idx] = crowd_values_per_front[rank_idx][i]
                else:  # 边界情况或单点层
                    individual_crowding[original_pop_idx] = float('inf')

        selected_population = []
        for _ in range(num_to_select):
            # 随机选择 k 个 *原始索引*
            participants_indices = np.random.choice(len(combined_population_data), size=self.tournament_size,
                                                    replace=False)

            winner_original_idx = participants_indices[0]
            for j in range(1, self.tournament_size):
                competitor_original_idx = participants_indices[j]
                # 获取等级
                rank_winner = individual_ranks.get(winner_original_idx, float('inf'))
                rank_competitor = individual_ranks.get(competitor_original_idx, float('inf'))

                if rank_competitor < rank_winner:
                    winner_original_idx = competitor_original_idx
                elif rank_competitor == rank_winner:  # 等级相同，比较拥挤度
                    diversity_winner = individual_crowding.get(winner_original_idx, -float('inf'))
                    diversity_competitor = individual_crowding.get(competitor_original_idx, -float('inf'))
                    if diversity_competitor > diversity_winner:
                        winner_original_idx = competitor_original_idx
                    elif diversity_competitor == diversity_winner and random.random() < 0.5:  # 等级和拥挤度都相同，随机选择
                        winner_original_idx = competitor_original_idx
            selected_population.append(combined_population_data[winner_original_idx])
        return selected_population
    # 新增：Z-Score 目标归一化函数
    def z_score_normalize_objectives(self, objectives_list):
        """
        对目标值列表进行 Z-Score 归一化 (标准化)。
        Args:
            objectives_list: 一个列表，每个元素是一个包含多个目标值的列表 (e.g., [[c1,e1,f1], [c2,e2,f2], ...])
        Returns:
            一个列表，包含归一化后的目标值。
        """
        if not objectives_list:
            return []

        obj_array = np.array(objectives_list, dtype=float)
        normalized_obj_array = np.zeros_like(obj_array)

        for i in range(obj_array.shape[1]):  # 遍历每个目标 (列)
            col = obj_array[:, i]
            mean_val = np.mean(col)
            std_val = np.std(col)

            if std_val == 0:
                # 如果标准差为0 (所有值都相同)，则归一化为0
                # (因为它们在比较中没有区分度，且 (X - mean) / 0 会导致错误)
                normalized_obj_array[:, i] = 0.0
            else:
                normalized_obj_array[:, i] = (col - mean_val) / std_val

        return normalized_obj_array.tolist()

    def update_position_vector(self, original_positions, new_order):
        n = len(new_order)
        # 基础检查
        if len(original_positions) != len(self.work):
            raise ValueError(
                f"长度不匹配! len(original_positions)={len(original_positions)}, "
                f"len(self.work)={len(self.work)}"
            )

        # 1. 构建工序到原始位置值的映射并降序排序
        position_map = {}
        for order, pos in zip(self.work, original_positions):
            if order not in position_map:
                position_map[order] = []
            position_map[order].append(pos)

        for order in position_map:
            position_map[order].sort(reverse=True)  # 工序内部降序排序

        # 2. 计算全局基础值 (线性递减)
        base_values = [n - i for i in range(n)]  # 索引0: n, 索引1: n-1, ... 索引n-1: 1

        # 3. 计算每个工序的偏移量范围 (确保|偏移| < 1)
        epsilon = 0.5  # 最大偏移量幅度 (<1)
        offset_map = {}
        for order, positions in position_map.items():
            k = len(positions)
            # 生成偏移量: 原始值最大的分配最大偏移，依次减小
            offsets = [epsilon * (1 - i / k) for i in range(k)]
            offset_map[order] = offsets

        # 4. 生成新位置向量
        new_positions = []
        order_count = {order: 0 for order in position_map}  # 工序出现计数器

        for i, order in enumerate(new_order):
            if order not in position_map:
                raise ValueError(f"工序编码 {order} 不在原始工序中")

            count = order_count[order]
            # 获取当前工序的偏移量 (若出现次数超原始值，取最小偏移)
            if count < len(offset_map[order]):
                offset = offset_map[order][count]
            else:
                offset = 0  # 或 epsilon * (1 - (len(offset_map[order])-1)/len(offset_map[order])

            new_pos = base_values[i] + offset
            new_positions.append(new_pos)
            order_count[order] += 1

        return new_positions
    # def update_position_vector(self, original_positions, new_order):
    #     """
    #     根据工序加工顺序的变化更新位置向量
    #
    #     参数:
    #     original_positions (list): 原始位置向量
    #     new_order (list): 新的工序编码
    #
    #     返回:
    #     list: 更新后的位置向量
    #     """
    #     original_order = copy.deepcopy(self.work)
    #     # --- 强制长度检查 ---
    #     if len(original_positions) != len(original_order):
    #         raise ValueError(
    #             f"长度不匹配! len(original_positions)={len(original_positions)}, "
    #             f"len(original_order/self.work)={len(original_order)}. "
    #             f"original_positions: {original_positions[:10]}..., "  # 打印一部分
    #             f"original_order: {original_order[:10]}..."
    #         )
    #     if len(original_order) != len(new_order):
    #         # 这个检查可以根据你的逻辑决定是否严格，因为new_order和original_order长度一致是这个函数的隐含假设
    #         # 但如果只是更新位置向量，new_order 的长度应该和 original_order/original_positions 一致
    #         pass  # 暂时不报错，但要注意
    #     # 创建原始位置向量和工序编码的映射
    #     position_map = {}
    #     for pos, order in zip(original_positions, original_order):
    #         if order not in position_map:
    #             position_map[order] = []
    #         position_map[order].append(pos)
    #     # 打印构建好的 position_map 的键，看看 14 是否真的不在里面
    #     # print(f"DEBUG update_position_vector: position_map.keys(): {list(position_map.keys())}")
    #     # print(f"DEBUG update_position_vector: Is 14 in position_map keys? {14 in position_map.keys()}")
    #     # 对每个工序编码的位置向量进行降序排序
    #     for order in position_map:
    #         position_map[order].sort(reverse=True)
    #
    #     # 根据新的工序编码生成新的位置向量
    #     new_positions = []
    #     used_counts = {order: 0 for order in position_map}
    #
    #     for order in new_order:
    #         if order not in position_map:
    #             # print(f"ERROR DEBUG: Failed to find {order} in position_map.")
    #             # print(f"               position_map contains keys: {list(position_map.keys())}")
    #             # print(f"               self.work contains: {self.work}")
    #             raise ValueError(f"新的工序编码 {order} 不在原始工序编码中")
    #
    #         # 获取该工序编码对应的下一个位置值
    #         pos_list = position_map[order]
    #         index = used_counts[order]
    #
    #         if index >= len(pos_list):
    #             # 如果位置值不够用，则生成一个比当前最小值略小的值
    #             min_val = min(pos_list)
    #             new_val = min_val - 0.1 * (index - len(pos_list) + 1)
    #             new_positions.append(new_val)
    #         else:
    #             new_positions.append(pos_list[index])
    #             used_counts[order] += 1
    #
    #     return new_positions
    def _get_hashable_key(self, item):
        """将项目转换为可哈希的键，特别是将 ndarray 转换为元组。"""
        if isinstance(item, np.ndarray):
            return tuple(item.flatten()) # flatten 以处理多维数组，然后转为元组
        elif isinstance(item, list): # 如果列表也可能作为键（不常见，但以防万一）
             # 注意：如果列表内还有不可哈希的元素，需要递归转换
            return tuple(item)
        return item
    def gwo_total(self):
        answer = []
        fit_every = [[], [], []]
        # job_init = np.zeros((self.popsize, len(self.work)))
        job_init_vectors = np.zeros((self.popsize, len(self.work)))  # 存储父代位置向量
        work_tran1, work_job1, work_M1, work_T1=np.zeros((self.popsize,len(self.work))),np.zeros((self.popsize,len(self.work))),np.zeros((self.popsize,len(self.work))),np.zeros((self.popsize,len(self.work)))
        work_tran, work_job, work_M ,work_T=np.zeros((self.popsize,len(self.work))),np.zeros((self.popsize,len(self.work))),np.zeros((self.popsize,len(self.work))),np.zeros((self.popsize,len(self.work)))
        work_tran2, work_job2, work_M2, work_T2 = np.zeros((self.popsize, len(self.work))), np.zeros((self.popsize, len(self.work))), np.zeros((self.popsize, len(self.work))), np.zeros((self.popsize, len(self.work)))
        work_wc ,work_wc1,work_wc2 = np.zeros((self.popsize,len(self.work))),np.zeros((self.popsize,len(self.work))),np.zeros((self.popsize,len(self.work)))
        for gen in range(self.generation):#迭代次数100
            #初始解+机器交叉变异  生成与评估
            if(gen<1):
                work_job, work_M, work_T, work_tran, work_F , job_init, work_wc = self.to.creat_job()
                pop_to_eval_initial = []  # 存储初始生成的个体
                #第一次生成多个可行的工序编码，机器编码，时间编码
                for i in range(self.popsize):#种群规模100
                    C_finish1,_,list_T , list_M, list_S , list_W , tmmw , Wmax, Twork1,global_max_fatigue,E_all1 = self.to.caculate(work_job[i:i+1], work_M[i:i+1], work_T[i:i+1], work_tran[i:i+1],work_wc[i:i+1],record_fatigue_history=False)
                    # self.to.plot_fatigue_history(fatigue_history)
                    c_job = work_job[i:i + 1]
                    c_M = work_M[i:i + 1]
                    c_T = work_T[i:i + 1]
                    c_tran = work_tran[i:i + 1]
                    c_wc = work_wc[i:i + 1]
                    c_init = job_init[i:i+1]
                    # answer.append([C_finish1,E_all1,global_max_fatigue])
                    fitness = [C_finish1, E_all1, global_max_fatigue]
                    pop_to_eval_initial.append({
                        'job': c_job, 'M': c_M, 'T': c_T, 'tran': c_tran, 'wc': c_wc,
                        'job_init': c_init, 'fitness': fitness
                    })
                    # Ma_W1, Tm_W1, WCross, WC_W1 = self.to_MT(c_job, c_M, c_T, c_wc)
                    # self.to.draw2(c_job, c_M, c_T, c_tran, c_wc, WC_W1, list_T, C_finish1, Twork1, E_all1)
                crossed_pop_initial = []
                for i in range(0,self.popsize,2):#机器均匀交叉
                    job, machine, machine_time, wc = work_job[i:i + 1], work_M[i:i + 1], work_T[i:i + 1],work_wc[i:i+1]
                    Ma_W1, Tm_W1, WCross, WC_W1 = self.to_MT(job, machine, machine_time,wc)   #创建存储机器与加工时间的列表以及用于交叉的序列

                    job1, machine1, machine_time1,wc1 = work_job[self.popsize-i-1: self.popsize-i], work_M[self.popsize-i-1: self.popsize-i], work_T[self.popsize-i-1: self.popsize-i],work_wc[self.popsize-i-1: self.popsize-i] #倒数第i个
                    Ma_W2, Tm_W2, WCross, WC_W2 = self.to_MT(job1, machine1, machine_time1,wc1)

                    MC1, TC1, MC2, TC2 ,WC1, WC2= self.mac_cross(Ma_W1, Tm_W1, Ma_W2, Tm_W2, WCross,WC_W1,WC_W2)   # mac_cross 交叉 MS/WS

                    job_new1, job_new2 = self.POX_improve(job, job1)   # POX 交叉 OS
                    job_new1, job_new2 = np.array(job_new1).reshape(1, len(self.work)), np.array(job_new2).reshape(1,len(self.work))
                    machine_new, time_new, wc = self.back_MT(job_new1, MC1, TC1, WC1)
                    tran_new = self.gettran(job_new1,machine_new) #得到转运时间

                    C_finish1, _, list_T, list_M, list_S, list_W, tmmw,Wmax,Twork1,global_max_fatigue,E_all1 = self.to.caculate(job_new1, machine_new, time_new,tran_new,wc,record_fatigue_history=False)
                    # answer2 = [C_finish1, E_all1, global_max_fatigue]
                    fit_c1 = [C_finish1, E_all1, global_max_fatigue]
                    work_job1[i],work_tran1[i],work_M1[i],work_T1[i],work_wc1[i]=job_new1,tran_new,machine_new,time_new,wc
                    # answer.append(answer2)
                    job_list1=self._get_hashable_key(job_new1)
                    job_init_c1 = self.update_position_vector(job_init[i], job_list1)
                    job_init_c1 = np.array(job_init_c1).reshape(1, len(self.work))
                    machine_new1, time_new1, wc1 = self.back_MT(job_new2, MC2, TC2, WC2)
                    tran_new1 = self.gettran(job_new2, machine_new1)
                    C_finish1, _, list_T, list_M, list_S, list_W, tmmw,Wmax,Twork1,global_max_fatigue,E_all1 = self.to.caculate(job_new2, machine_new1, time_new1,tran_new1,wc1,record_fatigue_history=False)
                    work_job1[i+1], work_tran1[i+1], work_M1[i+1], work_T1[i+1],work_wc1[i+1] = job_new2, tran_new1, machine_new1, time_new1,wc1
                    # answer3 = [C_finish1,E_all1,global_max_fatigue]
                    fit_c2 = [C_finish1, E_all1, global_max_fatigue]
                    # answer.append(answer3)
                    job_list2 = self._get_hashable_key(job_new2)
                    job_init_c2 = self.update_position_vector(job_init[i+1], job_list2)
                    job_init_c2 = np.array(job_init_c2).reshape(1, len(self.work))
                    crossed_pop_initial.append(
                        {'job': job_new1, 'M': machine_new, 'T': time_new, 'tran': tran_new,
                         'wc': wc, 'job_init': job_init_c1, 'fitness': fit_c1})
                    crossed_pop_initial.append(
                        {'job': job_new2, 'M': machine_new1, 'T': time_new1, 'tran': tran_new1,
                         'wc': wc1, 'job_init': job_init_c2, 'fitness': fit_c2})
                # 合并初始生成的个体和交叉产生的个体
                combined_initial_pop_data = pop_to_eval_initial + crossed_pop_initial
                # evaluated_pop_data = self._tournament_selection(combined_initial_pop_data, self.popsize)
                all_initial_fitness = [ind['fitness'] for ind in combined_initial_pop_data]
                Z_answer = self.z_score_normalize_objectives(all_initial_fitness)
                front, crowd, initial_crowder = self.oh.dis(Z_answer)
                next_pop_indices = initial_crowder[:self.popsize]
                evaluated_pop_data = [combined_initial_pop_data[idx] for idx in next_pop_indices]
                # 更新用于下一代 GWO 的 job_init_vectors (以及其他 work_* 数组)
                for k in range(self.popsize):
                    job_init_vectors[k] = evaluated_pop_data[k]['job_init']
                    work_job[k:k+1] = evaluated_pop_data[k]['job']
                    work_M[k:k+1] = evaluated_pop_data[k]['M']
                    work_T[k:k+1] = evaluated_pop_data[k]['T']
                    work_tran[k:k+1] = evaluated_pop_data[k]['tran']
                    work_wc[k:k+1] = evaluated_pop_data[k]['wc']
                # 记录第一代的统计信息
                current_evals_for_stats = [ind['fitness'] for ind in evaluated_pop_data]
                Z_answer = self.z_score_normalize_objectives(current_evals_for_stats)
                front_init, _, _ = self.oh.dis(Z_answer)
                if front_init and front_init[0]:
                    pareto_fitness_init = [current_evals_for_stats[x] for x in front_init[0]]
                    if pareto_fitness_init:
                        fit_every[0].append(min(f[0] for f in pareto_fitness_init))
                        fit_every[1].append(min(f[1] for f in pareto_fitness_init))
                        fit_every[2].append(min(f[2] for f in pareto_fitness_init))
            parent_fitnesses = [ind['fitness'] for ind in evaluated_pop_data]
            Z_answer = self.z_score_normalize_objectives(parent_fitnesses)
            _, _, parent_crowder = self.oh.dis(Z_answer)
            alpha_idx = parent_crowder[0]
            beta_idx = parent_crowder[min(1, len(parent_crowder) - 1)]
            delta_idx = parent_crowder[min(2, len(parent_crowder) - 1)]
            Alpha = evaluated_pop_data[alpha_idx]['job_init']
            Beta = evaluated_pop_data[beta_idx]['job_init']
            Delta = evaluated_pop_data[delta_idx]['job_init']
            Alpha = np.array(Alpha, dtype=float)
            Beta = np.array(Beta, dtype=float)
            Delta = np.array(Delta, dtype=float)
            t = gen + 1  # 当前迭代次数 (从 1 开始计数)
            t_max = self.generation  # 最大迭代次数
            # *** 修改计算 a 的方式 ***
            # try:
            #     # 计算指数项，防止 t=0 时 e^(0)=1
            #     exp_term = math.exp(t / t_max) if t > 0 else 1.0
            #     # 计算分子和分母中的余弦项
            #     cos_term_t = math.cos(exp_term / 2)
            #     cos_term_e = math.cos(math.e / 2)  # math.e 是自然常数
            #     cos_term_half = math.cos(0.5)
            #
            #     # 计算分母，处理可能为零的情况
            #     denominator = cos_term_e - cos_term_half
            #     if abs(denominator) < 1e-9:  # 避免除以零
            #         # 如果分母接近零，a 应该接近 0 (或根据具体情况处理)
            #         # 理论上 cos(e/2) != cos(1/2)，这种情况不太可能发生
            #         print("警告：非线性 a 计算中分母接近零！")
            #         a = 0.0
            #     else:
            #         # 计算括号内的部分
            #         fraction = (cos_term_t - cos_term_half) / denominator
            #         # 计算 a_gwo
            #         a = 2 * (1 - abs(fraction))
            #         # 确保 a_gwo 在合理范围 [0, 2] (理论上应该如此，但加上保险)
            #         a = max(0, min(a, 2))
            # except OverflowError:
            #     print(f"警告：计算非线性 a 时发生溢出错误 (t={t}, t_max={t_max})，回退到线性递减。")
            #     # 回退到线性递减以防万一
            #     a = 2 * (1 - gen / self.generation)
            a = 2 * (1 - gen / self.generation)
            # --- GWO 位置更新 ---
            num_dimensions = len(self.work)
            offspring_job_init_vectors = np.zeros_like(job_init_vectors)
            # *** 根据当前代数确定 Lévy alpha 值 ***
            current_levy_alpha = self.initial_levy_alpha  # 默认值
            for start_gen, alpha_val in sorted(self.levy_alpha_schedule.items()):
                if gen >= start_gen:
                    current_levy_alpha = alpha_val

            for i in range(3,self.popsize):     #用最优位置进行工序编码的更新
                trantime,job,machine,machine_time,wc=work_tran2[i:i+1],work_job2[i:i+1],work_M2[i:i+1],work_T2[i:i+1],work_wc2[i:i+1]

                Ma_W1,Tm_W1,WCross,WC_W1=self.to_MT(job,machine,machine_time,wc)
                # x=job_init1[i] # 当前位置
                x = job_init_vectors[i]
                r1 = random.random()   #灰狼算法解的更新
                r2 = random.random()
                A1 = 2 * a * r1 - a
                C1 = 2 * r2
                D_alpha =C1*Alpha-x
                x1 = x - A1 * D_alpha

                r1 = random.random()
                r2 = random.random()
                A2 = 2 * a * r1 - a
                C2 = 2 * r2
                D_beta =C2*Beta-x
                x2 = x - A2 * D_beta

                r1 = random.random()
                r2 = random.random()
                A3 = 2 * a * r1 - a
                C3 = 2 * r2
                D_delta =C3*Delta-x
                x3 = x - A3 * D_delta
                # 生成与位置向量维度相同的 Lévy 步长
                levy_step = self.levy_flight_step(beta=self.levy_beta, alpha=current_levy_alpha, size=num_dimensions)
                # offspring_job_init_vectors[i] = (x1 + levy_step + x2 + x3) / 3
                offspring_job_init_vectors[i] = (x1 + x2 + x3) / 3
            gwo_offspring_pop_data = []
            for i in range(self.popsize):
                index_work = offspring_job_init_vectors[i].argsort()
                job_gwo = np.array([[self.work[idx] for idx in index_work]])
                # MS/WS 继承自父代 (evaluated_pop_data[i] 是上一代被选中的个体)
                parent_data_for_ms_ws = evaluated_pop_data[i]
                M_gwo = parent_data_for_ms_ws['M']
                T_gwo = parent_data_for_ms_ws['T']
                wc_gwo = parent_data_for_ms_ws['wc']
                tran_gwo = self.gettran(job_gwo, M_gwo)
                C_finish1, _, list_T, list_M, list_S, list_W, tmmw, Wmax, Twork1, global_max_fatigue, E_all1 = self.to.caculate(
                    job_gwo, M_gwo, T_gwo, tran_gwo, wc_gwo, record_fatigue_history=False)
                job_list1 = self._get_hashable_key(job_gwo)
                job_init_gwo = self.update_position_vector(offspring_job_init_vectors[i], job_list1)
                gwo_offspring_pop_data.append(
                    {'job': job_gwo, 'M': M_gwo, 'T': T_gwo, 'tran': tran_gwo, 'wc': wc_gwo,
                     'fitness': [C_finish1, E_all1, global_max_fatigue],
                     'job_init': job_init_gwo})
            crossed_offspring_pop_data = []
            for i in range(0, self.popsize, 2):  # 机器均匀交叉
                p1_idx, p2_idx = np.random.choice(self.popsize, 2, replace=False)  # 从当前父代中选
                parent1_data = evaluated_pop_data[p1_idx]; parent2_data = evaluated_pop_data[p2_idx]
                child1_os_pox, child2_os_pox = self.POX_improve(parent1_data['job'], parent2_data['job'])
                child1_os_pox_list = self._get_hashable_key(child1_os_pox)
                parent1_list = self._get_hashable_key(parent1_data['job_init'])
                job_init_c1 = self.update_position_vector(parent1_list, child1_os_pox_list)
                job_init_c1 = np.array(job_init_c1).reshape(1, len(self.work))
                child2_os_pox_list= self._get_hashable_key(child2_os_pox)
                parent2_list = self._get_hashable_key(parent2_data['job_init'])
                job_init_c2 = self.update_position_vector(parent2_list, child2_os_pox_list)
                job_init_c2 = np.array(job_init_c2).reshape(1, len(self.work))

                Ma_W1_p1,Tm_W1_p1,WCross_p1,WC_W1_p1 = self.to_MT(parent1_data['job'],parent1_data['M'],parent1_data['T'],parent1_data['wc'])
                Ma_W1_p2,Tm_W1_p2,_,WC_W1_p2 = self.to_MT(parent2_data['job'],parent2_data['M'],parent2_data['T'],parent2_data['wc'])
                child_MC1,child_TC1,child_MC2,child_TC2,child_WC1_cross,child_WC2_cross = self.mac_cross(Ma_W1_p1,Tm_W1_p1,Ma_W1_p2,Tm_W1_p2,WCross_p1,WC_W1_p1,WC_W1_p2)

                c1_os = np.array([child1_os_pox]); c1_M,c1_T,c1_wc = self.back_MT(c1_os,child_MC1,child_TC1,child_WC1_cross); c1_tran=self.gettran(c1_os,c1_M)
                c2_os = np.array([child2_os_pox]); c2_M,c2_T,c2_wc = self.back_MT(c2_os,child_MC2,child_TC2,child_WC2_cross); c2_tran=self.gettran(c2_os,c2_M)

                C_finish1, _, list_T, list_M, list_S, list_W, tmmw,Wmax,Twork1,global_max_fatigue,E_all1 = self.to.caculate(c1_os, c1_M, c1_T, c1_tran,c1_wc,record_fatigue_history=False)
                fit_c1 = [C_finish1, E_all1, global_max_fatigue]
                C_finish1, _, list_T, list_M, list_S, list_W, tmmw,Wmax,Twork1,global_max_fatigue,E_all1 = self.to.caculate(c2_os, c2_M, c2_T, c2_tran,c2_wc,record_fatigue_history=False)
                fit_c2 = [C_finish1, E_all1, global_max_fatigue]

                crossed_offspring_pop_data.append({'job': c1_os, 'M': c1_M, 'T': c1_T, 'tran': c1_tran, 'wc': c1_wc,
                                                   'job_init': job_init_c1, 'fitness': fit_c1})
                crossed_offspring_pop_data.append({'job': c2_os, 'M': c2_M, 'T': c2_T, 'tran': c2_tran, 'wc': c2_wc,
                                                   'job_init': job_init_c2, 'fitness': fit_c2})
            combined_population_data = evaluated_pop_data + gwo_offspring_pop_data + crossed_offspring_pop_data
            # evaluated_pop_data = self._tournament_selection(combined_population_data, self.popsize)
            # 非支配选择
            all_initial_fitness = [ind['fitness'] for ind in combined_population_data]
            Z_answer = self.z_score_normalize_objectives(all_initial_fitness)
            front, crowd, initial_crowder = self.oh.dis(Z_answer)
            next_pop_indices = initial_crowder[:self.popsize]
            evaluated_pop_data = [combined_population_data[idx] for idx in next_pop_indices]
            # 更新下一代 GWO 位置向量 job_init_vectors
            for i in range(self.popsize):
                job_init_vectors[i] = evaluated_pop_data[i]['job_init']
                # (可选) 更新 work_job, work_M 等，如果其他地方会用到最新一代的编码
                work_job[i:i+1] = evaluated_pop_data[i]['job']
                work_M[i:i+1] = evaluated_pop_data[i]['M']
                work_T[i:i+1] = evaluated_pop_data[i]['T']
                work_tran[i:i+1] = evaluated_pop_data[i]['tran']
                work_wc[i:i+1] = evaluated_pop_data[i]['wc']
            # 7. 记录当前代最优信息
            current_evals_for_stats = [ind['fitness'] for ind in evaluated_pop_data]
            Z_answer = self.z_score_normalize_objectives(current_evals_for_stats)
            front, _, final_crowder_for_stats = self.oh.dis(Z_answer) # 使用 final_crowder_for_stats
            if front and front[0]:
                # 获取前沿个体的实际适应度值
                current_pareto_fitness = [current_evals_for_stats[k] for k in front[0]]
                if current_pareto_fitness:
                    min_c = min(f[0] for f in current_pareto_fitness); fit_every[0].append(min_c)
                    min_e = min(f[1] for f in current_pareto_fitness); fit_every[1].append(min_e)
                    min_s = min(f[2] for f in current_pareto_fitness); fit_every[2].append(min_s)
                    print(f'Gen {gen + 1}: Cmax={min_c:.1f}, Eall={min_e:.1f}, globalMaxFatigue={min_s:.3f}')
            else:
                # 处理没有有效前沿的情况
                if gen > 0 and fit_every[0]:
                     fit_every[0].append(fit_every[0][-1]); fit_every[1].append(fit_every[1][-1]); fit_every[2].append(fit_every[2][-1])
                else:
                     fit_every[0].append(float('inf')); fit_every[1].append(float('inf')); fit_every[2].append(float('inf'))
                print(f'Gen {gen + 1}: No valid Pareto front found for stats.')
            # print(fit_every)
            final_fitnesses = [ind['fitness'] for ind in evaluated_pop_data]
            Z_answer = self.z_score_normalize_objectives(final_fitnesses)
            final_front, _, final_crowder = self.oh.dis(Z_answer)
            final_pareto_indices = final_front[0] if final_front else []
            pareto = [evaluated_pop_data[i]['fitness'] for i in final_pareto_indices]
            pareto_job = np.array([evaluated_pop_data[i]['job'][0] for i in final_pareto_indices])
            pareto_machine = np.array([evaluated_pop_data[i]['M'][0] for i in final_pareto_indices])
            pareto_time = np.array([evaluated_pop_data[i]['T'][0] for i in final_pareto_indices])
            pareto_tran = np.array([evaluated_pop_data[i]['tran'][0] for i in final_pareto_indices])
            pareto_Wc = np.array([evaluated_pop_data[i]['wc'][0] for i in final_pareto_indices])
            print('算法迭代到了第%.0f次' % (gen + 1))
            print(pareto)
        return pareto,pareto_job,pareto_machine,pareto_time,pareto_tran,fit_every,pareto_Wc  #返回pareto解及其编码