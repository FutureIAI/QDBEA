import numpy as np


def update_position_vector(original_positions, original_order, new_order):
    """
    根据工序加工顺序的变化更新位置向量

    参数:
    original_positions (list): 原始位置向量
    original_order (list): 原始位置向量对应的工序编码
    new_order (list): 新的工序编码

    返回:
    list: 更新后的位置向量
    """
    # 确保输入合法
    if len(original_positions) != len(original_order) or len(original_order) != len(new_order):
        raise ValueError("所有输入列表的长度必须相同")

    # 创建原始位置向量和工序编码的映射
    position_map = {}
    for pos, order in zip(original_positions, original_order):
        if order not in position_map:
            position_map[order] = []
        position_map[order].append(pos)

    # 对每个工序编码的位置向量进行降序排序
    for order in position_map:
        position_map[order].sort(reverse=True)

    # 根据新的工序编码生成新的位置向量
    new_positions = []
    used_counts = {order: 0 for order in position_map}

    for order in new_order:
        if order not in position_map:
            raise ValueError(f"新的工序编码 {order} 不在原始工序编码中")

        # 获取该工序编码对应的下一个位置值
        pos_list = position_map[order]
        index = used_counts[order]

        if index >= len(pos_list):
            # 如果位置值不够用，则生成一个比当前最小值略小的值
            min_val = min(pos_list)
            new_val = min_val - 0.1 * (index - len(pos_list) + 1)
            new_positions.append(new_val)
        else:
            new_positions.append(pos_list[index])
            used_counts[order] += 1

    return new_positions


# 示例使用 - 修正后的对应关系
if __name__ == "__main__":
    # 原始位置向量
    original_positions = [2.8, 2.2, 2.1, 1.8, 1.5, 0.9, 0.7, 0.6, 0.2]
    # 原始工序编码（根据降序排列后的位置向量生成）
    original_order = [1, 1, 1, 2, 2, 2, 3, 3, 3]
    # 新的工序编码
    new_order = [1, 1, 2, 2, 2, 1, 3, 3, 3]

    # 更新位置向量
    new_positions = update_position_vector(original_positions, original_order, new_order)

    print("原始位置向量:", original_positions)
    print("原始工序编码:", original_order)
    print("新的工序编码:", new_order)
    print("更新后的位置向量:", new_positions)