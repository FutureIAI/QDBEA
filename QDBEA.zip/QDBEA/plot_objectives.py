import ast
import seaborn as sns
import matplotlib.pyplot as plt
import numpy as np

# 确保中文显示正常
from matplotlib.pylab import mpl
mpl.rcParams['font.sans-serif'] = ['SimHei']
mpl.rcParams['axes.unicode_minus'] = False # 解决负号显示问题

class Plotting:
    def comparison(self, content1, content2):
        content_1 = str(content1)
        content_2 = str(content2)
        # 解析两个数据
        lines1 = ast.literal_eval(str(content_1))
        lines2 = ast.literal_eval(str(content_2))

        titles = ['makespan', 'energy cost', 'worker fatigue']
        labels = ['Data 1', 'Data 2']  # 两个数据的标签

        plt.figure(figsize=[18, 6])

        # 遍历三个指标
        for i in range(len(titles)):
            plt.subplot(1, 3, i + 1)
            plt.title(titles[i])

            # 绘制第一个数据集
            values1 = [obj for obj in lines1[i]]
            sns.lineplot(data=values1, label=labels[0])

            # 绘制第二个数据集
            values2 = [obj for obj in lines2[i]]
            sns.lineplot(data=values2, label=labels[1])

            plt.xlabel('Index')
            plt.ylabel('Value')
            plt.legend()

        plt.tight_layout()
        plt.savefig('CURVE_Comparison.png', dpi=300)
        plt.show()

    def plot_convergence_comparison(self,*algorithm_results, **kwargs):
        """
        绘制多个算法在多个目标上的收敛曲线对比图。

        Args:
            *algorithm_results: 一个或多个算法的结果元组。
                                每个元组的格式应为 (fit_every_data, algorithm_name)。
                                例如: (F1, 'SGA'), (F3, 'SS-GWO'), ...

            **kwargs:
                title_prefix (str): 图表标题的前缀, 默认为 "Convergence Curve Comparison"。
                save_path_prefix (str): 图片保存路径的前缀, 默认为 "convergence_comparison"。
        """

        # --- 1. 获取参数 ---
        if not algorithm_results:
            print("没有提供任何算法结果，无法绘图。")
            return

        # title_prefix = kwargs.get('title_prefix', '收敛曲线对比')
        save_path_prefix = kwargs.get('save_path_prefix', 'convergence_comparison')

        # 定义目标名称和颜色/样式列表
        objective_names = ['最大完工时间 (Cmax)', '总能耗 (Energy)', '最大疲劳度 (Fatigue)']
        colors = ['#FF4136', '#0074D9', '#2ECC40', '#B10DC9', '#FF851B', '#7FDBFF']  # 红, 蓝, 绿, 紫, 橙, 浅蓝
        linestyles = ['-', '--', '-.', ':']  # 实线, 虚线, 点划线, 点线

        # 确定迭代次数 (以第一个算法为准)
        # 假设所有算法的迭代次数相同
        num_generations = len(algorithm_results[0][0][0])
        generations_axis = np.arange(1, num_generations + 1)

        # --- 2. 为每个目标绘制一张对比图 ---
        for obj_idx, obj_name in enumerate(objective_names):

            plt.figure(figsize=(12, 8))

            # --- 循环绘制每个算法的收敛曲线 ---
            for i,  (fit_every, algo_name) in enumerate(algorithm_results):

                # 检查数据长度是否匹配
                if len(fit_every[obj_idx]) != num_generations:
                    print(f"警告: 算法 '{algo_name}' 的目标 '{obj_name}' 数据长度 "
                          f"({len(fit_every[obj_idx])}) 与预期的迭代次数 ({num_generations}) 不匹配。将尝试绘制。")
                    # 创建一个匹配的x轴
                    current_gen_axis = np.arange(1, len(fit_every[obj_idx]) + 1)
                    plt.plot(current_gen_axis, fit_every[obj_idx],
                             label=algo_name,
                             color=colors[i % len(colors)],
                             linestyle=linestyles[i % len(linestyles)],
                             linewidth=2.5,
                             alpha=0.8)
                else:
                    plt.plot(generations_axis, fit_every[obj_idx],
                             label=algo_name,
                             color=colors[i % len(colors)],
                             linestyle=linestyles[i % len(linestyles)],
                             linewidth=2.5,
                             alpha=0.8)

            # --- 3. 美化图表 ---
            plt.title(f'{obj_name}', fontsize=18, weight='bold')
            plt.xlabel('迭代次数 (Generation)', fontsize=14)
            plt.ylabel('目标最小值 (Best Value)', fontsize=14)

            # 设置坐标轴刻度字体大小
            plt.xticks(fontsize=12)
            plt.yticks(fontsize=12)

            # 显示网格
            plt.grid(True, linestyle='--', alpha=0.6)

            # 显示图例
            plt.legend(fontsize=15)

            # 调整布局以防止标签重叠
            plt.tight_layout()

            # --- 4. 保存和显示 ---
            CURVE_convergence_Comparison = f"{save_path_prefix}_{obj_name.split(' ')[0]}.png"
            plt.savefig(CURVE_convergence_Comparison, dpi=300)
            print(f"对比图已保存至: {CURVE_convergence_Comparison}")

            plt.show()

    def plot_convergence_comparison_average(self, *results, save_path_prefix="comparison"):
        """
        绘制多个算法在多次运行下的平均收敛曲线对比图。

        Args:
            *results: 可变参数，每个参数是一个元组 (fit_histories, algo_name)。
                      其中 fit_histories 是一个包含多次运行历史的列表，
                      例如 [[run1_cmax, run1_energy, run1_fatigue], [run2_...]]
            save_path_prefix (str): 保存图像文件的前缀。
        """
        if not results:
            print("No results to plot.")
            return
        objectives = ['makespan', 'energy cost', 'worker fatigue']
        num_objectives = len(objectives)
        # 创建一个包含3个子图的画布
        fig, axes = plt.subplots(1, num_objectives, figsize=(20, 6))
        # fig.suptitle('Average Convergence Comparison Over Multiple Runs', fontsize=16)
        # 遍历每个目标（makespan, energy, fatigue）
        for i, obj_name in enumerate(objectives):
            ax = axes[i]

            # 在当前子图上绘制每个算法的平均曲线
            for fit_histories, algo_name in results:
                # 1. 从多次运行历史中提取当前目标的数据
                # 例如，对于 makespan (i=0)，提取所有 run 的 cmax_history
                all_runs_for_obj = [run_history[i] for run_history in fit_histories]

                # 2. 找到所有运行中最短的迭代次数，以它为准进行对齐
                min_len = min(len(run) for run in all_runs_for_obj)
                # 将所有运行数据裁剪到相同长度
                aligned_runs = [run[:min_len] for run in all_runs_for_obj]

                # 3. 计算平均值和标准差
                # 将列表转换为Numpy数组以便进行列向计算
                runs_array = np.array(aligned_runs)
                mean_curve = np.mean(runs_array, axis=0)
                std_curve = np.std(runs_array, axis=0)

                # 4. 准备x轴（迭代次数）
                iterations = np.arange(min_len)

                # 5. 绘制平均收敛曲线
                line, = ax.plot(iterations, mean_curve, label=algo_name)

            # --- 美化当前子图 ---
            ax.set_title(obj_name)
            ax.set_xlabel('Generation',fontsize=14)
            ax.set_ylabel('Value',fontsize=14)
            ax.grid(True, linestyle='--', alpha=0.6)
            ax.legend(fontsize=15)

        # --- 保存图像 ---
        plt.tight_layout(rect=[0, 0, 1, 0.96])  # 调整布局为总标题留出空间
        save_path = f"{save_path_prefix}_average_convergence.png"
        plt.savefig(save_path, dpi=300)
        print(f"Average convergence comparison plot saved to {save_path}")
        plt.show()

if __name__ == '__main__':
    np.random.seed(42)
    generations = 100
    def generate_fake_fitevery(start_vals, end_vals):
        cmax = np.linspace(start_vals[0], end_vals[0], generations) + np.random.randn(generations) * 10
        energy = np.linspace(start_vals[1], end_vals[1], generations) + np.random.randn(generations) * 50
        fatigue = np.linspace(start_vals[2], end_vals[2], generations) + np.random.randn(generations) * 0.02
        return [cmax, energy, fatigue]

    F1 = generate_fake_fitevery([400, 19000, 0.9], [320, 17500, 0.84])  # SGA
    F3 = generate_fake_fitevery([380, 18800, 0.88], [310, 17200, 0.82])  # SS-GWO (假设效果最好)
    F4 = generate_fake_fitevery([420, 19500, 0.92], [340, 18000, 0.86])  # NSGA-II (假设效果最差)
    F5 = generate_fake_fitevery([390, 19200, 0.89], [315, 17300, 0.83])  # SGA-Lévy

    # ==============================================================
    # 【调用新的绘图函数】
    # ==============================================================

    # 将每个算法的结果和它的名字打包成一个元组
    sga_result = (F1, 'SGA')
    ssgwo_result = (F3, 'SS-GWO')
    nsga2_result = (F4, 'NSGA-II (ENSGA-II)')
    sgalevy_result = (F5, 'SGA-Lévy')

    pa = Plotting()
    # 调用函数，传入所有要对比的算法结果
    pa.plot_convergence_comparison_average(
        ssgwo_result,
        nsga2_result,
        sgalevy_result,
        sga_result,
        # title_prefix="4种算法性能对比",
        save_path_prefix="4_algos_comparison"
    )